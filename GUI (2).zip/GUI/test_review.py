"""
快速测试审核功能
直接运行此文件可以测试审核页面
"""
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt6.QtWidgets import QApplication
from GUI.product_review_page import ProductReviewPage

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ProductReviewPage()
    window.show()
    sys.exit(app.exec())

