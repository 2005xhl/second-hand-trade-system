"""
快速测试发布功能
直接运行此文件可以测试发布和审核功能
"""
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt6.QtWidgets import QApplication
from GUI.publish_page import PublishPage

if __name__ == "__main__":
    app = QApplication(sys.argv)
    # 模拟用户信息
    user_info = {'user_id': 1, 'username': 'test_user'}
    window = PublishPage(user_info=user_info)
    window.show()
    sys.exit(app.exec())

