"""
用户管理页面（管理员专用）
"""
import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QLineEdit, QTableWidget, QTableWidgetItem,
                             QHeaderView)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont


class UserManagementPage(QMainWindow):
    """用户管理页面"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("用户管理 - 闲转")
        self.setGeometry(100, 100, 1200, 800)
        self.setStyleSheet("background-color: #F8F8F8;")
        
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)
        
        # 内容区
        self.create_content()
        main_layout.addWidget(self.content_area)
        
        main_widget.setLayout(main_layout)
        
        # 加载用户数据
        self.load_users()
    
    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        
        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333;
                border: none;
                font-size: 16px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #F5F5F5;
                border-radius: 5px;
            }
        """)
        back_btn.clicked.connect(self.close)
        layout.addWidget(back_btn)
        
        # 标题
        title_label = QLabel("用户管理")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label, 1)
        
        self.top_nav.setLayout(layout)
    
    def create_content(self):
        """创建内容区"""
        self.content_area = QScrollArea()
        self.content_area.setWidgetResizable(True)
        self.content_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(20, 20, 20, 20)
        scroll_layout.setSpacing(20)
        
        # 搜索栏
        search_frame = QFrame()
        search_frame.setFixedHeight(50)
        search_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 8px;
                border: 1px solid #E0E0E0;
            }
        """)
        
        search_layout = QHBoxLayout()
        search_layout.setContentsMargins(15, 10, 15, 10)
        
        search_input = QLineEdit()
        search_input.setPlaceholderText("搜索用户名或ID...")
        search_input.setStyleSheet("""
            QLineEdit {
                border: none;
                font-size: 14px;
            }
        """)
        search_layout.addWidget(search_input)
        
        search_btn = QPushButton("搜索")
        search_btn.setFixedSize(80, 30)
        search_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 15px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        search_layout.addWidget(search_btn)
        
        search_frame.setLayout(search_layout)
        scroll_layout.addWidget(search_frame)
        
        # 用户表格
        self.user_table = QTableWidget()
        self.user_table.setColumnCount(5)
        self.user_table.setHorizontalHeaderLabels(["用户ID", "用户名", "角色", "注册时间", "操作"])
        self.user_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.user_table.setStyleSheet("""
            QTableWidget {
                background-color: white;
                border-radius: 8px;
                border: 1px solid #E0E0E0;
                gridline-color: #E0E0E0;
            }
            QTableWidget::item {
                padding: 10px;
            }
            QHeaderView::section {
                background-color: #F5F5F5;
                padding: 10px;
                border: none;
                font-weight: bold;
            }
        """)
        scroll_layout.addWidget(self.user_table)
        
        scroll_content.setLayout(scroll_layout)
        self.content_area.setWidget(scroll_content)
    
    def load_users(self):
        """加载用户数据"""
        # 模拟用户数据
        users = [
            {"id": "U001", "name": "用户A", "role": "普通用户", "time": "2024-01-01"},
            {"id": "U002", "name": "用户B", "role": "普通用户", "time": "2024-01-02"},
            {"id": "U003", "name": "管理员", "role": "管理员", "time": "2023-12-01"},
        ]
        
        self.user_table.setRowCount(len(users))
        for i, user in enumerate(users):
            self.user_table.setItem(i, 0, QTableWidgetItem(user["id"]))
            self.user_table.setItem(i, 1, QTableWidgetItem(user["name"]))
            self.user_table.setItem(i, 2, QTableWidgetItem(user["role"]))
            self.user_table.setItem(i, 3, QTableWidgetItem(user["time"]))
            
            # 操作按钮
            action_btn = QPushButton("查看详情")
            action_btn.setFixedSize(80, 30)
            action_btn.setStyleSheet("""
                QPushButton {
                    background-color: #FFA366;
                    color: white;
                    border: none;
                    border-radius: 15px;
                    font-size: 12px;
                }
                QPushButton:hover {
                    background-color: #FFB380;
                }
            """)
            # 绑定点击事件
            user_id = user["id"]
            action_btn.clicked.connect(lambda checked, uid=user_id: self.view_user_detail(uid))
            self.user_table.setCellWidget(i, 4, action_btn)
    
    def view_user_detail(self, user_id):
        """查看用户详情"""
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton
        dialog = QDialog(self)
        dialog.setWindowTitle("用户详情")
        dialog.setFixedSize(400, 300)
        dialog.setStyleSheet("""
            QDialog {
                background-color: white;
                border-radius: 12px;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(30, 30, 30, 30)
        
        # 用户信息
        info_text = f"""
        <h3>用户详情</h3>
        <p><b>用户ID:</b> {user_id}</p>
        <p><b>用户名:</b> 用户{user_id[-1]}</p>
        <p><b>角色:</b> 普通用户</p>
        <p><b>注册时间:</b> 2024-01-01</p>
        <p><b>发布商品数:</b> 5</p>
        <p><b>成交订单数:</b> 3</p>
        """
        info_label = QLabel(info_text)
        info_label.setStyleSheet("font-size: 14px; color: #333;")
        layout.addWidget(info_label)
        
        layout.addStretch()
        
        # 关闭按钮
        close_btn = QPushButton("关闭")
        close_btn.setFixedHeight(40)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn)
        
        dialog.setLayout(layout)
        dialog.exec()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = UserManagementPage()
    window.show()
    sys.exit(app.exec())

