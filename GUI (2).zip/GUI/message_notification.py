"""
全局消息通知组件
可以在任何界面显示新消息提醒
"""
from PyQt6.QtWidgets import QLabel, QWidget, QApplication
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer, QPoint


class MessageNotification(QWidget):
    """新消息通知组件"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.FramelessWindowHint | 
            Qt.WindowType.WindowStaysOnTopHint |
            Qt.WindowType.Tool
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        
        # 固定宽度（比较窄）
        self.setFixedWidth(150)
        self.setFixedHeight(45)
        
        # 创建标签
        self.label = QLabel("新消息！", self)
        self.label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label.setStyleSheet("""
            QLabel {
                background-color: transparent;
                color: #FF0000;
                font-size: 16px;
                font-weight: bold;
                padding: 10px 15px;
            }
        """)
        self.label.setGeometry(0, 0, 150, 45)
        
        # 初始位置（屏幕顶部居中）
        self.hide()
    
    def show_notification(self, parent_window=None):
        """显示通知"""
        # 获取当前活动的窗口
        if parent_window is None:
            # 尝试获取当前活动的窗口
            app = QApplication.instance()
            if app:
                active_window = app.activeWindow()
                if active_window:
                    parent_window = active_window
        
        if parent_window:
            # 在父窗口顶部居中显示
            x = parent_window.x() + (parent_window.width() - self.width()) // 2
            y = parent_window.y() + 50
            self.move(x, y)
        else:
            # 如果没有父窗口，在屏幕顶部居中显示
            screen = QApplication.primaryScreen().geometry()
            x = (screen.width() - self.width()) // 2
            y = 50
            self.move(x, y)
        
        # 淡入动画
        self.setWindowOpacity(0)
        self.show()
        self.raise_()  # 确保在最上层
        
        fade_in = QPropertyAnimation(self, b"windowOpacity")
        fade_in.setDuration(300)
        fade_in.setStartValue(0)
        fade_in.setEndValue(1)
        fade_in.setEasingCurve(QEasingCurve.Type.OutCubic)
        fade_in.start()
        
        # 3秒后淡出并隐藏
        QTimer.singleShot(3000, self.hide_notification)
    
    def hide_notification(self):
        """隐藏通知（带淡出动画）"""
        fade_out = QPropertyAnimation(self, b"windowOpacity")
        fade_out.setDuration(300)
        fade_out.setStartValue(1)
        fade_out.setEndValue(0)
        fade_out.setEasingCurve(QEasingCurve.Type.InCubic)
        fade_out.finished.connect(self.hide)
        fade_out.start()


# 全局消息通知管理器
class MessageNotificationManager:
    """消息通知管理器（单例模式）"""
    _instance = None
    _notification = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(MessageNotificationManager, cls).__new__(cls)
        return cls._instance
    
    def show_new_message(self, parent_window=None):
        """显示新消息通知"""
        if self._notification is None:
            self._notification = MessageNotification()
        
        self._notification.show_notification(parent_window)
    
    def get_notification_widget(self):
        """获取通知组件（用于添加到页面中）"""
        if self._notification is None:
            self._notification = MessageNotification()
        return self._notification


# 全局函数，方便在任何地方调用
def show_new_message_notification(parent_window=None):
    """显示新消息通知的全局函数"""
    manager = MessageNotificationManager()
    manager.show_new_message(parent_window)

