"""
本地存储模块（用于前端测试，模拟服务器数据）
"""
import json
import os
from datetime import datetime

# 存储文件路径
STORAGE_FILE = os.path.join(os.path.dirname(__file__), "local_data.json")

def load_data():
    """加载本地数据，并做一次数据校验/归位"""
    data = None
    if os.path.exists(STORAGE_FILE):
        try:
            with open(STORAGE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except:
            data = None
    if not data:
        data = {
            'pending_goods': [],
            'approved_goods': [],
            'sold_goods': [],
            'rejected_goods': [],
            'favorites': [],
            'orders': []
        }
    # 确保字段存在
    data.setdefault('pending_goods', [])
    data.setdefault('approved_goods', [])
    data.setdefault('sold_goods', [])
    data.setdefault('rejected_goods', [])
    data.setdefault('favorites', [])
    data.setdefault('orders', [])

    changed = False

    # 统一清洗并修复 goods_id（去掉 False/None/空，去重，补发新ID）
    fixed = _sanitize_goods_ids(data)
    if fixed:
        changed = True

    # 归位：曾被错误放入 sold_goods 的下架商品，挪回 approved 并标记 off
    moved = False
    fixed_sold = []
    for g in data.get('sold_goods', []):
        status_val = g.get('status')
        if status_val == 'off':
            # 移回已上架列表并保留下架状态
            g['status'] = 'off'
            g.setdefault('off_time', g.get('sold_time'))
            data['approved_goods'].append(g)
            moved = True
        else:
            fixed_sold.append(g)
    if moved:
        data['sold_goods'] = fixed_sold
        changed = True

    if changed:
        save_data(data)
    return data

def get_favorites(user_id=None):
    """获取收藏列表，按用户过滤（user_id=None 时返回全部）"""
    data = load_data()
    favorites = data.get('favorites', [])
    if user_id is None:
        return favorites
    return [f for f in favorites if str(f.get('user_id')) == str(user_id)]

def is_favorited(user_id, goods_id):
    """判断是否已收藏"""
    favs = get_favorites(user_id)
    for f in favs:
        if str(f.get('goods_id')) == str(goods_id):
            return True
    return False

def add_favorite(user_id, goods):
    """添加收藏：goods 包含 goods_id, title, price, img_path 等"""
    if user_id is None or goods is None:
        return False
    data = load_data()
    favorites = data.get('favorites', [])
    for f in favorites:
        if str(f.get('user_id')) == str(user_id) and str(f.get('goods_id')) == str(goods.get('goods_id')):
            return True  # 已存在
    entry = {
        'user_id': user_id,
        'goods_id': goods.get('goods_id'),
        'title': goods.get('title', ''),
        'price': goods.get('price', 0),
        'img_path': goods.get('img_path', ''),
        'description': goods.get('description', ''),
        'category': goods.get('category', ''),
        'condition': goods.get('condition', ''),
        'create_time': goods.get('create_time', '')
    }
    favorites.append(entry)
    data['favorites'] = favorites
    save_data(data)
    return True

def remove_favorite(user_id, goods_id):
    """取消收藏"""
    data = load_data()
    favorites = data.get('favorites', [])
    new_favs = [f for f in favorites if not (str(f.get('user_id')) == str(user_id) and str(f.get('goods_id')) == str(goods_id))]
    data['favorites'] = new_favs
    save_data(data)
    return True

def get_favorite_count(goods_id):
    """获取某商品收藏数"""
    data = load_data()
    favorites = data.get('favorites', [])
    return len([f for f in favorites if str(f.get('goods_id')) == str(goods_id)])

def save_data(data):
    """保存本地数据"""
    try:
        with open(STORAGE_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"保存数据失败: {e}")
        return False

def _next_goods_id(data):
    """生成全局唯一ID（遍历所有列表）"""
    all_ids = []
    for key in ['pending_goods', 'approved_goods', 'sold_goods', 'rejected_goods']:
        for g in data.get(key, []):
            gid = g.get('goods_id')
            if gid is None or gid is False or gid == '':
                continue
            try:
                all_ids.append(int(gid))
            except Exception:
                # 如果是非数字的旧ID，忽略
                continue
    return (max(all_ids) + 1) if all_ids else 1

def _next_order_id(data):
    """生成订单ID（简单自增字符串）"""
    orders = data.get('orders', [])
    if not orders:
        return "1001"
    try:
        ids = [int(str(o.get('id'))) for o in orders if o.get('id') is not None]
        return str(max(ids) + 1) if ids else "1001"
    except Exception:
        return "1001"

def _is_valid_id(gid):
    """判断ID是否为有效数字"""
    try:
        if gid is None or gid is False or gid == '':
            return False
        if isinstance(gid, str) and gid.strip().lower() == 'false':
            return False
        int(gid)
        return True
    except Exception:
        return False


def _sanitize_goods_ids(data):
    """修复无效ID（None/False/空/非数字），为其分配新ID；已是有效数字的不改，允许重复保留。返回是否有变更。"""
    valid_max = 0
    seen = set()
    changed = False

    # 先收集已有有效ID的最大值
    for key in ['pending_goods', 'approved_goods', 'sold_goods', 'rejected_goods']:
        for g in data.get(key, []):
            gid = g.get('goods_id')
            try:
                if gid is None or gid is False or gid == '':
                    continue
                num = int(gid)
                valid_max = max(valid_max, num)
            except Exception:
                continue

    def assign_new_id():
        nonlocal valid_max
        valid_max += 1
        return valid_max

    for key in ['pending_goods', 'approved_goods', 'sold_goods', 'rejected_goods']:
        fixed_list = []
        for g in data.get(key, []):
            gid = g.get('goods_id')
            need_new = False
            try:
                if gid is None or gid is False or gid == '' or (isinstance(gid, str) and gid.strip().lower() == 'false'):
                    need_new = True
                else:
                    gid_num = int(gid)
            except Exception:
                need_new = True

            if need_new:
                gid_num = assign_new_id()
                g['goods_id'] = gid_num
                changed = True
            else:
                gid_num = int(g.get('goods_id'))

            seen.add(gid_num)
            fixed_list.append(g)
        data[key] = fixed_list
    return changed


def fix_pending_invalid_ids():
    """修复 pending_goods 中的无效ID，返回修复后的列表"""
    data = load_data()
    changed = False
    for g in data.get('pending_goods', []):
        if not _is_valid_id(g.get('goods_id')):
            g['goods_id'] = _next_goods_id(data)
            changed = True
    if changed:
        save_data(data)
    return data.get('pending_goods', [])

def add_pending_goods(goods_data):
    """添加待审核商品"""
    data = load_data()
    goods_id = _next_goods_id(data)
    
    goods_data['goods_id'] = goods_id
    goods_data['create_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    goods_data['status'] = 'pending'
    
    data['pending_goods'].append(goods_data)
    save_data(data)
    return goods_id

def get_pending_goods():
    """获取待审核商品列表"""
    data = load_data()
    return data['pending_goods']

def get_approved_goods():
    """获取已审核通过的商品列表"""
    data = load_data()
    return data.get('approved_goods', [])

def get_sold_goods():
    """获取已卖出商品列表"""
    data = load_data()
    return [g for g in data.get('sold_goods', []) if g.get('status') == 'sold']

def get_rejected_goods():
    """获取审核未通过的商品列表"""
    data = load_data()
    return data.get('rejected_goods', [])

def _find_goods(data, goods_id):
    """在三个列表里找到商品并返回所在列表名和索引"""
    gid = str(goods_id)
    for key in ['pending_goods', 'approved_goods', 'sold_goods']:
        for idx, g in enumerate(data.get(key, [])):
            if str(g.get('goods_id')) == gid:
                return key, idx, g
    return None, None, None

def update_goods(goods_id, updates: dict):
    """更新商品字段，不改变所在列表"""
    data = load_data()
    key, idx, g = _find_goods(data, goods_id)
    if g is None:
        return False
    g.update(updates)
    data[key][idx] = g
    save_data(data)
    return True

def audit_goods(goods_id, status):
    """审核商品（通过或拒绝）"""
    data = load_data()
    
    # 从待审核列表中移除
    goods = None
    gid = str(goods_id)
    for i, g in enumerate(data['pending_goods']):
        if str(g.get('goods_id')) == gid:
            goods = data['pending_goods'].pop(i)
            break
    
    if goods:
        goods['status'] = status
        goods['audit_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        if status == 'approved':
            data['approved_goods'].append(goods)
        elif status == 'rejected':
            data.setdefault('rejected_goods', []).append(goods)
        
        save_data(data)
        return True
    return False

def mark_goods_sold(goods_id, buyer_id=None, create_order=True, order_id=None):
    """标记商品为已售出：从approved移到sold
    create_order=False 时不再生成新订单（用于已存在订单的支付）"""
    data = load_data()
    target_idx = None
    goods = None
    gid = str(goods_id)
    for i, g in enumerate(data.get('approved_goods', [])):
        if str(g.get('goods_id')) == gid:
            target_idx = i
            goods = g
            break
    if goods is None:
        return False
    
    # 从在售列表移除
    data['approved_goods'].pop(target_idx)
    
    # 标记售出信息并放入已卖出列表
    goods['status'] = 'sold'
    goods['sold_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    goods['buyer_id'] = buyer_id
    goods['order_id'] = order_id if order_id else goods.get('order_id')
    goods['after_sale_status'] = goods.get('after_sale_status', '')
    # 同步生成订单（可选）
    if create_order:
        try:
            order = _create_order_from_goods(goods, buyer_id, data)
            if order_id:
                order['id'] = str(order_id)
                order['order_number'] = str(order_id)
            goods['order_id'] = order.get('id')
            data.setdefault('orders', []).append(order)
        except Exception as e:
            print(f"创建订单失败: {e}")
    data.setdefault('sold_goods', []).append(goods)
    
    save_data(data)
    return True

def _create_order_from_goods(goods, buyer_id, data):
    """基于商品生成订单字典"""
    order_id = _next_order_id(data)
    order_number = f"ORD{datetime.now().strftime('%Y%m%d%H%M%S')}{order_id}"
    title = goods.get('title') or goods.get('name') or "商品"
    price = goods.get('price', 0)
    img_path = goods.get('image') or goods.get('img_path') or ""
    seller_id = goods.get('user_id')
    return {
        'id': order_id,
        'order_number': order_number,
        'goods_id': goods.get('goods_id'),
        'buyer_id': buyer_id,
        'seller_id': seller_id,
        'title': title,
        'price': price,
        'quantity': 1,
        'status': '待发货',  # 付款成功后直接待发货
        'order_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'img_path': img_path,
        'after_sale_reason': '',
        'after_sale_status': ''
    }

def create_cart_order(goods, buyer_id=None):
    """创建待付款订单（加入购物车）"""
    data = load_data()
    order = _create_order_from_goods(goods, buyer_id, data)
    order['status'] = '待付款'
    order['after_sale_reason'] = ''
    order['after_sale_status'] = ''
    data.setdefault('orders', []).append(order)
    save_data(data)
    return order

def get_orders(user_id=None):
    """获取订单列表，按买家过滤"""
    data = load_data()
    orders = data.get('orders', [])
    if user_id is None:
        return orders
    return [o for o in orders if str(o.get('buyer_id')) == str(user_id)]

def get_order_by_id(order_id):
    """按ID获取订单"""
    data = load_data()
    for o in data.get('orders', []):
        if str(o.get('id')) == str(order_id):
            return o
    return None

def update_order_status(order_id, status):
    """更新订单状态"""
    data = load_data()
    updated = False
    for o in data.get('orders', []):
        if str(o.get('id')) == str(order_id):
            o['status'] = status
            updated = True
            break
    if updated:
        save_data(data)
    return updated

def update_order_after_sale(order_id, reason=None, status=None):
    """记录售后原因/状态"""
    data = load_data()
    updated = False
    for o in data.get('orders', []):
        if str(o.get('id')) == str(order_id):
            if reason is not None:
                o['after_sale_reason'] = reason
            if status is not None:
                o['after_sale_status'] = status
            updated = True
            break
    if updated:
        save_data(data)
    return updated

def set_goods_after_sale(goods_id, reason):
    """在已售商品上标记售后原因"""
    data = load_data()
    gid = str(goods_id)
    for g in data.get('sold_goods', []):
        if str(g.get('goods_id')) == gid:
            g['after_sale_reason'] = reason
            save_data(data)
            return True
    return False

def set_goods_after_sale_status(goods_id, status):
    """在已售商品上标记售后状态"""
    data = load_data()
    gid = str(goods_id)
    for g in data.get('sold_goods', []):
        if str(g.get('goods_id')) == gid:
            g['after_sale_status'] = status
            save_data(data)
            return True
    return False

def mark_goods_off(goods_id):
    """下架商品：标记status=off并保留在数据中（不进入已卖出）"""
    data = load_data()
    gid = str(goods_id)
    # 优先在已上架列表处理
    for i, g in enumerate(data.get('approved_goods', [])):
        if str(g.get('goods_id')) == gid:
            goods = data['approved_goods'][i]
            goods['status'] = 'off'
            goods['off_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            data['approved_goods'][i] = goods
            save_data(data)
            return True
    # pending 状态下架，直接标记off并放入rejected列表以便展示
    for i, g in enumerate(data.get('pending_goods', [])):
        if str(g.get('goods_id')) == gid:
            goods = data['pending_goods'].pop(i)
            goods['status'] = 'off'
            goods['off_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            data.setdefault('rejected_goods', []).append(goods)
            save_data(data)
            return True
    return False

