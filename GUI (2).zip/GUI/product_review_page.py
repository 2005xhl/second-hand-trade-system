"""
商品审核页面（管理员专用）
"""
import sys
import os
import json
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QLineEdit, QTextEdit, QMessageBox)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor


class ReviewCard(QFrame):
    """审核卡片"""
    def __init__(self, product_data, on_approve=None, on_reject=None, parent=None):
        super().__init__(parent)
        self.product_data = product_data
        self.on_approve = on_approve
        self.on_reject = on_reject
        
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                border: 1px solid #E0E0E0;
                padding: 15px;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setSpacing(15)
        
        # 商品信息
        info_layout = QHBoxLayout()
        info_layout.setSpacing(15)
        
        # 商品图片
        image_label = QLabel()
        image_label.setFixedSize(100, 100)
        image_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                border-radius: 8px;
            }
        """)
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        image_label.setScaledContents(False)
        
        # 尝试加载真实图片
        img_path = product_data.get('img_path', '')
        if img_path:
            # 处理多个图片路径（用逗号分隔）
            if ',' in img_path:
                img_path = img_path.split(',')[0].strip()
            
            # 处理相对路径和绝对路径
            if not os.path.isabs(img_path):
                # 相对路径，转换为绝对路径
                project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                img_path = os.path.join(project_root, img_path)
            
            if os.path.exists(img_path):
                pixmap = QPixmap(img_path)
                if not pixmap.isNull():
                    pixmap = pixmap.scaled(100, 100, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                    image_label.setPixmap(pixmap)
                else:
                    # 图片加载失败，显示占位图
                    self._load_placeholder(image_label)
            else:
                # 文件不存在，显示占位图
                self._load_placeholder(image_label)
        else:
            # 没有图片路径，显示占位图
            self._load_placeholder(image_label)
        
        info_layout.addWidget(image_label)
        
        # 商品详情
        detail_layout = QVBoxLayout()
        detail_layout.setSpacing(5)
        
        title_label = QLabel(product_data.get("title", "商品标题"))
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        detail_layout.addWidget(title_label)
        
        price_label = QLabel(f"价格：¥{product_data.get('price', 0)}")
        price_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 14px;
            }
        """)
        detail_layout.addWidget(price_label)
        
        seller_label = QLabel(f"发布者：{product_data.get('seller', '未知')}")
        seller_label.setStyleSheet("""
            QLabel {
                color: #666;
                font-size: 12px;
            }
        """)
        detail_layout.addWidget(seller_label)
        
        # 添加分类和成色信息
        category = product_data.get('category', '')
        condition = product_data.get('condition', '')
        if category or condition:
            info_text = []
            if category:
                info_text.append(f"分类：{category}")
            if condition:
                info_text.append(f"成色：{condition}")
            if info_text:
                info_label = QLabel(" | ".join(info_text))
                info_label.setStyleSheet("""
                    QLabel {
                        color: #999;
                        font-size: 11px;
                    }
                """)
                detail_layout.addWidget(info_label)
        
        info_layout.addLayout(detail_layout, 1)
        layout.addLayout(info_layout)
        
        # 操作按钮
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        reject_btn = QPushButton("拒绝")
        reject_btn.setFixedSize(100, 35)
        reject_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                color: #666;
                border: 1px solid #E0E0E0;
                border-radius: 17px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        # 固定使用当前卡片的 goods_id（不再使用其他来源，避免 False）
        current_gid = self.product_data.get("goods_id")
        if self.on_reject and current_gid is not None:
            reject_btn.clicked.connect(lambda _, g=current_gid: self.on_reject(g))
        btn_layout.addWidget(reject_btn)
        
        approve_btn = QPushButton("通过")
        approve_btn.setFixedSize(100, 35)
        approve_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 17px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        if self.on_approve and current_gid is not None:
            approve_btn.clicked.connect(lambda _, g=current_gid: self.on_approve(g))
        btn_layout.addWidget(approve_btn)
        
        layout.addLayout(btn_layout)
        self.setLayout(layout)
    
    def _load_placeholder(self, label):
        """加载占位图"""
        pixmap = QPixmap(100, 100)
        pixmap.fill(QColor(245, 245, 245))
        painter = QPainter(pixmap)
        painter.setPen(QColor(200, 200, 200))
        painter.setFont(QFont("Arial", 30))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "📷")
        painter.end()
        label.setPixmap(pixmap)


class ProductReviewPage(QMainWindow):
    """商品审核页面"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("商品审核 - 闲转")
        self.setGeometry(100, 100, 1200, 800)
        self.setStyleSheet("background-color: #F8F8F8;")
        
        # 使用本地存储（前端测试模式）
        from local_storage import get_pending_goods, audit_goods
        self.get_pending_goods = get_pending_goods
        self.audit_goods = audit_goods
        
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)
        
        # 内容区
        self.create_content()
        main_layout.addWidget(self.content_area)
        
        main_widget.setLayout(main_layout)
        
        # 添加刷新按钮到顶部导航
        self._add_refresh_button()
        
        # 立即加载待审核商品（不在后台线程，直接加载）
        self._load_pending_products_sync()
    
    def _add_refresh_button(self):
        """添加刷新按钮"""
        refresh_btn = QPushButton("🔄 刷新")
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 15px;
                font-size: 14px;
                padding: 5px 15px;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        refresh_btn.clicked.connect(self._load_pending_products_sync)
        # 添加到顶部导航栏
        nav_layout = self.top_nav.layout()
        if nav_layout:
            nav_layout.addWidget(refresh_btn)
    
    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        
        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333;
                border: none;
                font-size: 16px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #F5F5F5;
                border-radius: 5px;
            }
        """)
        back_btn.clicked.connect(self.close)
        layout.addWidget(back_btn)
        
        # 标题
        title_label = QLabel("商品审核")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label, 1)
        
        self.top_nav.setLayout(layout)
    
    def create_content(self):
        """创建内容区"""
        self.content_area = QScrollArea()
        self.content_area.setWidgetResizable(True)
        self.content_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(20, 20, 20, 20)
        scroll_layout.setSpacing(15)
        
        self.review_container = QWidget()
        self.review_layout = QVBoxLayout()
        self.review_layout.setContentsMargins(0, 0, 0, 0)
        self.review_layout.setSpacing(15)
        self.review_container.setLayout(self.review_layout)
        
        scroll_layout.addWidget(self.review_container)
        scroll_layout.addStretch()
        
        scroll_content.setLayout(scroll_layout)
        self.content_area.setWidget(scroll_content)
    
    def load_pending_products(self):
        """加载待审核商品（兼容旧接口）"""
        self._load_pending_products_sync()
    
    def _load_pending_products_sync(self):
        """同步加载待审核商品（从本地存储）"""
        try:
            # 直接获取待审核商品，不做任何ID修复，原样使用
            goods_list = self.get_pending_goods()
            products = []
            for goods in goods_list:
                gid = goods.get('goods_id')
                # 只接受正整数ID，其他直接跳过，避免弹窗出现False
                try:
                    if isinstance(gid, bool):
                        continue
                    gid_int = int(gid)
                    if gid_int <= 0:
                        continue
                except Exception:
                    continue
                products.append({
                    'id': gid_int,
                    'goods_id': gid_int,
                    'title': goods.get('title', ''),
                    'price': goods.get('price', 0),
                    'seller': f"用户{goods.get('user_id', '')}",
                    'category': goods.get('category', ''),
                    'condition': goods.get('condition', ''),
                    'description': goods.get('description', ''),
                    'img_path': goods.get('img_path', ''),
                    'create_time': goods.get('create_time', '')
                })
            self._update_review_list(products)
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"加载待审核商品失败: {e}")
            self._update_review_list([])
    
    def _update_review_list(self, products):
        """更新审核列表UI"""
        # 清空现有卡片
        while self.review_layout.count():
            item = self.review_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        self.pending_products = products  # 保存待审核商品列表
        
        if not products:
            # 显示空状态
            empty_label = QLabel("暂无待审核商品")
            empty_label.setStyleSheet("""
                QLabel {
                    color: #999;
                    font-size: 16px;
                    padding: 40px;
                }
            """)
            empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.review_layout.addWidget(empty_label)
        else:
            # 添加商品卡片
            for product in products:
                card = ReviewCard(
                    product,
                    on_approve=self.approve_product,
                    on_reject=self.reject_product
                )
                self.review_layout.addWidget(card)
    
    def approve_product(self, product_id):
        """通过商品审核"""
        reply = QMessageBox.question(
            self,
            "确认通过",
            f"确定通过商品ID {product_id} 的审核吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            # 在后台线程中发送审核命令
            import threading
            threading.Thread(target=self._approve_product_thread, daemon=True, args=(product_id,)).start()
    
    def _approve_product_thread(self, product_id):
        """在后台线程中通过审核（使用本地存储）"""
        try:
            # 使用本地存储审核商品
            success = self.audit_goods(product_id, 'approved')
            
            if success:
                # 审核成功，刷新列表
                QTimer.singleShot(0, lambda: (
                    self._load_pending_products_sync(),
                    QMessageBox.information(self, "提示", "商品审核已通过，商品已上架！")
                ))
            else:
                QTimer.singleShot(0, lambda: QMessageBox.warning(self, "错误", "审核失败：商品不存在"))
        except Exception as e:
            import traceback
            traceback.print_exc()
            QTimer.singleShot(0, lambda: QMessageBox.warning(self, "错误", f"审核失败: {str(e)}"))
    
    def reject_product(self, product_id):
        """拒绝商品审核"""
        reply = QMessageBox.question(
            self,
            "确认拒绝",
            f"确定拒绝商品ID {product_id} 的审核吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            # 在后台线程中发送审核命令
            import threading
            threading.Thread(target=self._reject_product_thread, daemon=True, args=(product_id,)).start()
    
    def _reject_product_thread(self, product_id):
        """在后台线程中拒绝审核（使用本地存储）"""
        try:
            # 使用本地存储审核商品
            success = self.audit_goods(product_id, 'rejected')
            
            if success:
                # 审核成功，刷新列表
                QTimer.singleShot(0, lambda: (
                    self._load_pending_products_sync(),
                    QMessageBox.information(self, "提示", "商品审核已拒绝！")
                ))
            else:
                QTimer.singleShot(0, lambda: QMessageBox.warning(self, "错误", "审核失败：商品不存在"))
        except Exception as e:
            import traceback
            traceback.print_exc()
            QTimer.singleShot(0, lambda: QMessageBox.warning(self, "错误", f"审核失败: {str(e)}"))
    
    def refresh_review_list(self):
        """刷新审核列表"""
        # 清空现有卡片
        while self.review_layout.count():
            item = self.review_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        # 重新加载
        for product in self.pending_products:
            card = ReviewCard(
                product,
                on_approve=self.approve_product,
                on_reject=self.reject_product
            )
            self.review_layout.addWidget(card)

    # 以上辅助清洗函数全部移除，保持ID原样使用


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ProductReviewPage()
    window.show()
    sys.exit(app.exec())

