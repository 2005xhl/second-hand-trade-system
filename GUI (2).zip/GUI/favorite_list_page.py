"""
收藏列表页面
显示用户收藏的商品，点击进入商品详情页
"""
import sys
import os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QGridLayout)
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor
from local_storage import get_favorites


class FavoriteProductCard(QFrame):
    """收藏商品卡片"""
    clicked = None
    
    def __init__(self, product_data, parent=None):
        super().__init__(parent)
        self.product_data = product_data
        
        self.setFixedSize(200, 280)
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                border: 1px solid #E0E0E0;
            }
            QFrame:hover {
                border: 2px solid #FFA366;
                background-color: #FFF8F5;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # 商品图片
        image_label = QLabel()
        image_label.setFixedSize(180, 180)
        image_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                border-radius: 8px;
            }
        """)
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        img_path = product_data.get("img_path", "")
        if img_path and ',' in str(img_path):
            img_path = str(img_path).split(',')[0].strip()
        if img_path:
            if not os.path.isabs(img_path):
                project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                img_path = os.path.join(project_root, img_path)
            if os.path.exists(img_path):
                pixmap = QPixmap(img_path)
                if not pixmap.isNull():
                    pixmap = pixmap.scaled(180, 180, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                    image_label.setPixmap(pixmap)
                else:
                    self._set_placeholder(image_label)
            else:
                self._set_placeholder(image_label)
        else:
            self._set_placeholder(image_label)
        
        layout.addWidget(image_label)
        
        # 商品标题
        title_label = QLabel(product_data.get("title", "商品标题"))
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        title_label.setWordWrap(True)
        title_label.setMaximumHeight(40)
        layout.addWidget(title_label)
        
        # 价格
        price_label = QLabel(f"¥{product_data.get('price', 0)}")
        price_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(price_label)
        
        layout.addStretch()
        self.setLayout(layout)
    
    def mousePressEvent(self, event):
        """点击事件"""
        if event.button() == Qt.MouseButton.LeftButton and self.clicked:
            self.clicked()

    def _set_placeholder(self, label):
        pixmap = QPixmap(180, 180)
        pixmap.fill(QColor(245, 245, 245))
        painter = QPainter(pixmap)
        painter.setPen(QColor(200, 200, 200))
        painter.setFont(QFont("Arial", 40))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "📷")
        painter.end()
        label.setPixmap(pixmap)

class FavoriteListPage(QMainWindow):
    """收藏列表页面"""
    def __init__(self, parent=None, user_info=None):
        super().__init__(parent)
        self.user_info = user_info or {}
        self.user_id = self.user_info.get('user_id')
        self.setWindowTitle("我的收藏 - 闲转")
        self.setGeometry(100, 100, 1200, 800)
        self.setStyleSheet("background-color: #F8F8F8;")
        
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)
        
        # 商品列表
        self.create_product_list()
        main_layout.addWidget(self.product_list_area)
        
        main_widget.setLayout(main_layout)
        
        # 加载收藏商品
        self.load_favorites()
    
    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        
        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333;
                border: none;
                font-size: 16px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #F5F5F5;
                border-radius: 5px;
            }
        """)
        back_btn.clicked.connect(self.close)
        layout.addWidget(back_btn)
        
        # 标题
        title_label = QLabel("我的收藏")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label, 1)
        
        self.top_nav.setLayout(layout)
    
    def create_product_list(self):
        """创建商品列表"""
        self.product_list_area = QScrollArea()
        self.product_list_area.setWidgetResizable(True)
        self.product_list_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(20, 20, 20, 20)
        scroll_layout.setSpacing(20)
        
        # 商品网格
        self.product_grid = QWidget()
        self.grid_layout = QGridLayout()
        self.grid_layout.setSpacing(15)
        self.grid_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.product_grid.setLayout(self.grid_layout)
        
        scroll_layout.addWidget(self.product_grid)
        scroll_layout.addStretch()
        
        scroll_content.setLayout(scroll_layout)
        self.product_list_area.setWidget(scroll_content)
    
    def load_favorites(self):
        """加载收藏商品"""
        # 清空旧卡片
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        favorites = get_favorites(self.user_id)

        row = 0
        col = 0
        for favorite in favorites:
            card = FavoriteProductCard(favorite)
            product_id = favorite.get("goods_id")
            card.clicked = lambda pid=product_id, data=favorite: self.open_product_detail(pid, data)
            self.grid_layout.addWidget(card, row, col)
            col += 1
            if col >= 5:  # 每行5个
                col = 0
                row += 1
    
    def open_product_detail(self, product_id, product_data):
        """打开商品详情页"""
        from product_detail_page import ProductDetailPage
        detail_window = ProductDetailPage(product_id=product_id, product_data=product_data, user_info=self.user_info)
        detail_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FavoriteListPage()
    window.show()
    sys.exit(app.exec())

