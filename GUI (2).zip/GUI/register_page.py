import tkinter as tk
from tkinter import messagebox
import re
import sys
import os
import json
import threading

# 添加根目录到路径，以便导入 socket_client
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from socket_client import SocketClient


class RegisterPage:
    def __init__(self, root, back_to_login_callback):
        self.root = root
        self.back_to_login = back_to_login_callback
        self.root.title("注册 - 闲转")
        self.root.geometry("600x700")
        self.root.resizable(False, False)

        # 颜色配置（与登录页保持一致）
        self.bg_color = "#FFF8E1"  # 浅黄色
        self.card_color = "#FFFFFF"  # 白色卡片
        self.orange_color = "#FF6B35"  # 橙色
        self.orange_dark = "#E55A2B"  # 深橙色（hover）
        self.gray_color = "#999999"  # 灰色
        self.blue_color = "#1890FF"  # 蓝色
        self.error_color = "#FF4D4F"  # 红色
        self.disabled_color = "#CCCCCC"  # 置灰颜色

        self.root.configure(bg=self.bg_color)

        # 初始化 socket 客户端（用于与服务器通信）
        self.socket_client = SocketClient()
        self.server_ip = "10.129.106.38"
        self.server_port = 8888

        # 输入状态
        self.username_placeholder = True
        self.password_placeholder = True
        self.confirm_password_placeholder = True
        self.agreement_checked = False

        # 创建界面
        self.create_widgets()

        # 绑定回车键
        self.root.bind('<Return>',
                       lambda e: self.submit_register() if self.register_button['state'] == 'normal' else None)

    def create_widgets(self):
        # 主容器（居中布局）
        main_container = tk.Frame(self.root, bg=self.bg_color)
        main_container.pack(fill=tk.BOTH, expand=True)

        # 注册表单区域（居中）
        form_frame = tk.Frame(main_container, bg=self.bg_color)
        form_frame.pack(expand=True, fill=tk.BOTH, padx=50, pady=30)

        # 顶部导航
        top_frame = tk.Frame(form_frame, bg=self.bg_color)
        top_frame.pack(fill=tk.X, pady=(20, 30))

        # 返回登录按钮
        back_button = tk.Label(
            top_frame,
            text="← 返回登录",
            font=("Microsoft YaHei", 12),
            fg=self.gray_color,
            bg=self.bg_color,
            cursor="hand2"
        )
        back_button.pack(side=tk.LEFT)
        back_button.bind('<Button-1>', lambda e: self.back_to_login())

        # 居中标题
        title_label = tk.Label(
            top_frame,
            text="注册新账号",
            font=("Microsoft YaHei", 28, "bold"),
            fg=self.orange_color,
            bg=self.bg_color
        )
        title_label.pack(expand=True)

        # 注册卡片（居中）
        card_frame = tk.Frame(
            form_frame,
            bg=self.card_color,
            relief=tk.FLAT
        )
        card_frame.pack(expand=True, fill=tk.BOTH, pady=(0, 20))

        # 添加阴影效果
        shadow_frame = tk.Frame(
            form_frame,
            bg="#E0E0E0",
            relief=tk.FLAT
        )
        shadow_frame.place(in_=card_frame, x=3, y=3, relwidth=1, relheight=1)
        card_frame.lift()

        # 卡片内容
        card_content = tk.Frame(card_frame, bg=self.card_color)
        card_content.pack(padx=60, pady=50, fill=tk.BOTH, expand=True)

        # 用户名输入区域
        username_frame = tk.Frame(card_content, bg=self.card_color)
        username_frame.pack(pady=(0, 15), fill=tk.X)

        username_icon = tk.Label(
            username_frame,
            text="👤",
            font=("Arial", 16),
            bg=self.card_color,
            fg=self.gray_color
        )
        username_icon.pack(side=tk.LEFT, padx=(0, 10))

        username_input_frame = tk.Frame(username_frame, bg=self.card_color)
        username_input_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.username_entry = tk.Entry(
            username_input_frame,
            font=("Microsoft YaHei", 12),
            relief=tk.FLAT,
            bd=2,
            highlightthickness=1,
            highlightbackground="#E0E0E0",
            highlightcolor=self.orange_color,
            insertbackground=self.orange_color
        )
        self.username_entry.pack(fill=tk.X, ipady=8)
        self.username_entry.insert(0, "请输入用户名")
        self.username_entry.config(fg=self.gray_color)
        self.username_entry.bind('<FocusIn>', self.on_username_focus_in)
        self.username_entry.bind('<FocusOut>', self.on_username_focus_out)
        self.username_entry.bind('<KeyRelease>', lambda e: self.update_register_button_state())

        self.username_error = tk.Label(
            username_input_frame,
            text="",
            font=("Microsoft YaHei", 9),
            fg=self.error_color,
            bg=self.card_color,
            anchor="w"
        )
        self.username_error.pack(fill=tk.X, pady=(3, 0))

        # 设置密码输入区域
        password_frame = tk.Frame(card_content, bg=self.card_color)
        password_frame.pack(pady=(0, 15), fill=tk.X)

        password_icon = tk.Label(
            password_frame,
            text="🔒",
            font=("Arial", 16),
            bg=self.card_color,
            fg=self.gray_color
        )
        password_icon.pack(side=tk.LEFT, padx=(0, 10))

        password_input_frame = tk.Frame(password_frame, bg=self.card_color)
        password_input_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.password_entry = tk.Entry(
            password_input_frame,
            font=("Microsoft YaHei", 12),
            relief=tk.FLAT,
            bd=2,
            show="*",
            highlightthickness=1,
            highlightbackground="#E0E0E0",
            highlightcolor=self.orange_color,
            insertbackground=self.orange_color
        )
        self.password_entry.pack(fill=tk.X, ipady=8)
        self.password_entry.insert(0, "8-16位字母数字组合")
        self.password_entry.config(fg=self.gray_color)
        self.password_entry.bind('<FocusIn>', self.on_password_focus_in)
        self.password_entry.bind('<FocusOut>', self.on_password_focus_out)
        self.password_entry.bind('<KeyRelease>', lambda e: (self.check_password_format(), self.check_password_match()))

        password_hint = tk.Label(
            password_input_frame,
            text="8-16位字母数字组合",
            font=("Microsoft YaHei", 9),
            fg=self.gray_color,
            bg=self.card_color,
            anchor="w"
        )
        password_hint.pack(fill=tk.X, pady=(3, 0))

        self.password_error = tk.Label(
            password_input_frame,
            text="",
            font=("Microsoft YaHei", 9),
            fg=self.error_color,
            bg=self.card_color,
            anchor="w"
        )
        self.password_error.pack(fill=tk.X)

        # 确认密码输入区域
        confirm_password_frame = tk.Frame(card_content, bg=self.card_color)
        confirm_password_frame.pack(pady=(0, 15), fill=tk.X)

        confirm_password_icon = tk.Label(
            confirm_password_frame,
            text="🔒",
            font=("Arial", 16),
            bg=self.card_color,
            fg=self.gray_color
        )
        confirm_password_icon.pack(side=tk.LEFT, padx=(0, 10))

        confirm_password_input_frame = tk.Frame(confirm_password_frame, bg=self.card_color)
        confirm_password_input_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.confirm_password_entry = tk.Entry(
            confirm_password_input_frame,
            font=("Microsoft YaHei", 12),
            relief=tk.FLAT,
            bd=2,
            show="*",
            highlightthickness=1,
            highlightbackground="#E0E0E0",
            highlightcolor=self.orange_color,
            insertbackground=self.orange_color
        )
        self.confirm_password_entry.pack(fill=tk.X, ipady=8)
        self.confirm_password_entry.insert(0, "请再次输入密码")
        self.confirm_password_entry.config(fg=self.gray_color)
        self.confirm_password_entry.bind('<FocusIn>', self.on_confirm_password_focus_in)
        self.confirm_password_entry.bind('<FocusOut>', self.on_confirm_password_focus_out)
        self.confirm_password_entry.bind('<KeyRelease>', lambda e: self.check_password_match())

        self.confirm_password_error = tk.Label(
            confirm_password_input_frame,
            text="",
            font=("Microsoft YaHei", 9),
            fg=self.error_color,
            bg=self.card_color,
            anchor="w"
        )
        self.confirm_password_error.pack(fill=tk.X, pady=(3, 0))

        # 协议区域
        agreement_frame = tk.Frame(card_content, bg=self.card_color)
        agreement_frame.pack(pady=(10, 20), fill=tk.X)

        self.agreement_var = tk.BooleanVar()
        self.agreement_checkbox = tk.Checkbutton(
            agreement_frame,
            text="同意《用户协议》和《隐私政策》",
            font=("Microsoft YaHei", 10),
            fg=self.gray_color,
            bg=self.card_color,
            selectcolor=self.card_color,
            activebackground=self.card_color,
            variable=self.agreement_var,
            command=self.update_register_button_state
        )
        self.agreement_checkbox.pack(anchor="w")

        # 提交按钮
        button_frame = tk.Frame(card_content, bg=self.card_color)
        button_frame.pack(fill=tk.X)

        self.register_button = tk.Button(
            button_frame,
            text="提交注册",
            font=("Microsoft YaHei", 14, "bold"),
            fg="white",
            bg=self.disabled_color,
            relief=tk.FLAT,
            cursor="hand2",
            command=self.submit_register,
            padx=30,
            pady=12,
            state="disabled"
        )
        self.register_button.pack(fill=tk.X)

        # 初始状态检查
        self.update_register_button_state()

    def on_username_focus_in(self, event):
        if self.username_placeholder:
            self.username_entry.delete(0, tk.END)
            self.username_entry.config(fg="black")
            self.username_placeholder = False
        self.username_entry.config(highlightbackground="#E0E0E0")
        self.username_error.config(text="")
        self.update_register_button_state()

    def on_username_focus_out(self, event):
        if not self.username_entry.get():
            self.username_entry.insert(0, "请输入用户名")
            self.username_entry.config(fg=self.gray_color)
            self.username_placeholder = True
        self.update_register_button_state()

    def on_password_focus_in(self, event):
        if self.password_placeholder:
            self.password_entry.delete(0, tk.END)
            self.password_entry.config(fg="black", show="*")
            self.password_placeholder = False
        self.password_entry.config(highlightbackground="#E0E0E0")
        self.password_error.config(text="")
        self.update_register_button_state()

    def on_password_focus_out(self, event):
        if not self.password_entry.get():
            self.password_entry.insert(0, "8-16位字母数字组合")
            self.password_entry.config(fg=self.gray_color, show="")
            self.password_placeholder = True
        self.update_register_button_state()

    def on_confirm_password_focus_in(self, event):
        if self.confirm_password_placeholder:
            self.confirm_password_entry.delete(0, tk.END)
            self.confirm_password_entry.config(fg="black", show="*")
            self.confirm_password_placeholder = False
        self.confirm_password_entry.config(highlightbackground="#E0E0E0")
        self.confirm_password_error.config(text="")
        self.update_register_button_state()

    def on_confirm_password_focus_out(self, event):
        if not self.confirm_password_entry.get():
            self.confirm_password_entry.insert(0, "请再次输入密码")
            self.confirm_password_entry.config(fg=self.gray_color, show="")
            self.confirm_password_placeholder = True
        self.update_register_button_state()

    def check_username_availability(self, event=None):
        """检查用户名格式（仅本地验证，不查询服务器）"""
        username = self.username_entry.get()

        if self.username_placeholder or not username:
            self.username_error.config(text="")
            self.username_entry.config(highlightbackground="#E0E0E0")
            self.update_register_button_state()
            return

        # 只做本地格式验证，不查询服务器
        # 用户名唯一性检查将在提交注册时由服务器返回
        self.username_error.config(text="")
        self.username_entry.config(highlightbackground="#E0E0E0")
        self.update_register_button_state()
    
    def _show_username_error(self, error_msg):
        """显示用户名错误（在主线程中调用）"""
        self.username_error.config(text=error_msg)
        self.username_entry.config(highlightbackground=self.error_color)
        self.register_button.config(state="normal")
        messagebox.showerror("注册失败", error_msg)
    
    def _show_register_error(self, error_msg):
        """显示注册错误（在主线程中调用）"""
        self.register_button.config(state="normal")
        messagebox.showerror("注册失败", error_msg)

    def check_password_format(self):
        """检查密码格式"""
        password = self.password_entry.get()

        if self.password_placeholder or not password:
            self.password_error.config(text="")
            self.password_entry.config(highlightbackground="#E0E0E0")
            return

        if not self.validate_password_format(password):
            self.password_error.config(text="密码格式不正确，请输入8-16位字母数字组合")
            self.password_entry.config(highlightbackground=self.error_color)
        else:
            self.password_error.config(text="")
            self.password_entry.config(highlightbackground="#E0E0E0")

        self.update_register_button_state()

    def check_password_match(self, event=None):
        password = self.password_entry.get()
        confirm_password = self.confirm_password_entry.get()

        # 如果密码或确认密码还在占位符状态，不检查
        if self.password_placeholder or self.confirm_password_placeholder:
            self.confirm_password_error.config(text="")
            self.confirm_password_entry.config(highlightbackground="#E0E0E0")
            self.update_register_button_state()
            return

        # 实时对比密码
        if confirm_password and password != confirm_password:
            self.confirm_password_error.config(text="两次密码不一致")
            self.confirm_password_entry.config(highlightbackground=self.error_color)
        else:
            self.confirm_password_error.config(text="")
            self.confirm_password_entry.config(highlightbackground="#E0E0E0")

        self.update_register_button_state()

    def validate_password_format(self, password):
        """验证密码格式：8-16位字母数字组合"""
        if len(password) < 8 or len(password) > 16:
            return False
        if not re.match(r'^[a-zA-Z0-9]+$', password):
            return False
        return True

    def update_register_button_state(self):
        """更新注册按钮状态"""
        username = self.username_entry.get()
        password = self.password_entry.get()
        confirm_password = self.confirm_password_entry.get()

        # 检查所有必填项是否已填写
        all_filled = (
                not self.username_placeholder and username and
                not self.password_placeholder and password and
                not self.confirm_password_placeholder and confirm_password and
                self.agreement_var.get()
        )

        # 检查是否有错误
        has_error = (
                self.username_error.cget("text") != "" or
                self.confirm_password_error.cget("text") != ""
        )

        # 检查密码格式
        password_valid = True
        if not self.password_placeholder and password:
            password_valid = self.validate_password_format(password)

        # 检查密码是否匹配
        password_match = True
        if (not self.password_placeholder and not self.confirm_password_placeholder and
                password and confirm_password):
            password_match = (password == confirm_password)

        # 如果所有条件满足，启用按钮
        if all_filled and not has_error and password_valid and password_match:
            self.register_button.config(state="normal", bg=self.orange_color)
            self.register_button.bind('<Enter>', lambda e: self.register_button.config(bg=self.orange_dark))
            self.register_button.bind('<Leave>', lambda e: self.register_button.config(bg=self.orange_color))
        else:
            self.register_button.config(state="disabled", bg=self.disabled_color)
            self.register_button.unbind('<Enter>')
            self.register_button.unbind('<Leave>')

    def submit_register(self):
        """提交注册"""
        if self.register_button['state'] == 'disabled':
            return

        username = self.username_entry.get()
        password = self.password_entry.get()
        confirm_password = self.confirm_password_entry.get()

        # 最终验证
        if not self.agreement_var.get():
            messagebox.showwarning("提示", "请阅读并同意协议")
            return

        # 用户名唯一性检查会在实时检查中完成，这里不再重复检查

        if not self.validate_password_format(password):
            messagebox.showerror("错误", "密码格式不正确，请输入8-16位字母数字组合")
            return

        if password != confirm_password:
            messagebox.showerror("错误", "两次密码不一致")
            return

        # 禁用注册按钮，防止重复提交
        self.register_button.config(state="disabled")
        
        # 通过 socket 发送注册信息到服务器
        def send_register_request():
            try:
                # 连接服务器
                connect_result = self.socket_client.connect(self.server_ip, self.server_port)
                if not connect_result.startswith("连接成功") and connect_result != "已连接":
                    self.root.after(0, lambda: messagebox.showerror("错误", f"无法连接到服务器: {connect_result}"))
                    self.root.after(0, lambda: self.register_button.config(state="normal"))
                    return
                
                # 准备注册数据
                register_data = {
                    "username": username,
                    "password": password,
                    "nickname": "新用户",
                    "phone": None,
                    "role": "normal"
                }
                
                # 发送 REGISTER 命令
                response = self.socket_client.send_command("REGISTER", register_data)
                
                # 解析服务器响应
                if "|" in response:
                    cmd, resp_body = response.split("|", 1)
                    try:
                        resp_data = json.loads(resp_body)
                        code = resp_data.get("code", 500)
                        msg = resp_data.get("msg", "未知错误")
                        user_info = resp_data.get("user_info", {})
                        
                        if code == 200:
                            # 注册成功，返回用户信息
                            self.root.after(0, lambda: self.show_success_dialog(user_info))
                        elif code == 401:
                            # 用户名已存在或其他参数错误
                            self.root.after(0, lambda: self._show_username_error(msg))
                        elif code == 403:
                            # 账号被封禁（注册时不太可能，但处理一下）
                            self.root.after(0, lambda: self._show_register_error(msg))
                        else:
                            # 其他注册失败
                            self.root.after(0, lambda: self._show_register_error(msg))
                    except json.JSONDecodeError:
                        self.root.after(0, lambda: messagebox.showerror("错误", f"服务器响应格式错误: {response}"))
                        self.root.after(0, lambda: self.register_button.config(state="normal"))
                else:
                    self.root.after(0, lambda: messagebox.showerror("错误", f"服务器响应异常: {response}"))
                    self.root.after(0, lambda: self.register_button.config(state="normal"))
                
                # 关闭连接
                self.socket_client.close()
                
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("错误", f"注册失败: {e}"))
                self.root.after(0, lambda: self.register_button.config(state="normal"))
                if self.socket_client:
                    self.socket_client.close()
        
        # 在后台线程中发送请求，避免阻塞UI
        threading.Thread(target=send_register_request, daemon=True).start()

    def show_success_dialog(self, user_info=None):
        """显示注册成功弹窗并倒计时"""
        dialog = tk.Toplevel(self.root)
        dialog.title("注册成功")
        dialog.geometry("400x200")
        dialog.resizable(False, False)
        dialog.configure(bg="white")
        dialog.transient(self.root)
        dialog.grab_set()

        # 居中显示
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 200
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 100
        dialog.geometry(f"400x200+{x}+{y}")

        # 成功图标
        success_icon = tk.Label(
            dialog,
            text="✓",
            font=("Arial", 48, "bold"),
            fg="#52C41A",
            bg="white"
        )
        success_icon.pack(pady=(20, 10))

        # 成功文字（如果有用户信息，可以显示用户名）
        success_text = "注册成功！3秒后跳转到登录页"
        if user_info and user_info.get("username"):
            success_text = f"注册成功！欢迎 {user_info.get('username')}\n3秒后跳转到登录页"
        
        self.countdown_label = tk.Label(
            dialog,
            text=success_text,
            font=("Microsoft YaHei", 14),
            fg="#333333",
            bg="white"
        )
        self.countdown_label.pack()

        # 倒计时
        self.countdown = 3
        self.update_countdown(dialog, user_info)

    def update_countdown(self, dialog, user_info=None):
        """更新倒计时"""
        if self.countdown > 0:
            if user_info and user_info.get("username"):
                self.countdown_label.config(text=f"注册成功！欢迎 {user_info.get('username')}\n{self.countdown}秒后跳转到登录页")
            else:
                self.countdown_label.config(text=f"注册成功！{self.countdown}秒后跳转到登录页")
            self.countdown -= 1
            dialog.after(1000, lambda: self.update_countdown(dialog, user_info))
        else:
            dialog.destroy()
            self.back_to_login()

    def close_window(self):
        """关闭窗口"""
        if hasattr(self.root, 'quit'):
            self.root.quit()


def main():
    """注册页面独立运行入口"""
    root = tk.Tk()
    root.geometry("600x700")

    def back_to_login():
        root.destroy()
        # 可以在这里打开登录页面
        from login_page import LoginPage
        login_root = tk.Tk()
        LoginPage(login_root)
        login_root.mainloop()

    app = RegisterPage(root, back_to_login)
    root.mainloop()


if __name__ == "__main__":
    main()

