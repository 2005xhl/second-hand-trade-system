import sys
import os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QLineEdit, QPushButton,
                             QScrollArea, QFrame, QSlider, QButtonGroup,
                             QMenu, QGraphicsDropShadowEffect, QSizePolicy)
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer, pyqtSignal, QPoint, QRect
from PyQt6.QtGui import QFont, QPixmap, QIcon, QPainter, QColor, QLinearGradient
import random
import time
from datetime import datetime, timedelta


class OrangeButton(QPushButton):
    """橙色主题按钮，hover时变大"""

    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.original_size = None
        self.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 20px;
                padding: 8px 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
            QPushButton:pressed {
                background-color: #FF8C4D;
            }
        """)

    def enterEvent(self, event):
        """鼠标进入时变大"""
        if self.original_size is None:
            self.original_size = self.size()
        self.animation = QPropertyAnimation(self, b"geometry")
        self.animation.setDuration(200)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        new_width = int(self.original_size.width() * 1.1)
        new_height = int(self.original_size.height() * 1.1)
        self.animation.setStartValue(self.geometry())
        self.animation.setEndValue(self.geometry().adjusted(
            -(new_width - self.width()) // 2,
            -(new_height - self.height()) // 2,
            (new_width - self.width()) // 2,
            (new_height - self.height()) // 2
        ))
        self.animation.start()
        super().enterEvent(event)

    def leaveEvent(self, event):
        """鼠标离开时恢复"""
        if self.original_size:
            self.animation = QPropertyAnimation(self, b"geometry")
            self.animation.setDuration(200)
            self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
            self.animation.setStartValue(self.geometry())
            self.animation.setEndValue(self.geometry().adjusted(
                (self.width() - self.original_size.width()) // 2,
                (self.height() - self.original_size.height()) // 2,
                -(self.width() - self.original_size.width()) // 2,
                -(self.height() - self.original_size.height()) // 2
            ))
            self.animation.start()
        super().leaveEvent(event)


class CategoryButton(QPushButton):
    """分类按钮，选中时显示橙色下划线"""

    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.is_selected = False
        self.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333;
                border: none;
                padding: 10px 15px;
                font-size: 15px;
            }
            QPushButton:hover {
                color: #FFA366;
            }
        """)

    def set_selected(self, selected):
        self.is_selected = selected
        if selected:
            self.setStyleSheet("""
                QPushButton {
                    background-color: transparent;
                    color: #FFA366;
                    border: none;
                    border-bottom: 3px solid #FFA366;
                    padding: 10px 15px;
                    font-size: 15px;
                    font-weight: bold;
                }
            """)
        else:
            self.setStyleSheet("""
                QPushButton {
                    background-color: transparent;
                    color: #333;
                    border: none;
                    padding: 10px 15px;
                    font-size: 15px;
                }
                QPushButton:hover {
                    color: #FFA366;
                }
            """)


class ProductCard(QFrame):
    """商品卡片"""
    clicked = pyqtSignal(object)  # 允许字符串/数字ID都能传递

    def __init__(self, product_id, title, price, image_path, days_ago, seller, likes, parent=None):
        super().__init__(parent)
        self.product_id = product_id
        self.setFixedSize(280, 380)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)  # 固定大小策略
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                border: 1px solid #F0F0F0;
            }
        """)

        # 添加阴影效果
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(10)
        shadow.setColor(QColor(0, 0, 0, 30))
        shadow.setOffset(0, 2)
        self.setGraphicsEffect(shadow)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 商品图片（占2/3）
        image_label = QLabel()
        image_label.setFixedHeight(250)
        image_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                border-top-left-radius: 12px;
                border-top-right-radius: 12px;
                border: none;
            }
        """)

        # 使用占位图或实际图片
        if image_path and image_path != "":
            # 处理多个图片路径（用逗号分隔）
            if ',' in str(image_path):
                image_path = str(image_path).split(',')[0].strip()

            # 处理相对路径：如果是相对路径，转换为绝对路径
            if not os.path.isabs(image_path):
                # 获取项目根目录
                project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                image_path = os.path.join(project_root, image_path).replace("\\", "/")

            # 检查文件是否存在
            if os.path.exists(image_path):
                pixmap = QPixmap(image_path)
                if not pixmap.isNull():
                    pixmap = pixmap.scaled(280, 250, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                                           Qt.TransformationMode.SmoothTransformation)
                    image_label.setPixmap(pixmap)
                else:
                    # 图片加载失败，生成占位图
                    self._load_placeholder_image(image_label)
            else:
                # 文件不存在，生成占位图
                self._load_placeholder_image(image_label)
        else:
            # 没有图片路径，生成占位图
            self._load_placeholder_image(image_label)

        layout.addWidget(image_label)

        # 商品标题
        title_label = QLabel(title)
        title_label.setStyleSheet("""
            QLabel {
                color: #666;
                font-size: 14px;
                padding: 8px 12px;
                background-color: white;
            }
        """)
        title_label.setWordWrap(False)
        title_label.setFixedHeight(40)
        # 文本省略
        metrics = title_label.fontMetrics()
        elided_text = metrics.elidedText(title, Qt.TextElideMode.ElideRight, 260)
        title_label.setText(elided_text)
        layout.addWidget(title_label)

        # 底部信息栏
        bottom_layout = QHBoxLayout()
        bottom_layout.setContentsMargins(12, 0, 12, 12)

        # 价格（橙色）
        price_label = QLabel(f"¥{price}")
        price_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        bottom_layout.addWidget(price_label)

        bottom_layout.addStretch()

        # 右侧信息
        right_info = QVBoxLayout()
        right_info.setSpacing(2)

        days_label = QLabel(f"发布于{days_ago}天前")
        days_label.setStyleSheet("""
            QLabel {
                color: #999;
                font-size: 11px;
            }
        """)
        right_info.addWidget(days_label)

        seller_layout = QHBoxLayout()
        seller_label = QLabel(seller)
        seller_label.setStyleSheet("""
            QLabel {
                color: #999;
                font-size: 11px;
            }
        """)
        seller_layout.addWidget(seller_label)
        seller_layout.addStretch()
        right_info.addLayout(seller_layout)

        bottom_layout.addLayout(right_info)
        layout.addLayout(bottom_layout)

        self.setLayout(layout)

        # 点击事件
        self.mousePressEvent = self.on_click

    def on_click(self, event):
        # 直接发出点击信号，避免卡片位置被动画挤动
        self.clicked.emit(self.product_id)

    def enterEvent(self, event):
        """鼠标进入时加深阴影"""
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 50))
        shadow.setOffset(0, 4)
        self.setGraphicsEffect(shadow)
        super().enterEvent(event)

    def leaveEvent(self, event):
        """鼠标离开时恢复"""
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(10)
        shadow.setColor(QColor(0, 0, 0, 30))
        shadow.setOffset(0, 2)
        self.setGraphicsEffect(shadow)
        super().leaveEvent(event)

    def _load_placeholder_image(self, label):
        """加载占位图"""
        pixmap = QPixmap(280, 250)
        pixmap.fill(QColor(240, 240, 240))
        painter = QPainter(pixmap)
        painter.setPen(QColor(200, 200, 200))
        painter.setFont(QFont("Arial", 16))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "商品图片")
        painter.end()
        label.setPixmap(pixmap)


class MainWindow(QMainWindow):
    def __init__(self, user_info=None):
        super().__init__()
        self.setWindowTitle("闲转 - 商品列表")
        self.setGeometry(100, 100, 1400, 900)
        self.setStyleSheet("background-color: #F8F8F8;")

        # 保存登录时的用户信息（包括username）
        self.user_info = user_info or {}

        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)

        # 筛选区
        self.create_filter_section()
        main_layout.addWidget(self.filter_section)

        # 商品流区域
        self.create_product_area()
        main_layout.addWidget(self.product_area)

        # 底部导航栏
        self.create_bottom_nav()
        main_layout.addWidget(self.bottom_nav)

        main_widget.setLayout(main_layout)

        # 初始化数据
        self.current_category = "全部"
        self.current_sort = "综合"
        self.price_range = (0, 99999)  # 增大默认最大值，确保能显示所有商品
        self.condition = "全部"
        self.products = []
        self.load_products()

        # 底部导航当前页面
        self.current_page = "首页"

        # 保存打开的窗口引用，防止被垃圾回收
        self.publish_window = None

    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(120)
        self.top_nav.setStyleSheet("background-color: white; border-bottom: 1px solid #E0E0E0;")

        nav_layout = QHBoxLayout()
        nav_layout.setContentsMargins(20, 10, 20, 10)

        # 左侧Logo
        logo = QLabel("闲转")
        logo.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 28px;
                font-weight: bold;
            }
        """)
        nav_layout.addWidget(logo)

        # 分类栏
        categories_layout = QHBoxLayout()
        categories_layout.setSpacing(0)
        self.category_buttons = []
        self.category_group = QButtonGroup()

        categories = ["全部", "数码", "服饰", "图书", "家居", "其他"]
        for i, cat in enumerate(categories):
            btn = CategoryButton(cat)
            if i == 0:
                btn.set_selected(True)
            btn.clicked.connect(lambda checked, c=cat: self.on_category_clicked(c))
            self.category_buttons.append(btn)
            self.category_group.addButton(btn, i)
            categories_layout.addWidget(btn)

        nav_layout.addLayout(categories_layout)
        nav_layout.addStretch()

        # 搜索框
        search_layout = QHBoxLayout()
        search_layout.setSpacing(0)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("搜你想要的")
        self.search_input.setFixedWidth(300)
        self.search_input.setFixedHeight(40)
        self.search_input.setStyleSheet("""
            QLineEdit {
                border: 2px solid #E0E0E0;
                border-radius: 20px;
                padding: 0 15px;
                font-size: 14px;
                background-color: white;
            }
            QLineEdit:focus {
                border: 2px solid #FFA366;
            }
        """)
        search_layout.addWidget(self.search_input)

        search_btn = QPushButton("🔍")
        search_btn.setFixedSize(40, 40)
        search_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 18px;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        search_btn.clicked.connect(self.on_search)
        search_layout.addWidget(search_btn)

        # 刷新按钮
        refresh_btn = QPushButton("刷新")
        refresh_btn.setFixedHeight(40)
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                color: #666;
                border: 1px solid #E0E0E0;
                border-radius: 10px;
                font-size: 14px;
                padding: 0 12px;
            }
            QPushButton:hover {
                background-color: #EDEDED;
            }
        """)
        refresh_btn.clicked.connect(lambda: self.load_products())
        search_layout.addWidget(refresh_btn)

        nav_layout.addLayout(search_layout)

        # 发布按钮
        publish_btn = OrangeButton("+ 发布宝贝")
        publish_btn.setFixedHeight(40)
        publish_btn.clicked.connect(self.open_publish_page)
        nav_layout.addWidget(publish_btn)

        nav_layout.addSpacing(20)

        # 消息图标（带角标）
        class MessageButton(QWidget):
            def __init__(self, parent_window=None):
                super().__init__()
                self.parent_window = parent_window
                self.setFixedSize(40, 40)
                layout = QHBoxLayout()
                layout.setContentsMargins(0, 0, 0, 0)

                self.btn = QPushButton("🔔")
                self.btn.setFixedSize(40, 40)
                self.btn.setStyleSheet("""
                    QPushButton {
                        background-color: transparent;
                        border: none;
                        font-size: 20px;
                    }
                    QPushButton:hover {
                        background-color: #F5F5F5;
                        border-radius: 20px;
                    }
                """)
                # 添加点击事件
                self.btn.clicked.connect(self.on_message_clicked)
                layout.addWidget(self.btn)
                self.setLayout(layout)

                # 红色角标
                self.badge = QLabel("3", self)
                self.badge.setFixedSize(18, 18)
                self.badge.setStyleSheet("""
                    QLabel {
                        background-color: #FF4444;
                        color: white;
                        border-radius: 9px;
                        font-size: 10px;
                        font-weight: bold;
                    }
                """)
                self.badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
                self.badge.move(25, 0)  # 右上角位置

            def on_message_clicked(self):
                """消息按钮点击事件"""
                try:
                    from message_list_page import MessageListPage
                    message_window = MessageListPage(self.parent_window)
                    message_window.show()
                except Exception as e:
                    from PyQt6.QtWidgets import QMessageBox
                    QMessageBox.warning(self, "错误", f"打开消息列表失败: {str(e)}")

        msg_widget = MessageButton(self)
        nav_layout.addWidget(msg_widget)

        # 用户头像
        avatar_btn = QPushButton("👤")
        avatar_btn.setFixedSize(40, 40)
        avatar_btn.setStyleSheet("""
            QPushButton {
                background-color: #E0E0E0;
                border: none;
                border-radius: 20px;
                font-size: 20px;
            }
            QPushButton:hover {
                background-color: #D0D0D0;
            }
        """)

        # 用户头像按钮 - 点击打开个人中心
        # 注意：如果设置了菜单，clicked信号可能不会触发，所以使用菜单项
        user_menu = QMenu(self)
        my_action = user_menu.addAction("我的")
        my_action.triggered.connect(lambda: self.navigate_to_page("profile"))
        exit_action = user_menu.addAction("退出")
        exit_action.triggered.connect(self.close)
        avatar_btn.setMenu(user_menu)
        # 也尝试直接点击（如果菜单不显示时）
        avatar_btn.clicked.connect(lambda: self.navigate_to_page("profile"))
        nav_layout.addWidget(avatar_btn)

        self.top_nav.setLayout(nav_layout)

    def create_filter_section(self):
        """创建筛选区"""
        self.filter_section = QFrame()
        self.filter_section.setFixedHeight(80)
        self.filter_section.setStyleSheet("background-color: white; border-bottom: 1px solid #E0E0E0;")

        filter_layout = QHBoxLayout()
        filter_layout.setContentsMargins(20, 10, 20, 10)

        # 左侧筛选
        left_filter = QHBoxLayout()
        left_filter.setSpacing(20)

        # 价格区间输入
        price_label = QLabel("价格：")
        price_label.setStyleSheet("color: #666; font-size: 14px;")
        left_filter.addWidget(price_label)

        # 最低价格输入框
        self.price_min_input = QLineEdit()
        self.price_min_input.setPlaceholderText("最低")
        self.price_min_input.setFixedWidth(80)
        self.price_min_input.setFixedHeight(30)
        self.price_min_input.setStyleSheet("""
            QLineEdit {
                border: 1px solid #E0E0E0;
                border-radius: 4px;
                padding: 0 8px;
                font-size: 13px;
            }
            QLineEdit:focus {
                border: 1px solid #FFA366;
            }
        """)
        self.price_min_input.textChanged.connect(self.on_price_input_changed)
        left_filter.addWidget(self.price_min_input)

        # 分隔符
        price_sep = QLabel("-")
        price_sep.setStyleSheet("color: #666; font-size: 14px;")
        left_filter.addWidget(price_sep)

        # 最高价格输入框
        self.price_max_input = QLineEdit()
        self.price_max_input.setPlaceholderText("最高")
        self.price_max_input.setFixedWidth(80)
        self.price_max_input.setFixedHeight(30)
        self.price_max_input.setStyleSheet(self.price_min_input.styleSheet())
        self.price_max_input.textChanged.connect(self.on_price_input_changed)
        left_filter.addWidget(self.price_max_input)

        # 成色选项
        condition_label = QLabel("成色：")
        condition_label.setStyleSheet("color: #666; font-size: 14px;")
        left_filter.addWidget(condition_label)

        self.condition_buttons = []
        conditions = ["全部", "全新", "99新", "95新", "9成新", "8成新", "其他"]
        for cond in conditions:
            btn = QPushButton(cond)
            btn.setCheckable(True)
            btn.setFixedHeight(30)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #F5F5F5;
                    color: #666;
                    border: none;
                    border-radius: 15px;
                    padding: 5px 15px;
                    font-size: 13px;
                }
                QPushButton:checked {
                    background-color: #FFA366;
                    color: white;
                }
                QPushButton:hover {
                    background-color: #FFE5DD;
                }
            """)
            if cond == "全部":
                btn.setChecked(True)
            btn.clicked.connect(lambda checked, c=cond: self.on_condition_changed(c))
            self.condition_buttons.append(btn)
            left_filter.addWidget(btn)

        filter_layout.addLayout(left_filter)
        filter_layout.addStretch()

        # 右侧排序
        sort_label = QLabel("排序：")
        sort_label.setStyleSheet("color: #666; font-size: 14px;")
        filter_layout.addWidget(sort_label)

        self.sort_buttons = []
        sorts = ["综合", "最新发布", "价格低→高", "价格高→低"]
        for sort in sorts:
            btn = QPushButton(sort)
            btn.setCheckable(True)
            btn.setFixedHeight(30)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: transparent;
                    color: #666;
                    border: 1px solid #E0E0E0;
                    border-radius: 15px;
                    padding: 5px 15px;
                    font-size: 13px;
                }
                QPushButton:checked {
                    background-color: #FFA366;
                    color: white;
                    border: 1px solid #FFA366;
                }
                QPushButton:hover {
                    border: 1px solid #FFA366;
                    color: #FFA366;
                }
            """)
            if sort == "综合":
                btn.setChecked(True)
            btn.clicked.connect(lambda checked, s=sort: self.on_sort_changed(s))
            self.sort_buttons.append(btn)
            filter_layout.addWidget(btn)

        self.filter_section.setLayout(filter_layout)

    def create_product_area(self):
        """创建商品流区域"""
        self.product_area = QScrollArea()
        self.product_area.setWidgetResizable(True)
        self.product_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)

        self.product_widget = QWidget()
        self.product_layout = QVBoxLayout()
        self.product_layout.setContentsMargins(20, 20, 20, 20)
        self.product_layout.setSpacing(20)

        # 商品网格容器
        self.product_grid = QWidget()
        self.product_grid.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        self.grid_layout = QVBoxLayout()
        self.grid_layout.setContentsMargins(0, 0, 0, 0)
        self.grid_layout.setSpacing(20)
        self.grid_layout.setAlignment(Qt.AlignmentFlag.AlignTop)  # 顶部对齐

        self.product_grid.setLayout(self.grid_layout)
        self.product_layout.addWidget(self.product_grid)
        self.product_layout.addStretch()

        self.product_widget.setLayout(self.product_layout)
        self.product_area.setWidget(self.product_widget)

        # 加载提示
        self.loading_label = QLabel("正在加载...")
        self.loading_label.setStyleSheet("""
            QLabel {
                color: #999;
                font-size: 14px;
                padding: 20px;
            }
        """)
        self.loading_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.loading_label.hide()
        self.product_layout.insertWidget(0, self.loading_label)

        # 滚动到底部检测
        self.product_area.verticalScrollBar().valueChanged.connect(self.on_scroll)

    def create_bottom_nav(self):
        """创建底部导航栏"""
        self.bottom_nav = QFrame()
        self.bottom_nav.setFixedHeight(60)
        self.bottom_nav.setStyleSheet("""
            QFrame {
                background-color: #F5F5F5;
                border-top: 1px solid #E0E0E0;
            }
        """)

        nav_layout = QHBoxLayout()
        nav_layout.setContentsMargins(0, 0, 0, 0)

        nav_items = [
            ("🏠", "首页", "main"),
            ("💬", "消息", "chat"),
            ("➕", "发布", "publish"),
            ("👤", "我的", "profile"),
            ("📊", "数据看板", "dashboard")
        ]

        self.nav_buttons = []
        for icon, text, page_name in nav_items:
            # 创建可点击的容器
            nav_item_widget = QWidget()
            nav_item_widget.setCursor(Qt.CursorShape.PointingHandCursor)
            item_layout = QVBoxLayout()
            item_layout.setContentsMargins(10, 5, 10, 5)
            item_layout.setSpacing(2)
            item_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

            icon_label = QLabel(icon)
            icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            is_active = (page_name == "main")
            icon_label.setStyleSheet(f"""
                QLabel {{
                    font-size: 24px;
                    color: {'#FFA366' if is_active else '#999'};
                }}
            """)
            item_layout.addWidget(icon_label)

            text_label = QLabel(text)
            text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            text_label.setStyleSheet(f"""
                QLabel {{
                    font-size: 11px;
                    color: {'#FFA366' if is_active else '#999'};
                }}
            """)
            item_layout.addWidget(text_label)

            nav_item_widget.setLayout(item_layout)

            # 添加点击事件
            def make_click_handler(pn):
                def handler(event):
                    if event.button() == Qt.MouseButton.LeftButton:
                        print(f"点击了导航项: {pn}")  # 调试信息
                        self.navigate_to_page(pn)

                return handler

            nav_item_widget.mousePressEvent = make_click_handler(page_name)
            self.nav_buttons.append((nav_item_widget, icon_label, text_label, page_name))
            nav_layout.addWidget(nav_item_widget)

        nav_layout.addStretch()
        self.bottom_nav.setLayout(nav_layout)

    def load_products(self, append=False):
        """加载商品数据"""
        if not append:
            self.products = []
            # 清空现有商品（同时清理子布局，避免残留导致重复渲染）
            self._clear_grid_layout()

            # 确保价格范围已更新（从输入框读取）
            try:
                min_price_text = self.price_min_input.text().strip()
                max_price_text = self.price_max_input.text().strip()
                min_price = int(min_price_text) if min_price_text else 0
                max_price = int(max_price_text) if max_price_text else 99999
                if min_price <= max_price:
                    self.price_range = (min_price, max_price)
            except ValueError:
                pass  # 如果输入无效，使用默认值

        # 显示加载提示
        self.loading_label.show()

        # 模拟加载延迟
        QTimer.singleShot(500, lambda: self._render_products(append))

    def _render_products(self, append=False):
        """渲染商品卡片"""
        # 如果不是追加模式，清空现有商品列表
        if not append:
            self.products = []

        # 确保价格范围已更新（从输入框读取）
        try:
            min_price_text = self.price_min_input.text().strip()
            max_price_text = self.price_max_input.text().strip()
            min_price = int(min_price_text) if min_price_text else 0
            max_price = int(max_price_text) if max_price_text else 99999
            if min_price <= max_price:
                self.price_range = (min_price, max_price)
        except ValueError:
            self.price_range = (0, 99999)

        # 从本地存储加载已审核通过的商品
        try:
            from local_storage import get_approved_goods
            approved_goods = get_approved_goods()

            print(f"[DEBUG] 从本地存储加载到 {len(approved_goods)} 个已审核商品")

            # 使用集合记录已添加的商品ID，避免重复
            added_keys = set()
            existing_ids = set()
            added_goods_ids = set()

            # 转换已审核商品为前端格式，并应用筛选
            for goods in approved_goods:
                # 兜底商品ID，避免 None/空字符串导致所有卡片同一个ID
                raw_goods_id = goods.get('goods_id') or goods.get('id') or goods.get('uid')
                if raw_goods_id in (None, "", "None", "null"):
                    raw_goods_id = f"auto_{len(self.products) + 1}_{int(time.time() * 1000)}"
                goods_id = str(raw_goods_id)
                # 如果ID已存在，则跳过，避免重复和点击错位
                if goods_id in added_goods_ids:
                    print(f"[DEBUG] 跳过重复ID商品: {goods_id}")
                    continue
                added_goods_ids.add(goods_id)
                existing_ids.add(goods_id)

                # 跳过已卖出/已下架商品
                if goods.get('status') in ('sold', 'off'):
                    continue

                create_time = goods.get('create_time', '')
                # 计算发布时间（天数）
                try:
                    from datetime import datetime
                    if create_time:
                        create_date = datetime.strptime(create_time, '%Y-%m-%d %H:%M:%S')
                        days_ago = (datetime.now() - create_date).days
                    else:
                        days_ago = 0
                except:
                    days_ago = 0

                # 获取图片路径（处理多张图片）
                img_path = goods.get('img_path', '')
                images_list = []
                if img_path:
                    parts = [p.strip() for p in str(img_path).split(',') if p.strip()]
                    if parts:
                        images_list = parts
                        img_path = parts[0]

                # 根据分类筛选
                goods_category = goods.get('category', '')
                if self.current_category != "全部":
                    if goods_category != self.current_category:
                        continue

                # 价格筛选
                price = float(goods.get('price', 0))
                if price < self.price_range[0] or price > self.price_range[1]:
                    continue

                # 成色筛选
                condition = goods.get('condition', '')
                if self.condition != "全部" and condition != self.condition:
                    continue

                product = {
                    'id': goods_id,
                    'title': goods.get('title', ''),
                    'price': price,
                    'image': img_path,
                    'images': images_list,
                    'days_ago': days_ago,
                    'seller': f"用户{goods.get('user_id', '')}",
                    'likes': 0,
                    'category': goods_category,
                    'condition': condition,
                    'description': goods.get('description', ''),
                    'create_time': create_time  # 保存创建时间用于去重
                }
                self.products.append(product)
                added_keys.add((goods_id, create_time))
                print(f"[DEBUG] 添加商品: id={goods_id}, title={goods.get('title')}, price={price}")

            print(f"[DEBUG] 总共添加了 {len(self.products)} 个已审核商品")

            # 排序（在所有筛选完成后）
            self._sort_products()

            # 隐藏加载提示（如果是自动刷新，可能没有显示加载提示）
            if self.loading_label.isVisible():
                self.loading_label.hide()

            # 渲染商品网格
            self._render_product_grid()

        except Exception as e:
            print(f"[ERROR] 加载已审核商品失败: {e}")
            import traceback
            traceback.print_exc()

    def _sort_products(self):
        """对商品列表进行排序"""
        if self.current_sort == "价格低→高":
            self.products.sort(key=lambda x: x.get('price', 0))
        elif self.current_sort == "价格高→低":
            self.products.sort(key=lambda x: x.get('price', 0), reverse=True)
        elif self.current_sort == "最新发布":
            self.products.sort(key=lambda x: x.get('days_ago', 0))
        # "综合"排序保持原顺序

    def _render_product_grid(self):
        """渲染商品网格（每行4个）"""
        row_layout = None
        for idx, product in enumerate(self.products):
            if idx % 4 == 0:
                row_layout = QHBoxLayout()
                row_layout.setSpacing(15)
                row_layout.setContentsMargins(0, 0, 0, 0)  # 确保没有额外边距
                row_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)  # 左对齐和顶部对齐
                self.grid_layout.addLayout(row_layout)

            card = ProductCard(
                product['id'],
                product['title'],
                product['price'],
                product['image'],
                product['days_ago'],
                product['seller'],
                product['likes'],
                self.product_grid  # 明确指定父容器
            )
            card.clicked.connect(self.on_product_clicked)

            # 确保卡片有正确的大小策略
            card.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

            # 渐入动画
            card.setWindowOpacity(0)
            QTimer.singleShot(idx * 30, lambda c=card: self._fade_in_card(c))

            row_layout.addWidget(card, alignment=Qt.AlignmentFlag.AlignTop)  # 添加顶部对齐

        # 最后一行如果不满4个，添加stretch使其左对齐
        if row_layout and row_layout.count() < 4:
            row_layout.addStretch()

    def _clear_grid_layout(self):
        """清理商品网格布局，移除旧的布局和控件，避免重复显示"""
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            # 如果是子布局，递归清理其中的控件
            if item.layout():
                sub_layout = item.layout()
                while sub_layout.count():
                    sub_item = sub_layout.takeAt(0)
                    if sub_item.widget():
                        sub_item.widget().deleteLater()
                # 删除子布局自身
                sub_layout.deleteLater()
            if item.widget():
                item.widget().deleteLater()

    def _fade_in_card(self, card):
        """卡片渐入动画"""
        animation = QPropertyAnimation(card, b"windowOpacity")
        animation.setDuration(300)
        animation.setStartValue(0)
        animation.setEndValue(1)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        animation.start()

    def on_category_clicked(self, category):
        """分类点击事件"""
        self.current_category = category
        for btn in self.category_buttons:
            btn.set_selected(btn.text() == category)
        self.load_products()

    def on_sort_changed(self, sort):
        """排序改变事件"""
        self.current_sort = sort
        for btn in self.sort_buttons:
            btn.setChecked(btn.text() == sort)
        self.load_products()

    def on_condition_changed(self, condition):
        """成色改变事件"""
        self.condition = condition
        for btn in self.condition_buttons:
            btn.setChecked(btn.text() == condition)
        self.load_products()

    def on_price_input_changed(self):
        """价格输入框改变事件"""
        try:
            min_price = int(self.price_min_input.text()) if self.price_min_input.text() else 0
            max_price = int(self.price_max_input.text()) if self.price_max_input.text() else 9999
            if min_price > max_price:
                return  # 无效输入
            self.price_range = (min_price, max_price)
            self.load_products()
        except ValueError:
            pass  # 输入不是数字时忽略

    def on_search(self):
        """搜索事件"""
        keyword = self.search_input.text()
        # 实现搜索逻辑
        self.load_products()

    def on_product_clicked(self, product_id):
        """商品卡片点击事件"""
        try:
            # 从商品列表中找到对应的商品数据
            product_data = None
            target_id = str(product_id)
            for product in self.products:
                if str(product.get('id')) == target_id:
                    product_data = product.copy()
                    break

            # 如果没有找到，使用默认数据
            if not product_data:
                product_data = {
                    'id': product_id,
                    'title': f'商品 {product_id}',
                    'price': 0,
                    'image': None,
                    'days_ago': 0,
                    'seller': '未知卖家',
                    'likes': 0
                }

            from product_detail_page import ProductDetailPage
            detail_window = ProductDetailPage(
                product_id=product_id,
                product_data=product_data,
                user_info=self.user_info,
                on_purchase=lambda: self.load_products()
            )
            detail_window.show()
        except Exception as e:
            print(f"打开详情页失败: {e}")
            import traceback
            traceback.print_exc()
            self.setWindowTitle(f"闲转 - 商品 {product_id}")

    def on_scroll(self):
        """滚动事件，检测是否到底部"""
        # 当前数据全部一次性加载，不需要“加载更多”，直接返回防止重复添加
        return

    def _load_more(self, loading_label):
        """加载更多商品（已禁用，避免重复）"""
        if loading_label:
            loading_label.deleteLater()
        self.loading_more = False

    def open_publish_page(self):
        """打开发布页面"""
        print("点击了发布按钮")  # 调试信息
        try:
            import sys
            import os
            # 确保能正确导入
            gui_dir = os.path.dirname(os.path.abspath(__file__))
            if gui_dir not in sys.path:
                sys.path.insert(0, gui_dir)

            print("开始导入PublishPage...")
            from publish_page import PublishPage
            print("PublishPage导入成功")

            # 如果窗口已存在且未关闭，先关闭它
            if self.publish_window is not None:
                try:
                    if self.publish_window.isVisible():
                        self.publish_window.close()
                except:
                    pass

            # 创建新窗口
            print("开始创建PublishPage实例...")
            publish_window = PublishPage(user_info=self.user_info)
            print("PublishPage实例创建成功")

            # 设置窗口属性，确保窗口独立存在
            publish_window.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
            publish_window.setWindowFlags(Qt.WindowType.Window)

            # 保存窗口引用，防止被垃圾回收
            self.publish_window = publish_window

            print("准备显示窗口...")
            publish_window.show()
            publish_window.raise_()
            publish_window.activateWindow()
            print("发布页面已显示")
        except Exception as e:
            print(f"打开发布页面失败: {e}")
            import traceback
            traceback.print_exc()
            try:
                from PyQt6.QtWidgets import QMessageBox
                QMessageBox.warning(self, "错误", f"打开发布页面失败: {str(e)}\n请查看控制台输出")
            except:
                pass

    def navigate_to_page(self, page_name, QMessageBox=None):
        """导航到指定页面"""
        # 更新底部导航状态
        for widget, icon_label, text_label, pn in self.nav_buttons:
            is_active = (pn == page_name)
            icon_label.setStyleSheet(f"""
                QLabel {{
                    font-size: 24px;
                    color: {'#FFA366' if is_active else '#999'};
                }}
            """)
            text_label.setStyleSheet(f"""
                QLabel {{
                    font-size: 11px;
                    color: {'#FFA366' if is_active else '#999'};
                }}
            """)

        self.current_page = page_name

        # 跳转到对应页面
        try:
            if page_name == "main":
                # 已经在主页面
                pass
            elif page_name == "chat":
                from chat_page import ChatPage
                chat_window = ChatPage()
                chat_window.show()
            elif page_name == "publish":
                print("navigate_to_page: 发布页面")  # 调试信息
                # 直接调用open_publish_page方法
                self.open_publish_page()
            elif page_name == "profile":
                try:
                    # 打开普通用户个人中心页，传递登录时的用户信息（包括username）
                    from user_profile_page import UserProfilePage
                    profile_window = UserProfilePage(self, user_info=self.user_info)
                    profile_window.show()
                    profile_window.raise_()  # 确保窗口显示在最前面
                    profile_window.activateWindow()  # 激活窗口
                except Exception as e:
                    print(f"打开个人中心页失败: {e}")
                    import traceback
                    traceback.print_exc()
                    from PyQt6.QtWidgets import QMessageBox
                    QMessageBox.warning(self, "错误", f"打开个人中心页失败: {str(e)}")
            elif page_name == "dashboard":
                try:
                    from dashboard_page import DashboardPage
                    dashboard_window = DashboardPage()
                    dashboard_window.show()
                    dashboard_window.raise_()  # 确保窗口显示在最前面
                    dashboard_window.activateWindow()  # 激活窗口
                except Exception as e:
                    print(f"打开数据看板失败: {e}")
                    import traceback
                    traceback.print_exc()
                    from PyQt6.QtWidgets import QMessageBox
                    QMessageBox.warning(self, "错误", f"打开数据看板失败: {str(e)}")
        except Exception as e:
            print(f"打开页面失败: {e}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
