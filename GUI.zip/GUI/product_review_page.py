"""
商品审核页面（管理员专用）
"""
import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QLineEdit, QTextEdit, QMessageBox)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor


class ReviewCard(QFrame):
    """审核卡片"""
    def __init__(self, product_data, on_approve=None, on_reject=None, parent=None):
        super().__init__(parent)
        self.product_data = product_data
        self.on_approve = on_approve
        self.on_reject = on_reject
        
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                border: 1px solid #E0E0E0;
                padding: 15px;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setSpacing(15)
        
        # 商品信息
        info_layout = QHBoxLayout()
        info_layout.setSpacing(15)
        
        # 商品图片
        image_label = QLabel()
        image_label.setFixedSize(100, 100)
        image_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                border-radius: 8px;
            }
        """)
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # 绘制占位图
        pixmap = QPixmap(100, 100)
        pixmap.fill(QColor(245, 245, 245))
        painter = QPainter(pixmap)
        painter.setPen(QColor(200, 200, 200))
        painter.setFont(QFont("Arial", 30))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "📷")
        painter.end()
        image_label.setPixmap(pixmap)
        info_layout.addWidget(image_label)
        
        # 商品详情
        detail_layout = QVBoxLayout()
        detail_layout.setSpacing(5)
        
        title_label = QLabel(product_data.get("title", "商品标题"))
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        detail_layout.addWidget(title_label)
        
        price_label = QLabel(f"价格：¥{product_data.get('price', 0)}")
        price_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 14px;
            }
        """)
        detail_layout.addWidget(price_label)
        
        seller_label = QLabel(f"发布者：{product_data.get('seller', '未知')}")
        seller_label.setStyleSheet("""
            QLabel {
                color: #666;
                font-size: 12px;
            }
        """)
        detail_layout.addWidget(seller_label)
        
        info_layout.addLayout(detail_layout, 1)
        layout.addLayout(info_layout)
        
        # 操作按钮
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        reject_btn = QPushButton("拒绝")
        reject_btn.setFixedSize(100, 35)
        reject_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                color: #666;
                border: 1px solid #E0E0E0;
                border-radius: 17px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        if self.on_reject:
            reject_btn.clicked.connect(lambda: self.on_reject(self.product_data.get("id")))
        btn_layout.addWidget(reject_btn)
        
        approve_btn = QPushButton("通过")
        approve_btn.setFixedSize(100, 35)
        approve_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 17px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        if self.on_approve:
            approve_btn.clicked.connect(lambda: self.on_approve(self.product_data.get("id")))
        btn_layout.addWidget(approve_btn)
        
        layout.addLayout(btn_layout)
        self.setLayout(layout)


class ProductReviewPage(QMainWindow):
    """商品审核页面"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("商品审核 - 闲转")
        self.setGeometry(100, 100, 1200, 800)
        self.setStyleSheet("background-color: #F8F8F8;")
        
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)
        
        # 内容区
        self.create_content()
        main_layout.addWidget(self.content_area)
        
        main_widget.setLayout(main_layout)
        
        # 加载待审核商品
        self.load_pending_products()
    
    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        
        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333;
                border: none;
                font-size: 16px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #F5F5F5;
                border-radius: 5px;
            }
        """)
        back_btn.clicked.connect(self.close)
        layout.addWidget(back_btn)
        
        # 标题
        title_label = QLabel("商品审核")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label, 1)
        
        self.top_nav.setLayout(layout)
    
    def create_content(self):
        """创建内容区"""
        self.content_area = QScrollArea()
        self.content_area.setWidgetResizable(True)
        self.content_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(20, 20, 20, 20)
        scroll_layout.setSpacing(15)
        
        self.review_container = QWidget()
        self.review_layout = QVBoxLayout()
        self.review_layout.setContentsMargins(0, 0, 0, 0)
        self.review_layout.setSpacing(15)
        self.review_container.setLayout(self.review_layout)
        
        scroll_layout.addWidget(self.review_container)
        scroll_layout.addStretch()
        
        scroll_content.setLayout(scroll_layout)
        self.content_area.setWidget(scroll_content)
    
    def load_pending_products(self):
        """加载待审核商品"""
        # 模拟待审核商品数据
        products = [
            {"id": 1, "title": "99新iPhone14 256G", "price": 1299, "seller": "用户A"},
            {"id": 2, "title": "二手MacBook Pro 13寸", "price": 5999, "seller": "用户B"},
            {"id": 3, "title": "AirPods Pro 2代", "price": 899, "seller": "用户C"},
        ]
        
        self.pending_products = products  # 保存待审核商品列表
        for product in products:
            card = ReviewCard(
                product,
                on_approve=self.approve_product,
                on_reject=self.reject_product
            )
            self.review_layout.addWidget(card)
    
    def approve_product(self, product_id):
        """通过商品审核"""
        reply = QMessageBox.question(
            self,
            "确认通过",
            f"确定通过商品ID {product_id} 的审核吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            # 从待审核列表中移除
            self.pending_products = [p for p in self.pending_products if p.get("id") != product_id]
            # 刷新界面
            self.refresh_review_list()
            QMessageBox.information(self, "提示", "商品审核已通过，商品已上架！")
    
    def reject_product(self, product_id):
        """拒绝商品审核"""
        reply = QMessageBox.question(
            self,
            "确认拒绝",
            f"确定拒绝商品ID {product_id} 的审核吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            # 从待审核列表中移除
            self.pending_products = [p for p in self.pending_products if p.get("id") != product_id]
            # 刷新界面
            self.refresh_review_list()
            QMessageBox.information(self, "提示", "商品审核已拒绝！")
    
    def refresh_review_list(self):
        """刷新审核列表"""
        # 清空现有卡片
        while self.review_layout.count():
            item = self.review_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        # 重新加载
        for product in self.pending_products:
            card = ReviewCard(
                product,
                on_approve=self.approve_product,
                on_reject=self.reject_product
            )
            self.review_layout.addWidget(card)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ProductReviewPage()
    window.show()
    sys.exit(app.exec())

