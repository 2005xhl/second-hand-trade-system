import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QTextEdit, QLineEdit, QFileDialog, QSizePolicy)
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer, pyqtSignal, QDateTime, QPoint
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor, QMouseEvent


class MessageBubble(QFrame):
    """消息气泡"""
    def __init__(self, message, is_me=True, timestamp="", parent=None):
        super().__init__(parent)
        self.is_me = is_me
        self.message = message
        self.timestamp = timestamp

        if is_me:
            self.setStyleSheet("""
                QFrame {
                    background-color: #FFA366;
                    border-radius: 12px;
                    padding: 10px 15px;
                }
            """)
        else:
            self.setStyleSheet("""
                QFrame {
                    background-color: #F5F5F5;
                    border-radius: 12px;
                    padding: 10px 15px;
                }
            """)

        # 设置最大宽度，让气泡根据内容自适应
        if parent:
            # 获取父窗口的实际宽度，如果还没有显示则使用默认值
            parent_width = parent.width() if parent.width() > 0 else 800
            max_width = int(parent_width * 0.65)  # 最大宽度为窗口的65%
        else:
            max_width = 400  # 默认最大宽度
        self.setMaximumWidth(max_width)
        self.setMinimumWidth(0)  # 允许缩小到内容所需的最小宽度
        
        # 设置大小策略，允许根据内容调整大小
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        # 消息内容
        message_label = QLabel(message)
        message_label.setWordWrap(True)
        message_label.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        # 设置文本格式，确保文本能够正确换行
        message_label.setTextFormat(Qt.TextFormat.PlainText)
        if is_me:
            message_label.setStyleSheet("color: white; font-size: 14px;")
        else:
            message_label.setStyleSheet("color: #333; font-size: 14px;")
        layout.addWidget(message_label)

        # 时间戳
        if timestamp:
            time_label = QLabel(timestamp)
            if is_me:
                time_label.setStyleSheet("color: rgba(255, 255, 255, 0.7); font-size: 11px;")
            else:
                time_label.setStyleSheet("color: #999; font-size: 11px;")
            time_label.setAlignment(Qt.AlignmentFlag.AlignRight)
            layout.addWidget(time_label)

        self.setLayout(layout)


class ChatPage(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("聊天 - 闲转")
        self.setGeometry(100, 100, 800, 900)
        self.setStyleSheet("background-color: white;")
        
        # 设置窗口属性，确保作为独立窗口存在
        self.setWindowFlags(Qt.WindowType.Window)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)

        self.other_user_name = "卖家昵称"
        self.other_user_online = True
        self.messages = []
        self.unread_count = 0

        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 顶部栏
        self.create_top_bar()
        main_layout.addWidget(self.top_bar)

        # 消息区
        self.create_message_area()
        main_layout.addWidget(self.message_scroll_area, 1)

        # 输入区
        self.create_input_area()
        main_layout.addWidget(self.input_area)

        main_widget.setLayout(main_layout)

        # 添加初始消息
        QTimer.singleShot(500, self.add_system_message)
        QTimer.singleShot(1000, lambda: self.add_received_message("你好，请问这个宝贝还在吗？"))

    def create_top_bar(self):
        """创建顶部栏"""
        self.top_bar = QFrame()
        self.top_bar.setFixedHeight(60)
        self.top_bar.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)

        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)

        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #666;
                border: none;
                font-size: 14px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                color: #333;
                background-color: #F5F5F5;
                border-radius: 4px;
            }
        """)
        back_btn.clicked.connect(self.close)
        layout.addWidget(back_btn)

        # 用户信息
        user_info_layout = QHBoxLayout()
        user_info_layout.setSpacing(10)

        # 头像
        avatar_label = QLabel()
        avatar_label.setFixedSize(40, 40)
        avatar_label.setStyleSheet("""
            QLabel {
                background-color: #E0E0E0;
                border-radius: 20px;
            }
        """)
        pixmap = QPixmap(40, 40)
        pixmap.fill(QColor(200, 200, 200))
        painter = QPainter(pixmap)
        painter.setPen(QColor(100, 100, 100))
        painter.setFont(QFont("Arial", 20))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "👤")
        painter.end()
        avatar_label.setPixmap(pixmap)
        user_info_layout.addWidget(avatar_label)

        # 昵称和状态
        name_status_layout = QVBoxLayout()
        name_status_layout.setSpacing(2)

        name_label = QLabel(self.other_user_name)
        name_label.setStyleSheet("color: #333; font-size: 14px; font-weight: bold;")
        name_status_layout.addWidget(name_label)

        self.status_label = QLabel("在线" if self.other_user_online else "离线")
        self.status_label.setStyleSheet("color: #999; font-size: 11px;")
        name_status_layout.addWidget(self.status_label)

        user_info_layout.addLayout(name_status_layout)
        layout.addLayout(user_info_layout, 1)

        # 更多按钮
        more_btn = QPushButton("更多")
        more_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #666;
                border: none;
                font-size: 14px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                color: #333;
                background-color: #F5F5F5;
                border-radius: 4px;
            }
        """)
        more_btn.clicked.connect(self.show_more_menu)
        layout.addWidget(more_btn)

        self.top_bar.setLayout(layout)

    def create_message_area(self):
        """创建消息区"""
        self.message_scroll_area = QScrollArea()
        self.message_scroll_area.setWidgetResizable(True)
        self.message_scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: white;
            }
        """)

        self.message_container = QWidget()
        self.message_layout = QVBoxLayout()
        self.message_layout.setContentsMargins(15, 15, 15, 15)
        self.message_layout.setSpacing(10)

        self.message_container.setLayout(self.message_layout)
        self.message_scroll_area.setWidget(self.message_container)

    def create_input_area(self):
        """创建输入区"""
        self.input_area = QFrame()
        self.input_area.setFixedHeight(80)
        self.input_area.setStyleSheet("""
            QFrame {
                background-color: #F5F5F5;
                border-top: 1px solid #E0E0E0;
            }
        """)

        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        layout.setSpacing(10)

        # 左侧图标按钮
        icon_layout = QHBoxLayout()
        icon_layout.setSpacing(5)

        emoji_btn = QPushButton("😊")
        emoji_btn.setFixedSize(30, 30)
        emoji_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: none;
                font-size: 18px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
                border-radius: 15px;
            }
        """)
        icon_layout.addWidget(emoji_btn)

        image_btn = QPushButton("📷")
        image_btn.setFixedSize(30, 30)
        image_btn.setStyleSheet(emoji_btn.styleSheet())
        icon_layout.addWidget(image_btn)

        file_btn = QPushButton("📎")
        file_btn.setFixedSize(30, 30)
        file_btn.setStyleSheet(emoji_btn.styleSheet())
        icon_layout.addWidget(file_btn)

        layout.addLayout(icon_layout)

        # 输入框
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("说点什么...")
        self.input_field.setFixedHeight(40)
        self.input_field.setStyleSheet("""
            QLineEdit {
                background-color: white;
                border: 1px solid #E0E0E0;
                border-radius: 20px;
                padding: 0 15px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #FFA366;
            }
        """)
        self.input_field.textChanged.connect(self.on_input_changed)
        self.input_field.returnPressed.connect(self.send_message)
        layout.addWidget(self.input_field, 1)

        # 发送按钮
        self.send_btn = QPushButton("发送")
        self.send_btn.setFixedSize(70, 40)
        self.send_btn.setEnabled(False)
        self.send_btn.setStyleSheet("""
            QPushButton {
                background-color: #CCCCCC;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:enabled {
                background-color: #FFA366;
            }
            QPushButton:enabled:hover {
                background-color: #FFB380;
            }
        """)
        self.send_btn.clicked.connect(self.send_message)
        layout.addWidget(self.send_btn)

        self.input_area.setLayout(layout)

    def add_system_message(self, text=None):
        """添加系统消息"""
        if text is None:
            current_date = QDateTime.currentDateTime().toString("yyyy-MM-dd")
            text = current_date

        system_label = QLabel(text)
        system_label.setStyleSheet("""
            QLabel {
                color: #999;
                font-size: 12px;
                padding: 5px 0;
            }
        """)
        system_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.message_layout.addWidget(system_label)
        self.scroll_to_bottom()

    def add_message(self, message, is_me=True, status=""):
        """添加消息"""
        current_time = QDateTime.currentDateTime().toString("hh:mm")
        # 传递消息容器作为父窗口，用于计算最大宽度
        bubble = MessageBubble(message, is_me, current_time, self.message_container)
        
        # 消息布局
        message_wrapper = QHBoxLayout()
        message_wrapper.setContentsMargins(0, 0, 0, 0)
        message_wrapper.setSpacing(8)  # 添加间距，让气泡和头像/状态之间有间隔
        
        if is_me:
            message_wrapper.addStretch()
            message_wrapper.addWidget(bubble, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        else:
            # 对方消息显示头像
            avatar_label = QLabel()
            avatar_label.setFixedSize(35, 35)
            avatar_label.setStyleSheet("""
                QLabel {
                    background-color: #E0E0E0;
                    border-radius: 17px;
                }
            """)
            pixmap = QPixmap(35, 35)
            pixmap.fill(QColor(200, 200, 200))
            painter = QPainter(pixmap)
            painter.setPen(QColor(100, 100, 100))
            painter.setFont(QFont("Arial", 16))
            painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "👤")
            painter.end()
            avatar_label.setPixmap(pixmap)
            message_wrapper.addWidget(avatar_label, 0, Qt.AlignmentFlag.AlignTop)
            message_wrapper.addWidget(bubble, 0, Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
            message_wrapper.addStretch()

        # 状态提示（已发送/已读）
        if status:
            status_label = QLabel(status)
            status_label.setStyleSheet("color: #999; font-size: 11px;")
            if is_me:
                status_label.setAlignment(Qt.AlignmentFlag.AlignRight)
            else:
                status_label.setAlignment(Qt.AlignmentFlag.AlignLeft)
            message_wrapper.addWidget(status_label)

        self.message_layout.addLayout(message_wrapper)
        
        # 滑入动画
        if not is_me:
            self.animate_message_in(bubble)
        
        self.scroll_to_bottom()
        self.messages.append({'message': message, 'is_me': is_me, 'status': status})

    def add_received_message(self, message):
        """添加接收到的消息"""
        self.add_message(message, is_me=False)
        self.unread_count += 1
        if self.unread_count > 0:
            self.update_unread_indicator()

    def animate_message_in(self, widget):
        """消息滑入动画"""
        widget.setWindowOpacity(0)
        widget.move(widget.x() + 50, widget.y())
        
        # 淡入动画
        fade_animation = QPropertyAnimation(widget, b"windowOpacity")
        fade_animation.setDuration(300)
        fade_animation.setStartValue(0)
        fade_animation.setEndValue(1)
        fade_animation.start()

        # 位移动画
        move_animation = QPropertyAnimation(widget, b"pos")
        move_animation.setDuration(300)
        move_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        original_pos = widget.pos()
        move_animation.setStartValue(QPoint(original_pos.x() + 50, original_pos.y()))
        move_animation.setEndValue(original_pos)
        move_animation.start()

    def send_message(self):
        """发送消息"""
        text = self.input_field.text().strip()
        if not text:
            return

        # 添加消息
        status = "已发送" if self.other_user_online else ""
        self.add_message(text, is_me=True, status=status)
        
        # 清空输入框
        self.input_field.clear()
        
        # 如果对方在线，模拟已读
        if self.other_user_online:
            QTimer.singleShot(1000, lambda: self.update_message_status("已读"))

        # 模拟对方回复
        QTimer.singleShot(2000, lambda: self.add_received_message("还在的，需要的话可以联系我"))

    def update_message_status(self, status):
        """更新消息状态"""
        if self.messages:
            # 更新最后一条消息的状态
            last_item = self.message_layout.itemAt(self.message_layout.count() - 1)
            if last_item:
                # 这里简化处理，实际应该更新状态标签
                pass

    def on_input_changed(self):
        """输入框内容改变"""
        text = self.input_field.text().strip()
        self.send_btn.setEnabled(len(text) > 0)

    def scroll_to_bottom(self):
        """滚动到底部"""
        QTimer.singleShot(100, lambda: self.message_scroll_area.verticalScrollBar().setValue(
            self.message_scroll_area.verticalScrollBar().maximum()
        ))

    def update_unread_indicator(self):
        """更新未读提示"""
        if self.unread_count > 0:
            # 显示全局消息通知
            from message_notification import MessageNotificationManager
            notification_manager = MessageNotificationManager()
            notification_manager.show_new_message(self)
            
            # 在聊天界面内也显示一个小的提示（可选）
            unread_label = QLabel("新消息！")
            unread_label.setStyleSheet("""
                QLabel {
                    background-color: transparent;
                    color: #FF0000;
                    padding: 5px 15px;
                    font-size: 12px;
                    font-weight: bold;
                }
            """)
            unread_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.message_layout.insertWidget(0, unread_label)
            
            # 3秒后移除
            QTimer.singleShot(3000, lambda: (unread_label.deleteLater(), setattr(self, 'unread_count', 0)))

    def show_more_menu(self):
        """显示更多菜单"""
        from PyQt6.QtWidgets import QMenu
        menu = QMenu(self)
        menu.addAction("举报", lambda: self.report_user())
        menu.addAction("拉黑", lambda: self.block_user())
        menu.exec(self.sender().mapToGlobal(QPoint(0, self.sender().height())))

    def report_user(self):
        """举报用户"""
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QTextEdit, QPushButton, QMessageBox
        dialog = QDialog(self)
        dialog.setWindowTitle("举报用户")
        dialog.setFixedSize(500, 400)
        dialog.setStyleSheet("""
            QDialog {
                background-color: white;
                border-radius: 12px;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(30, 30, 30, 30)
        
        # 标题
        title_label = QLabel("举报用户")
        title_label.setStyleSheet("""
            QLabel {
                font-size: 18px;
                font-weight: bold;
                color: #333;
            }
        """)
        layout.addWidget(title_label)
        
        # 举报原因
        reason_label = QLabel("举报原因：")
        reason_label.setStyleSheet("font-size: 14px; color: #333;")
        layout.addWidget(reason_label)
        
        reason_input = QTextEdit()
        reason_input.setPlaceholderText("请详细描述举报原因...")
        reason_input.setFixedHeight(150)
        reason_input.setStyleSheet("""
            QTextEdit {
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 10px;
                font-size: 14px;
            }
            QTextEdit:focus {
                border: 1px solid #FFA366;
            }
        """)
        layout.addWidget(reason_input)
        
        layout.addStretch()
        
        # 按钮
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        cancel_btn = QPushButton("取消")
        cancel_btn.setFixedSize(100, 40)
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                color: #666;
                border: none;
                border-radius: 20px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        cancel_btn.clicked.connect(dialog.reject)
        btn_layout.addWidget(cancel_btn)
        
        submit_btn = QPushButton("提交举报")
        submit_btn.setFixedSize(100, 40)
        submit_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        def submit_report():
            if reason_input.toPlainText().strip():
                dialog.accept()
                QMessageBox.information(self, "提示", "举报已提交，我们会尽快处理！")
            else:
                QMessageBox.warning(self, "提示", "请填写举报原因")
        submit_btn.clicked.connect(submit_report)
        btn_layout.addWidget(submit_btn)
        
        layout.addLayout(btn_layout)
        dialog.setLayout(layout)
        dialog.exec()

    def block_user(self):
        """拉黑用户"""
        reply = QMessageBox.question(
            self,
            "确认拉黑",
            "确定要拉黑此用户吗？拉黑后将无法接收该用户的消息。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            QMessageBox.information(self, "提示", "用户已拉黑，您将不再接收该用户的消息。")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ChatPage()
    window.show()
    sys.exit(app.exec())

