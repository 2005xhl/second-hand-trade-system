"""
普通用户个人中心页面
"""
import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QMessageBox, QDialog, QLineEdit, QFileDialog)
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer, pyqtSignal, QPoint
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor, QMouseEvent


class FunctionButton(QFrame):
    """功能入口按钮"""
    clicked = pyqtSignal()

    def __init__(self, icon_text, title, icon_color, parent=None):
        super().__init__(parent)
        self.icon_text = icon_text
        self.title = title
        self.icon_color = icon_color

        self.setFixedSize(80, 90)
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                border: 1px solid #E0E0E0;
            }
            QFrame:hover {
                border: 2px solid #FFA366;
                background-color: #FFF8F5;
            }
        """)

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(8)

        # 图标
        icon_label = QLabel(icon_text)
        icon_label.setStyleSheet(f"""
            QLabel {{
                font-size: 32px;
                color: {icon_color};
            }}
        """)
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(icon_label)

        # 文字
        title_label = QLabel(title)
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 12px;
            }
        """)
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        self.setLayout(layout)

    def mousePressEvent(self, event: QMouseEvent):
        """点击事件，添加动画效果"""
        if event.button() == Qt.MouseButton.LeftButton:
            # 放大动画
            self.animation = QPropertyAnimation(self, b"geometry")
            self.animation.setDuration(150)
            self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
            original_geo = self.geometry()
            self.animation.setStartValue(original_geo)
            self.animation.setEndValue(original_geo.adjusted(-5, -5, 5, 5))
            
            # 恢复动画
            self.restore_animation = QPropertyAnimation(self, b"geometry")
            self.restore_animation.setDuration(150)
            self.restore_animation.setEasingCurve(QEasingCurve.Type.OutCubic)
            self.restore_animation.setEndValue(original_geo)

            self.animation.finished.connect(self.restore_animation.start)
            self.animation.start()

            # 延迟发送信号，让动画先执行
            QTimer.singleShot(200, lambda: self.clicked.emit())


class EditProfileDialog(QDialog):
    """编辑资料对话框"""
    def __init__(self, current_name, current_avatar_path, parent=None):
        super().__init__(parent)
        self.setWindowTitle("编辑资料")
        self.setFixedSize(400, 300)
        self.setStyleSheet("""
            QDialog {
                background-color: white;
                border-radius: 12px;
            }
        """)

        self.new_avatar_path = current_avatar_path

        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(30, 30, 30, 30)

        # 头像
        avatar_layout = QVBoxLayout()
        avatar_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.avatar_label = QLabel()
        self.avatar_label.setFixedSize(100, 100)
        self.avatar_label.setStyleSheet("""
            QLabel {
                background-color: #E0E0E0;
                border-radius: 50px;
                border: 3px solid #FFA366;
            }
        """)
        self.avatar_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.load_avatar(current_avatar_path)
        self.avatar_label.mousePressEvent = self.change_avatar
        self.avatar_label.setCursor(Qt.CursorShape.PointingHandCursor)
        avatar_layout.addWidget(self.avatar_label)

        change_avatar_btn = QPushButton("点击更换头像")
        change_avatar_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #FFA366;
                border: none;
                font-size: 12px;
            }
            QPushButton:hover {
                color: #FFB380;
            }
        """)
        change_avatar_btn.clicked.connect(self.change_avatar)
        avatar_layout.addWidget(change_avatar_btn)

        layout.addLayout(avatar_layout)

        # 昵称输入
        name_label = QLabel("昵称")
        name_label.setStyleSheet("color: #666; font-size: 14px;")
        layout.addWidget(name_label)

        self.name_input = QLineEdit()
        self.name_input.setText(current_name)
        self.name_input.setStyleSheet("""
            QLineEdit {
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 10px 15px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #FFA366;
            }
        """)
        layout.addWidget(self.name_input)

        layout.addStretch()

        # 按钮
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)

        cancel_btn = QPushButton("取消")
        cancel_btn.setFixedHeight(40)
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                color: #666;
                border: none;
                border-radius: 20px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)

        save_btn = QPushButton("保存")
        save_btn.setFixedHeight(40)
        save_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        save_btn.clicked.connect(self.accept)
        button_layout.addWidget(save_btn)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def load_avatar(self, path):
        """加载头像"""
        if path:
            pixmap = QPixmap(path)
            if not pixmap.isNull():
                pixmap = pixmap.scaled(100, 100, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                self.avatar_label.setPixmap(pixmap)
                return

        # 默认头像
        pixmap = QPixmap(100, 100)
        pixmap.fill(QColor(200, 200, 200))
        painter = QPainter(pixmap)
        painter.setPen(QColor(100, 100, 100))
        painter.setFont(QFont("Arial", 30))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "👤")
        painter.end()
        self.avatar_label.setPixmap(pixmap)

    def change_avatar(self, event=None):
        """更换头像"""
        file, _ = QFileDialog.getOpenFileName(
            self,
            "选择头像",
            "",
            "图片文件 (*.png *.jpg *.jpeg *.bmp)"
        )
        if file:
            self.new_avatar_path = file
            self.load_avatar(file)


class UserProfilePage(QMainWindow):
    """普通用户个人中心页面"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("个人中心 - 闲转")
        self.setGeometry(100, 100, 900, 700)
        self.setStyleSheet("background-color: #F8F8F8;")

        self.user_name = "用户昵称"
        self.user_role = "普通用户"
        self.avatar_path = None

        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 顶部信息栏
        self.create_top_info_bar()
        main_layout.addWidget(self.top_info_bar)

        # 滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)

        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(20, 20, 20, 20)
        scroll_layout.setSpacing(20)

        # 功能区
        self.create_function_area()
        scroll_layout.addWidget(self.function_area)

        scroll_layout.addStretch()

        scroll_content.setLayout(scroll_layout)
        scroll_area.setWidget(scroll_content)
        main_layout.addWidget(scroll_area)

        # 底部退出按钮
        self.create_bottom_bar()
        main_layout.addWidget(self.bottom_bar)

        main_widget.setLayout(main_layout)

    def create_top_info_bar(self):
        """创建顶部信息栏"""
        self.top_info_bar = QFrame()
        self.top_info_bar.setFixedHeight(150)
        self.top_info_bar.setStyleSheet("""
            QFrame {
                background-color: #FFA366;
            }
        """)

        layout = QHBoxLayout()
        layout.setContentsMargins(30, 20, 30, 20)

        # 头像
        self.avatar_label = QLabel()
        self.avatar_label.setFixedSize(80, 80)
        self.avatar_label.setStyleSheet("""
            QLabel {
                background-color: white;
                border-radius: 40px;
                border: 3px solid white;
            }
        """)
        self.avatar_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.avatar_label.mousePressEvent = self.on_avatar_clicked
        self.avatar_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self.load_avatar()
        layout.addWidget(self.avatar_label)

        # 用户信息
        user_info_layout = QVBoxLayout()
        user_info_layout.setSpacing(8)

        self.name_label = QLabel(self.user_name)
        self.name_label.setStyleSheet("""
            QLabel {
                color: white;
                font-size: 20px;
                font-weight: bold;
            }
        """)
        user_info_layout.addWidget(self.name_label)

        role_label = QLabel(self.user_role)
        role_label.setStyleSheet("""
            QLabel {
                color: rgba(255, 255, 255, 0.8);
                font-size: 14px;
            }
        """)
        user_info_layout.addWidget(role_label)

        user_info_layout.addStretch()
        layout.addLayout(user_info_layout, 1)

        # 编辑资料按钮
        edit_btn = QPushButton("编辑资料")
        edit_btn.setFixedSize(100, 35)
        edit_btn.setStyleSheet("""
            QPushButton {
                background-color: white;
                color: #FFA366;
                border: none;
                border-radius: 17px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFF8F5;
            }
        """)
        edit_btn.clicked.connect(self.edit_profile)
        layout.addWidget(edit_btn)

        self.top_info_bar.setLayout(layout)

    def create_function_area(self):
        """创建功能区"""
        self.function_area = QFrame()
        self.function_area.setStyleSheet("background-color: transparent;")

        layout = QVBoxLayout()
        layout.setSpacing(20)

        # 普通用户：只显示四个功能按钮
        row1_layout = QHBoxLayout()
        row1_layout.setSpacing(15)
        row1_layout.addStretch()

        functions_row1 = [
            ("📝", "我的发布", "#FFD700"),
            ("📦", "我的订单", "#1890FF"),
            ("❤️", "我的收藏", "#FF4444"),
            ("💰", "我卖出的", "#FFA366")
        ]

        for icon, title, color in functions_row1:
            btn = FunctionButton(icon, title, color)
            # 使用默认参数捕获正确的title值
            btn.clicked.connect(lambda t=title: self.on_function_clicked(t))
            row1_layout.addWidget(btn)

        row1_layout.addStretch()
        layout.addLayout(row1_layout)

        self.function_area.setLayout(layout)

    def create_bottom_bar(self):
        """创建底部栏"""
        self.bottom_bar = QFrame()
        self.bottom_bar.setFixedHeight(80)
        self.bottom_bar.setStyleSheet("""
            QFrame {
                background-color: white;
                border-top: 1px solid #E0E0E0;
            }
        """)

        layout = QHBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)

        layout.addStretch()

        logout_btn = QPushButton("退出登录")
        logout_btn.setFixedSize(200, 40)
        logout_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                color: #666;
                border: 1px solid #E0E0E0;
                border-radius: 20px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        logout_btn.clicked.connect(self.logout)
        layout.addWidget(logout_btn)

        layout.addStretch()

        self.bottom_bar.setLayout(layout)

    def load_avatar(self):
        """加载头像"""
        if self.avatar_path:
            pixmap = QPixmap(self.avatar_path)
            if not pixmap.isNull():
                pixmap = pixmap.scaled(80, 80, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                self.avatar_label.setPixmap(pixmap)
                return

        # 默认头像
        pixmap = QPixmap(80, 80)
        pixmap.fill(QColor(200, 200, 200))
        painter = QPainter(pixmap)
        painter.setPen(QColor(100, 100, 100))
        painter.setFont(QFont("Arial", 30))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "👤")
        painter.end()
        self.avatar_label.setPixmap(pixmap)

    def on_avatar_clicked(self, event):
        """头像点击事件"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.edit_profile()

    def edit_profile(self):
        """编辑资料"""
        dialog = EditProfileDialog(self.user_name, self.avatar_path, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            # 更新信息
            self.user_name = dialog.name_input.text()
            self.avatar_path = dialog.new_avatar_path
            
            # 刷新显示
            self.name_label.setText(self.user_name)
            self.load_avatar()
            QMessageBox.information(self, "提示", "资料已更新！")

    def on_function_clicked(self, function_name):
        """功能入口点击"""
        try:
            if function_name == "我的收藏":
                from favorite_list_page import FavoriteListPage
                favorite_window = FavoriteListPage(self)
                favorite_window.show()
            elif function_name == "我的订单":
                from order_page import OrderPage
                order_window = OrderPage()
                order_window.show()
            elif function_name == "我的发布":
                from my_posts_page import MyPostsPage
                posts_window = MyPostsPage(self)
                posts_window.show()
            elif function_name == "我卖出的":
                from my_sales_page import MySalesPage
                sales_window = MySalesPage(self)
                sales_window.show()
            else:
                QMessageBox.information(self, "提示", f"跳转到「{function_name}」页面")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"打开页面失败: {str(e)}")
            import traceback
            traceback.print_exc()
    
    def logout(self):
        """退出登录"""
        reply = QMessageBox.question(
            self,
            "确认退出",
            "确定退出吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            # 渐变关闭效果
            self.fade_out_animation = QPropertyAnimation(self, b"windowOpacity")
            self.fade_out_animation.setDuration(500)
            self.fade_out_animation.setStartValue(1.0)
            self.fade_out_animation.setEndValue(0.0)
            self.fade_out_animation.finished.connect(self.close)
            self.fade_out_animation.start()

            # 显示提示
            QTimer.singleShot(250, lambda: QMessageBox.information(
                self, "提示", "已安全退出"
            ))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = UserProfilePage()
    window.show()
    sys.exit(app.exec())

