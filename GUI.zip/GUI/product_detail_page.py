import sys
import os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QTextEdit, QLineEdit, QGraphicsDropShadowEffect,
                             QDialog, QMessageBox)
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer, pyqtSignal, QPoint, QSize, QRect, QPointF
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor, QMouseEvent, QWheelEvent, QKeyEvent


class ThumbnailWidget(QFrame):
    """缩略图组件"""
    clicked = pyqtSignal(int)

    def __init__(self, image_path, index, is_selected=False, parent=None):
        super().__init__(parent)
        self.image_path = image_path
        self.index = index
        self.is_selected = is_selected

        self.setFixedSize(80, 80)
        self.update_style()

        layout = QVBoxLayout()
        layout.setContentsMargins(2, 2, 2, 2)

        self.image_label = QLabel()
        self.image_label.setFixedSize(76, 76)
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet("border-radius: 4px;")
        
        pixmap = QPixmap(image_path)
        if not pixmap.isNull():
            pixmap = pixmap.scaled(76, 76, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            self.image_label.setPixmap(pixmap)
        
        layout.addWidget(self.image_label)
        self.setLayout(layout)

    def update_style(self):
        """更新样式"""
        if self.is_selected:
            self.setStyleSheet("""
                QFrame {
                    background-color: white;
                    border: 2px solid #FFA366;
                    border-radius: 6px;
                }
            """)
        else:
            self.setStyleSheet("""
                QFrame {
                    background-color: white;
                    border: 2px solid #E0E0E0;
                    border-radius: 6px;
                }
                QFrame:hover {
                    border: 2px solid #FFA366;
                }
            """)

    def set_selected(self, selected):
        """设置选中状态"""
        self.is_selected = selected
        self.update_style()

    def mousePressEvent(self, event: QMouseEvent):
        """点击事件"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.index)
        super().mousePressEvent(event)


class ImageViewerDialog(QDialog):
    """图片全屏查看对话框"""
    def __init__(self, image_paths, current_index, parent=None):
        super().__init__(parent)
        self.image_paths = image_paths
        self.current_index = current_index
        self.scale_factor = 1.0
        self.min_scale = 0.5
        self.max_scale = 3.0

        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setStyleSheet("background-color: rgba(0, 0, 0, 0.9);")
        
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)

        # 图片显示区域
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet("background-color: transparent;")
        self.load_image(self.current_index)
        
        layout.addWidget(self.image_label)
        self.setLayout(layout)

        # 关闭按钮
        self.close_btn = QPushButton("×")
        self.close_btn.setFixedSize(40, 40)
        self.close_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.3);
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 24px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.5);
            }
        """)
        self.close_btn.setParent(self)
        self.close_btn.move(self.width() - 50, 10)
        self.close_btn.clicked.connect(self.close)

        # 左右切换按钮
        self.prev_btn = QPushButton("‹")
        self.prev_btn.setFixedSize(50, 50)
        self.prev_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.3);
                color: white;
                border: none;
                border-radius: 25px;
                font-size: 32px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.5);
            }
        """)
        self.prev_btn.setParent(self)
        self.prev_btn.move(20, self.height() // 2 - 25)
        self.prev_btn.clicked.connect(self.prev_image)

        self.next_btn = QPushButton("›")
        self.next_btn.setFixedSize(50, 50)
        self.next_btn.setStyleSheet(self.prev_btn.styleSheet())
        self.next_btn.setParent(self)
        self.next_btn.move(self.width() - 70, self.height() // 2 - 25)
        self.next_btn.clicked.connect(self.next_image)

    def load_image(self, index):
        """加载图片"""
        if 0 <= index < len(self.image_paths):
            self.current_index = index
            pixmap = QPixmap(self.image_paths[index])
            if not pixmap.isNull():
                # 缩放图片以适应窗口
                scaled_pixmap = pixmap.scaled(
                    int(pixmap.width() * self.scale_factor),
                    int(pixmap.height() * self.scale_factor),
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation
                )
                self.image_label.setPixmap(scaled_pixmap)

    def prev_image(self):
        """上一张"""
        if self.current_index > 0:
            self.current_index -= 1
            self.scale_factor = 1.0
            self.load_image(self.current_index)

    def next_image(self):
        """下一张"""
        if self.current_index < len(self.image_paths) - 1:
            self.current_index += 1
            self.scale_factor = 1.0
            self.load_image(self.current_index)

    def wheelEvent(self, event: QWheelEvent):
        """滚轮缩放"""
        delta = event.angleDelta().y()
        if delta > 0:
            self.scale_factor = min(self.scale_factor * 1.1, self.max_scale)
        else:
            self.scale_factor = max(self.scale_factor * 0.9, self.min_scale)
        self.load_image(self.current_index)

    def keyPressEvent(self, event: QKeyEvent):
        """键盘事件"""
        if event.key() == Qt.Key.Key_Escape:
            self.close()
        elif event.key() == Qt.Key.Key_Left:
            self.prev_image()
        elif event.key() == Qt.Key.Key_Right:
            self.next_image()

    def resizeEvent(self, event):
        """窗口大小改变"""
        self.close_btn.move(self.width() - 50, 10)
        self.prev_btn.move(20, self.height() // 2 - 25)
        self.next_btn.move(self.width() - 70, self.height() // 2 - 25)
        self.load_image(self.current_index)
        super().resizeEvent(event)


class ChatWindow(QWidget):
    """聊天窗口"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setFixedSize(400, 600)
        self.setStyleSheet("""
            QWidget {
                background-color: white;
                border-radius: 12px;
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 顶部栏
        top_bar = QFrame()
        top_bar.setFixedHeight(50)
        top_bar.setStyleSheet("""
            QFrame {
                background-color: #FFA366;
                border-top-left-radius: 12px;
                border-top-right-radius: 12px;
            }
        """)

        top_layout = QHBoxLayout()
        top_layout.setContentsMargins(15, 10, 15, 10)

        title_label = QLabel("与卖家聊天")
        title_label.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        top_layout.addWidget(title_label)

        top_layout.addStretch()

        close_btn = QPushButton("×")
        close_btn.setFixedSize(30, 30)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: white;
                border: none;
                font-size: 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.2);
                border-radius: 15px;
            }
        """)
        close_btn.clicked.connect(self.close)
        top_layout.addWidget(close_btn)

        top_bar.setLayout(top_layout)
        layout.addWidget(top_bar)

        # 聊天内容区
        self.chat_area = QTextEdit()
        self.chat_area.setReadOnly(True)
        self.chat_area.setStyleSheet("""
            QTextEdit {
                border: none;
                padding: 15px;
                background-color: #F5F5F5;
                font-size: 14px;
            }
        """)
        layout.addWidget(self.chat_area)

        # 输入区
        input_frame = QFrame()
        input_frame.setFixedHeight(60)
        input_frame.setStyleSheet("background-color: white; border-top: 1px solid #E0E0E0;")

        input_layout = QHBoxLayout()
        input_layout.setContentsMargins(10, 10, 10, 10)

        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("输入消息...")
        self.input_field.setStyleSheet("""
            QLineEdit {
                border: 1px solid #E0E0E0;
                border-radius: 20px;
                padding: 8px 15px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #FFA366;
            }
        """)
        self.input_field.returnPressed.connect(self.send_message)
        input_layout.addWidget(self.input_field)

        send_btn = QPushButton("发送")
        send_btn.setFixedSize(60, 35)
        send_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 17px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        send_btn.clicked.connect(self.send_message)
        input_layout.addWidget(send_btn)

        input_frame.setLayout(input_layout)
        layout.addWidget(input_frame)

        self.setLayout(layout)

        # 自动发送初始消息
        QTimer.singleShot(100, self.send_initial_message)

    def send_initial_message(self):
        """发送初始消息"""
        self.add_message("请问这个宝贝还在吗？", is_me=True)

    def send_message(self):
        """发送消息"""
        text = self.input_field.text().strip()
        if text:
            self.add_message(text, is_me=True)
            self.input_field.clear()
            # 模拟卖家回复
            QTimer.singleShot(1000, lambda: self.add_message("还在的，需要的话可以联系我", is_me=False))

    def add_message(self, text, is_me=True):
        """添加消息"""
        if is_me:
            message_html = f"""
            <div style="text-align: right; margin: 10px 0;">
                <span style="background-color: #FFA366; color: white; padding: 8px 12px; border-radius: 12px; display: inline-block;">
                    {text}
                </span>
            </div>
            """
        else:
            message_html = f"""
            <div style="text-align: left; margin: 10px 0;">
                <span style="background-color: white; color: #333; padding: 8px 12px; border-radius: 12px; display: inline-block;">
                    {text}
                </span>
            </div>
            """
        self.chat_area.append(message_html)


class ProductDetailPage(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("商品详情 - 闲转")
        self.setGeometry(100, 100, 1200, 900)
        self.setStyleSheet("background-color: #F8F8F8;")

        # 模拟数据
        self.product_images = [
            "placeholder_image_1.jpg",
            "placeholder_image_2.jpg",
            "placeholder_image_3.jpg",
        ]
        self.current_image_index = 0
        self.is_favorited = False
        self.is_following = False

        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)

        # 滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)

        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(20, 20, 20, 20)
        scroll_layout.setSpacing(20)

        # 主体区（左图右文）
        self.create_main_content()
        scroll_layout.addWidget(self.main_content)

        # 底部评价区和猜你喜欢
        self.create_bottom_section()
        scroll_layout.addWidget(self.bottom_section)

        scroll_content.setLayout(scroll_layout)
        scroll_area.setWidget(scroll_content)
        main_layout.addWidget(scroll_area)

        main_widget.setLayout(main_layout)

    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)

        nav_layout = QHBoxLayout()
        nav_layout.setContentsMargins(20, 10, 20, 10)

        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #666;
                border: none;
                font-size: 14px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                color: #333;
                background-color: #F5F5F5;
                border-radius: 4px;
            }
        """)
        back_btn.clicked.connect(self.close)
        nav_layout.addWidget(back_btn)

        nav_layout.addStretch()

        # 举报按钮
        report_btn = QPushButton("举报")
        report_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #666;
                border: none;
                font-size: 14px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                color: #333;
                background-color: #F5F5F5;
                border-radius: 4px;
            }
        """)
        nav_layout.addWidget(report_btn)

        # 收藏按钮
        self.favorite_btn = QPushButton("☆")
        self.favorite_btn.setFixedSize(40, 40)
        self.favorite_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #666;
                border: none;
                font-size: 24px;
            }
            QPushButton:hover {
                color: #FFA366;
            }
        """)
        self.favorite_btn.clicked.connect(self.toggle_favorite)
        nav_layout.addWidget(self.favorite_btn)

        self.top_nav.setLayout(nav_layout)

    def create_main_content(self):
        """创建主体内容区"""
        self.main_content = QFrame()
        self.main_content.setStyleSheet("background-color: transparent;")

        content_layout = QHBoxLayout()
        content_layout.setSpacing(20)
        content_layout.setContentsMargins(0, 0, 0, 0)

        # 左侧图片预览区
        self.create_image_section()
        content_layout.addWidget(self.image_section, 1)

        # 右侧信息区
        self.create_info_section()
        content_layout.addWidget(self.info_section, 1)

        self.main_content.setLayout(content_layout)

    def create_image_section(self):
        """创建图片预览区"""
        self.image_section = QFrame()
        self.image_section.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
            }
        """)

        layout = QVBoxLayout()
        layout.setSpacing(15)

        # 主图（可点击）
        class ClickableImageLabel(QLabel):
            def __init__(self, parent):
                super().__init__(parent)
                self.parent_window = parent

            def mousePressEvent(self, event: QMouseEvent):
                if event.button() == Qt.MouseButton.LeftButton:
                    self.parent_window.on_main_image_clicked()

        self.main_image_label = ClickableImageLabel(self)
        self.main_image_label.setFixedHeight(500)
        self.main_image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.main_image_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                border-radius: 8px;
            }
        """)
        self.main_image_label.setCursor(Qt.CursorShape.PointingHandCursor)
        self.load_main_image(0)
        layout.addWidget(self.main_image_label)

        # 缩略图栏
        thumbnails_layout = QHBoxLayout()
        thumbnails_layout.setSpacing(10)
        thumbnails_layout.setContentsMargins(0, 0, 0, 0)

        self.thumbnail_widgets = []
        for i, img_path in enumerate(self.product_images):
            thumbnail = ThumbnailWidget(img_path, i, is_selected=(i == 0))
            thumbnail.clicked.connect(self.on_thumbnail_clicked)
            self.thumbnail_widgets.append(thumbnail)
            thumbnails_layout.addWidget(thumbnail)

        thumbnails_layout.addStretch()
        layout.addLayout(thumbnails_layout)

        self.image_section.setLayout(layout)

    def create_info_section(self):
        """创建右侧信息区"""
        self.info_section = QFrame()
        self.info_section.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 25px;
            }
        """)

        layout = QVBoxLayout()
        layout.setSpacing(20)

        # 卖家信息
        self.create_seller_info()
        layout.addWidget(self.seller_info)

        # 商品信息
        self.create_product_info()
        layout.addWidget(self.product_info)

        # 交易区
        self.create_trade_section()
        layout.addWidget(self.trade_section)

        layout.addStretch()

        self.info_section.setLayout(layout)

    def create_seller_info(self):
        """创建卖家信息区"""
        self.seller_info = QFrame()
        self.seller_info.setStyleSheet("background-color: transparent;")

        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)

        # 头像
        avatar_label = QLabel()
        avatar_label.setFixedSize(60, 60)
        avatar_label.setStyleSheet("""
            QLabel {
                background-color: #E0E0E0;
                border-radius: 30px;
            }
        """)
        # 使用文字模拟头像
        avatar_pixmap = QPixmap(60, 60)
        avatar_pixmap.fill(QColor(200, 200, 200))
        painter = QPainter(avatar_pixmap)
        painter.setPen(QColor(100, 100, 100))
        painter.setFont(QFont("Arial", 20))
        painter.drawText(avatar_pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "👤")
        painter.end()
        avatar_label.setPixmap(avatar_pixmap)
        layout.addWidget(avatar_label)

        # 卖家信息
        seller_layout = QVBoxLayout()
        seller_layout.setSpacing(5)

        seller_name = QLabel("卖家昵称")
        seller_name.setStyleSheet("font-size: 16px; font-weight: bold; color: #333;")
        seller_layout.addWidget(seller_name)

        seller_location = QLabel("来自北京市")
        seller_location.setStyleSheet("color: #999; font-size: 12px;")
        seller_layout.addWidget(seller_location)

        seller_sales = QLabel("已售15件")
        seller_sales.setStyleSheet("color: #999; font-size: 12px;")
        seller_layout.addWidget(seller_sales)

        layout.addLayout(seller_layout)
        layout.addStretch()

        # 关注按钮
        self.follow_btn = QPushButton("关注")
        self.follow_btn.setFixedSize(80, 35)
        self.follow_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 17px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        self.follow_btn.clicked.connect(self.toggle_follow)
        layout.addWidget(self.follow_btn)

        self.seller_info.setLayout(layout)

    def create_product_info(self):
        """创建商品信息区"""
        self.product_info = QFrame()
        self.product_info.setStyleSheet("background-color: transparent;")

        layout = QVBoxLayout()
        layout.setSpacing(15)

        # 价格
        price_layout = QHBoxLayout()
        price_layout.setContentsMargins(0, 0, 0, 0)

        price_label = QLabel("¥1,299")
        price_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 36px;
                font-weight: bold;
            }
        """)
        price_layout.addWidget(price_label)

        price_layout.addStretch()

        # 原价
        original_price = QLabel("原价¥2,999")
        original_price.setStyleSheet("""
            QLabel {
                color: #999;
                font-size: 14px;
                text-decoration: line-through;
            }
        """)
        price_layout.addWidget(original_price)

        layout.addLayout(price_layout)

        # 成色标签
        condition_label = QLabel("99新")
        condition_label.setFixedSize(50, 25)
        condition_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                color: #666;
                border-radius: 4px;
                font-size: 12px;
            }
        """)
        condition_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(condition_label)

        # 标题
        title_label = QLabel("99新iPhone14 256G 几乎全新 无划痕 配件齐全")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 20px;
                font-weight: bold;
            }
        """)
        title_label.setWordWrap(True)
        layout.addWidget(title_label)

        # 详情描述
        details_frame = QFrame()
        details_frame.setStyleSheet("background-color: #F8F8F8; border-radius: 8px; padding: 15px;")

        details_layout = QVBoxLayout()
        details_layout.setSpacing(10)

        detail_items = [
            "品牌：苹果",
            "购买时间：2023年5月",
            "描述：几乎全新，无划痕，配件齐全，包装盒都在"
        ]

        for item in detail_items:
            detail_label = QLabel(item)
            detail_label.setStyleSheet("color: #666; font-size: 14px;")
            details_layout.addWidget(detail_label)

        details_frame.setLayout(details_layout)
        layout.addWidget(details_frame)

        self.product_info.setLayout(layout)

    def create_trade_section(self):
        """创建交易区"""
        self.trade_section = QFrame()
        self.trade_section.setStyleSheet("background-color: transparent;")

        layout = QVBoxLayout()
        layout.setSpacing(15)

        # 按钮区
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)

        # 我想要按钮（付款）
        want_btn = QPushButton("我想要")
        want_btn.setFixedHeight(50)
        want_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 25px;
                font-size: 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
            QPushButton:pressed {
                background-color: #FF8C4D;
            }
        """)
        want_btn.clicked.connect(self.on_want_clicked)
        button_layout.addWidget(want_btn, 2)

        # 加入购物车按钮
        cart_btn = QPushButton("加入购物车")
        cart_btn.setFixedHeight(50)
        cart_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                color: #666;
                border: 1px solid #E0E0E0;
                border-radius: 25px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        cart_btn.clicked.connect(self.on_add_to_cart_clicked)
        button_layout.addWidget(cart_btn, 1)

        layout.addLayout(button_layout)

        # 和卖家聊天按钮
        chat_btn = QPushButton("和卖家聊一聊")
        chat_btn.setFixedHeight(45)
        chat_btn.setStyleSheet("""
            QPushButton {
                background-color: white;
                color: #FFA366;
                border: 1px solid #FFA366;
                border-radius: 22px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #FFF8F5;
            }
        """)
        chat_btn.clicked.connect(self.on_chat_clicked)
        layout.addWidget(chat_btn)

        self.trade_section.setLayout(layout)

    def create_bottom_section(self):
        """创建底部区域"""
        self.bottom_section = QFrame()
        self.bottom_section.setStyleSheet("background-color: transparent;")

        layout = QVBoxLayout()
        layout.setSpacing(20)

        # 评价区
        review_frame = QFrame()
        review_frame.setStyleSheet("""
            QFrame {
                background-color: #F5F5F5;
                border-radius: 12px;
                padding: 20px;
            }
        """)

        review_layout = QVBoxLayout()
        review_layout.setSpacing(15)

        review_title = QLabel("宝贝评价 (0条评价)")
        review_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #333;")
        review_layout.addWidget(review_title)

        no_review_label = QLabel("暂无评价")
        no_review_label.setStyleSheet("color: #999; font-size: 14px;")
        no_review_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        review_layout.addWidget(no_review_label)

        review_frame.setLayout(review_layout)
        layout.addWidget(review_frame)

        # 猜你喜欢
        recommend_frame = QFrame()
        recommend_frame.setStyleSheet("background-color: transparent;")

        recommend_layout = QVBoxLayout()
        recommend_layout.setSpacing(15)

        recommend_title = QLabel("猜你喜欢")
        recommend_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #333;")
        recommend_layout.addWidget(recommend_title)

        # 推荐商品横向滚动
        recommend_scroll = QScrollArea()
        recommend_scroll.setWidgetResizable(True)
        recommend_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        recommend_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        recommend_scroll.setStyleSheet("border: none; background-color: transparent;")

        recommend_container = QWidget()
        recommend_container_layout = QHBoxLayout()
        recommend_container_layout.setSpacing(15)

        # 模拟推荐商品
        for i in range(5):
            product_card = self.create_recommend_product_card(f"推荐商品{i+1}", 299 + i * 100)
            recommend_container_layout.addWidget(product_card)

        recommend_container_layout.addStretch()
        recommend_container.setLayout(recommend_container_layout)
        recommend_scroll.setWidget(recommend_container)

        recommend_layout.addWidget(recommend_scroll)
        recommend_frame.setLayout(recommend_layout)
        layout.addWidget(recommend_frame)

        self.bottom_section.setLayout(layout)

    def create_recommend_product_card(self, title, price):
        """创建推荐商品卡片"""
        card = QFrame()
        card.setFixedSize(180, 250)
        card.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 8px;
                border: 1px solid #E0E0E0;
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 图片
        image_label = QLabel()
        image_label.setFixedHeight(180)
        image_label.setStyleSheet("background-color: #F5F5F5; border-top-left-radius: 8px; border-top-right-radius: 8px;")
        layout.addWidget(image_label)

        # 信息
        info_frame = QFrame()
        info_frame.setStyleSheet("padding: 10px;")

        info_layout = QVBoxLayout()
        info_layout.setSpacing(5)

        title_label = QLabel(title)
        title_label.setStyleSheet("color: #333; font-size: 12px;")
        title_label.setWordWrap(True)
        info_layout.addWidget(title_label)

        price_label = QLabel(f"¥{price}")
        price_label.setStyleSheet("color: #FFA366; font-size: 16px; font-weight: bold;")
        info_layout.addWidget(price_label)

        info_frame.setLayout(info_layout)
        layout.addWidget(info_frame)

        card.setLayout(layout)
        return card

    def load_main_image(self, index):
        """加载主图"""
        if 0 <= index < len(self.product_images):
            self.current_image_index = index
            # 创建占位图
            pixmap = QPixmap(500, 500)
            pixmap.fill(QColor(240, 240, 240))
            painter = QPainter(pixmap)
            painter.setPen(QColor(200, 200, 200))
            painter.setFont(QFont("Arial", 24))
            painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, f"商品图片 {index + 1}")
            painter.end()
            self.main_image_label.setPixmap(pixmap)

    def on_thumbnail_clicked(self, index):
        """缩略图点击事件"""
        self.load_main_image(index)
        # 更新选中状态
        for i, widget in enumerate(self.thumbnail_widgets):
            widget.set_selected(i == index)

    def on_main_image_clicked(self):
        """主图点击事件（放大）"""
        viewer = ImageViewerDialog(self.product_images, self.current_image_index, self)
        viewer.setGeometry(self.geometry())
        viewer.exec()

    def toggle_favorite(self):
        """切换收藏状态"""
        self.is_favorited = not self.is_favorited
        if self.is_favorited:
            self.favorite_btn.setText("★")
            self.favorite_btn.setStyleSheet("""
                QPushButton {
                    background-color: transparent;
                    color: #FFA366;
                    border: none;
                    font-size: 24px;
                }
            """)
            self.show_toast("收藏成功～")
        else:
            self.favorite_btn.setText("☆")
            self.favorite_btn.setStyleSheet("""
                QPushButton {
                    background-color: transparent;
                    color: #666;
                    border: none;
                    font-size: 24px;
                }
                QPushButton:hover {
                    color: #FFA366;
                }
            """)

    def toggle_follow(self):
        """切换关注状态"""
        self.is_following = not self.is_following
        if self.is_following:
            self.follow_btn.setText("已关注")
            self.follow_btn.setStyleSheet("""
                QPushButton {
                    background-color: #F5F5F5;
                    color: #666;
                    border: 1px solid #E0E0E0;
                    border-radius: 17px;
                    font-size: 14px;
                }
            """)
        else:
            self.follow_btn.setText("关注")
            self.follow_btn.setStyleSheet("""
                QPushButton {
                    background-color: #FFA366;
                    color: white;
                    border: none;
                    border-radius: 17px;
                    font-size: 14px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #FFB380;
                }
            """)

    def on_want_clicked(self):
        """我想要按钮点击（弹出付款界面）"""
        try:
            from payment_page import PaymentPage
            
            # 商品信息
            product_info = {
                'title': '99新iPhone14 256G 几乎全新 无划痕 配件齐全',
                'price': 1299
            }
            
            payment_dialog = PaymentPage(product_info, self)
            payment_dialog.payment_success.connect(self.on_payment_success)
            
            # 居中显示
            payment_dialog.exec()
        except Exception as e:
            print(f"打开付款界面失败: {e}")

    def on_chat_clicked(self):
        """和卖家聊天按钮点击"""
        try:
            from chat_page import ChatPage
            chat_window = ChatPage(self)  # 传递父窗口
            chat_window.show()
        except Exception as e:
            print(f"打开聊天页面失败: {e}")
            import traceback
            traceback.print_exc()

    def on_add_to_cart_clicked(self):
        """加入购物车按钮点击"""
        import random
        from datetime import datetime
        
        # 创建订单（状态为待付款）
        order_id = f"CART{random.randint(1000, 9999)}"
        order_info = {
            'id': order_id,
            'title': '99新iPhone14 256G 几乎全新 无划痕 配件齐全',
            'price': 1299,
            'quantity': 1,
            'status': '待付款',  # 购物车商品状态为待付款
            'order_time': datetime.now().strftime('%Y-%m-%d %H:%M'),
            'order_number': order_id
        }
        
        self.show_toast("已加入购物车")
        # 注意：实际应用中应该将订单保存到数据库或订单管理系统中

    def on_payment_success(self, order_info):
        """付款成功回调"""
        self.show_toast("付款成功！订单已创建")
        # 注意：实际应用中应该将订单保存到数据库或订单管理系统中
        # 订单状态已经是'待发货'，可以在订单页面查看

    def show_toast(self, message):
        """显示Toast提示"""
        toast = QLabel(message, self)
        toast.setStyleSheet("""
            QLabel {
                background-color: rgba(0, 0, 0, 0.8);
                color: white;
                padding: 10px 20px;
                border-radius: 20px;
                font-size: 14px;
            }
        """)
        toast.setAlignment(Qt.AlignmentFlag.AlignCenter)
        toast.adjustSize()
        
        # 居中显示
        x = (self.width() - toast.width()) // 2
        y = self.height() // 2
        toast.move(x, y)
        toast.show()

        # 2秒后隐藏
        QTimer.singleShot(2000, toast.hide)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ProductDetailPage()
    window.show()
    sys.exit(app.exec())

