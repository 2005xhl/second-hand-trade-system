import tkinter as tk
from tkinter import messagebox


class LoginPage:
    def __init__(self, root):
        self.root = root
        self.root.title("闲转 - 二手交易平台")
        self.root.geometry("1000x750")
        self.root.resizable(False, False)

        # 浅黄底色
        self.bg_color = "#FFF8E1"  # 浅黄色
        self.card_color = "#FFFFFF"  # 白色卡片
        self.orange_color = "#FF6B35"  # 橙色
        self.orange_dark = "#E55A2B"  # 深橙色（hover）
        self.gray_color = "#999999"  # 灰色
        self.blue_color = "#1890FF"  # 蓝色
        self.error_color = "#FF4D4F"  # 红色

        self.root.configure(bg=self.bg_color)

        # 密码显示状态
        self.password_visible = False
        self.password_placeholder = True

        # 创建界面
        self.create_widgets()

        # 绑定回车键
        self.root.bind('<Return>', lambda e: self.login())

    def create_widgets(self):
        # 主容器
        main_frame = tk.Frame(self.root, bg=self.bg_color)
        main_frame.pack(fill=tk.BOTH, expand=True)

        # 顶部标题区域
        title_frame = tk.Frame(main_frame, bg=self.bg_color)
        title_frame.pack(pady=(80, 20))

        # 大号橙色标题
        title_label = tk.Label(
            title_frame,
            text="闲转 - 二手交易平台",
            font=("Microsoft YaHei", 32, "bold"),
            fg=self.orange_color,
            bg=self.bg_color
        )
        title_label.pack()

        # 小字提示
        subtitle_label = tk.Label(
            title_frame,
            text="登录后体验更多功能",
            font=("Microsoft YaHei", 12),
            fg=self.gray_color,
            bg=self.bg_color
        )
        subtitle_label.pack(pady=(8, 0))

        # 登录卡片容器（增大尺寸）
        card_frame = tk.Frame(
            main_frame,
            bg=self.card_color,
            relief=tk.FLAT,
            width=550,  # 增大卡片宽度
            height=500  # 增大卡片高度
        )
        card_frame.pack(pady=20, padx=50)
        card_frame.pack_propagate(False)  # 禁止卡片随内容收缩

        # 添加阴影效果（通过多层Frame模拟）
        shadow_frame = tk.Frame(
            main_frame,
            bg="#E0E0E0",
            relief=tk.FLAT
        )
        shadow_frame.place(in_=card_frame, x=3, y=3, relwidth=1, relheight=1)
        card_frame.lift()

        # 卡片内容
        card_content = tk.Frame(card_frame, bg=self.card_color)
        card_content.pack(padx=50, pady=40, fill=tk.BOTH, expand=True)

        # 错误提示区域（初始隐藏）
        self.error_label = tk.Label(
            card_content,
            text="",
            font=("Microsoft YaHei", 11),
            fg=self.error_color,
            bg=self.card_color,
            wraplength=300
        )
        self.error_label.pack(pady=(0, 20))

        # 用户名输入区域
        username_frame = tk.Frame(card_content, bg=self.card_color)
        username_frame.pack(pady=(0, 15), fill=tk.X)

        # 用户名图标（使用文本模拟）
        username_icon = tk.Label(
            username_frame,
            text="👤",
            font=("Arial", 16),
            bg=self.card_color,
            fg=self.gray_color
        )
        username_icon.pack(side=tk.LEFT, padx=(0, 10))

        # 用户名输入框容器
        username_input_frame = tk.Frame(username_frame, bg=self.card_color)
        username_input_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.username_entry = tk.Entry(
            username_input_frame,
            font=("Microsoft YaHei", 12),
            relief=tk.FLAT,
            bd=2,
            highlightthickness=1,
            highlightbackground="#E0E0E0",
            highlightcolor=self.orange_color,
            insertbackground=self.orange_color
        )
        self.username_entry.pack(fill=tk.X, ipady=8)
        self.username_entry.insert(0, "请输入用户名")
        self.username_entry.config(fg=self.gray_color)
        self.username_entry.bind('<FocusIn>', self.on_username_focus_in)
        self.username_entry.bind('<FocusOut>', self.on_username_focus_out)

        # 用户名错误提示
        self.username_error = tk.Label(
            username_input_frame,
            text="",
            font=("Microsoft YaHei", 9),
            fg=self.error_color,
            bg=self.card_color,
            anchor="w"
        )
        self.username_error.pack(fill=tk.X, pady=(3, 0))

        # 密码输入区域
        password_frame = tk.Frame(card_content, bg=self.card_color)
        password_frame.pack(pady=(0, 15), fill=tk.X)

        # 密码图标
        password_icon = tk.Label(
            password_frame,
            text="🔒",
            font=("Arial", 16),
            bg=self.card_color,
            fg=self.gray_color
        )
        password_icon.pack(side=tk.LEFT, padx=(0, 10))

        # 密码输入框容器
        password_input_frame = tk.Frame(password_frame, bg=self.card_color)
        password_input_frame.pack(side=tk.LEFT, fill=tk.X, expand=True)

        self.password_entry = tk.Entry(
            password_input_frame,
            font=("Microsoft YaHei", 12),
            relief=tk.FLAT,
            bd=2,
            show="*",
            highlightthickness=1,
            highlightbackground="#E0E0E0",
            highlightcolor=self.orange_color,
            insertbackground=self.orange_color
        )
        self.password_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, ipady=8)
        self.password_entry.insert(0, "请输入密码")
        self.password_entry.config(fg=self.gray_color)
        self.password_entry.bind('<FocusIn>', self.on_password_focus_in)
        self.password_entry.bind('<FocusOut>', self.on_password_focus_out)

        # 显示/隐藏密码按钮
        self.password_toggle = tk.Button(
            password_input_frame,
            text="显示密码",
            font=("Microsoft YaHei", 9),
            fg=self.gray_color,
            bg=self.card_color,
            relief=tk.FLAT,
            cursor="hand2",
            command=self.toggle_password
        )
        self.password_toggle.pack(side=tk.RIGHT, padx=(5, 0))

        # 密码错误提示
        self.password_error = tk.Label(
            password_input_frame,
            text="",
            font=("Microsoft YaHei", 9),
            fg=self.error_color,
            bg=self.card_color,
            anchor="w"
        )
        self.password_error.pack(fill=tk.X, pady=(3, 0))

        # 按钮区域（居中布局）
        button_frame = tk.Frame(card_content, bg=self.card_color)
        button_frame.pack(pady=(10, 0), fill=tk.X)

        # 登录按钮和忘记密码在同一行
        login_forgot_frame = tk.Frame(button_frame, bg=self.card_color)
        login_forgot_frame.pack(expand=True, pady=(0, 8))  # 减小间距

        # 登录按钮（减小尺寸）
        self.login_button = tk.Button(
            login_forgot_frame,
            text="登录",
            font=("Microsoft YaHei", 12, "bold"),  # 统一字体大小
            fg="white",
            bg=self.orange_color,
            relief=tk.FLAT,
            cursor="hand2",
            command=self.login,
            padx=25,  # 减小内边距
            pady=8   # 减小内边距
        )
        self.login_button.pack(side=tk.LEFT)

        # 绑定hover效果
        self.login_button.bind('<Enter>', lambda e: self.login_button.config(bg=self.orange_dark))
        self.login_button.bind('<Leave>', lambda e: self.login_button.config(bg=self.orange_color))

        # 忘记密码（在登录按钮右侧）
        forgot_link = tk.Label(
            login_forgot_frame,
            text="忘记密码？",
            font=("Microsoft YaHei", 12),  # 统一字体大小
            fg=self.gray_color,
            bg=self.card_color,
            cursor="hand2"
        )
        forgot_link.pack(side=tk.LEFT, padx=(15, 0))
        forgot_link.bind('<Button-1>', lambda e: self.show_forgot_password())

        # 注册链接区域（真正居中显示）
        register_frame = tk.Frame(card_content, bg=self.card_color)
        register_frame.pack(pady=(5, 0), fill=tk.X)  # 减小间距

        # 使用居中容器
        register_center = tk.Frame(register_frame, bg=self.card_color)
        register_center.pack(expand=True)

        register_text = tk.Label(
            register_center,
            text="还没账号？",
            font=("Microsoft YaHei", 12),  # 统一字体大小
            fg=self.gray_color,
            bg=self.card_color
        )
        register_text.pack(side=tk.LEFT)

        register_link = tk.Label(
            register_center,
            text="去注册",
            font=("Microsoft YaHei", 12),  # 统一字体大小，去掉bold
            fg=self.blue_color,
            bg=self.card_color,
            cursor="hand2"
        )
        register_link.pack(side=tk.LEFT, padx=(5, 0))
        register_link.bind('<Button-1>', lambda e: self.show_register())
        
        # 添加hover效果
        def on_enter(e):
            register_link.config(fg="#0050B3", underline=True)
        def on_leave(e):
            register_link.config(fg=self.blue_color, underline=False)
        register_link.bind('<Enter>', on_enter)
        register_link.bind('<Leave>', on_leave)

    def on_username_focus_in(self, event):
        if self.username_entry.get() == "请输入用户名":
            self.username_entry.delete(0, tk.END)
            self.username_entry.config(fg="black")
        # 清除错误状态
        self.username_entry.config(highlightbackground="#E0E0E0")
        self.username_error.config(text="")

    def on_username_focus_out(self, event):
        if not self.username_entry.get():
            self.username_entry.insert(0, "请输入用户名")
            self.username_entry.config(fg=self.gray_color)

    def on_password_focus_in(self, event):
        if self.password_placeholder:
            self.password_entry.delete(0, tk.END)
            self.password_entry.config(fg="black", show="*")
            self.password_placeholder = False
        # 清除错误状态
        self.password_entry.config(highlightbackground="#E0E0E0")
        self.password_error.config(text="")

    def on_password_focus_out(self, event):
        if not self.password_entry.get():
            self.password_entry.insert(0, "请输入密码")
            self.password_entry.config(fg=self.gray_color, show="")
            self.password_placeholder = True
            self.password_visible = False
            self.password_toggle.config(text="显示密码")

    def toggle_password(self):
        # 如果还在占位符状态，不执行切换
        if self.password_placeholder:
            return

        self.password_visible = not self.password_visible
        current_text = self.password_entry.get()

        if self.password_visible:
            self.password_entry.config(show="")
            self.password_toggle.config(text="隐藏密码")
        else:
            self.password_entry.config(show="*")
            self.password_toggle.config(text="显示密码")

    def validate_input(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        # 清除之前的错误
        self.error_label.config(text="")
        self.username_error.config(text="")
        self.password_error.config(text="")
        self.username_entry.config(highlightbackground="#E0E0E0")
        self.password_entry.config(highlightbackground="#E0E0E0")

        has_error = False

        # 检查用户名
        if not username or username == "请输入用户名":
            self.username_entry.config(highlightbackground=self.error_color)
            self.username_error.config(text="请填写用户名")
            has_error = True

        # 检查密码（考虑占位符状态）
        if not password or password == "请输入密码" or self.password_placeholder:
            self.password_entry.config(highlightbackground=self.error_color)
            self.password_error.config(text="请填写密码")
            has_error = True

        return not has_error, username, password

    def login(self):
        is_valid, username, password = self.validate_input()

        if not is_valid:
            return

        # 模拟登录验证（这里可以替换为实际的验证逻辑）
        # 示例：用户名和密码都是 "admin" 时登录成功
        if username == "admin" and password == "admin":
            # 登录成功
            self.show_success()
        else:
            # 登录失败
            self.error_label.config(text="用户名或密码错误，请重试")
            self.username_entry.config(highlightbackground=self.error_color)
            self.password_entry.config(highlightbackground=self.error_color)

    def show_success(self):
        # 显示成功Toast提示
        toast = tk.Toplevel(self.root)
        toast.overrideredirect(True)
        toast.configure(bg=self.orange_color)
        toast.geometry("200x50")

        # 居中显示
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - 100
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - 25
        toast.geometry(f"200x50+{x}+{y}")

        toast_label = tk.Label(
            toast,
            text="登录成功～",
            font=("Microsoft YaHei", 12, "bold"),
            fg="white",
            bg=self.orange_color
        )
        toast_label.pack(expand=True)

        # 2秒后关闭Toast并跳转（这里可以跳转到商品列表页）
        toast.after(2000, lambda: (toast.destroy(), self.transition_to_product_list()))

    def transition_to_product_list(self):
        # 关闭登录窗口，打开主界面
        try:
            from main_page import MainWindow
            import sys
            from PyQt6.QtWidgets import QApplication
            
            # 创建新的应用实例（如果还没有）
            if not QApplication.instance():
                app = QApplication(sys.argv)
            else:
                app = QApplication.instance()
            
            # 打开主界面
            main_window = MainWindow()
            main_window.show()
            
            # 关闭登录窗口
            self.root.destroy()
            
            # 运行应用
            if not QApplication.instance():
                sys.exit(app.exec())
        except Exception as e:
            messagebox.showinfo("提示", f"登录成功！\n打开主界面失败: {e}")

    def show_register(self):
        """跳转到注册页面"""
        try:
            # 导入注册页面
            from register_page import RegisterPage

            # 创建新的注册窗口（使用Toplevel，这样不会阻塞主循环）
            register_window = tk.Toplevel(self.root)
            register_window.title("注册 - 闲转")
            register_window.geometry("800x700")
            register_window.resizable(False, False)
            register_window.transient(self.root)

            def back_to_login():
                register_window.destroy()
                self.root.lift()
                self.root.focus_force()

            def on_close():
                register_window.destroy()
                self.root.lift()
                self.root.focus_force()

            register_window.protocol("WM_DELETE_WINDOW", on_close)

            RegisterPage(register_window, back_to_login)
            register_window.focus_force()
            register_window.lift()
        except Exception as e:
            # 如果出错，显示错误信息
            import traceback
            messagebox.showerror("错误", f"无法打开注册页面：{str(e)}")

    def on_register_close(self, register_window):
        """注册窗口关闭时的处理"""
        try:
            register_window.quit()
        except:
            pass
        register_window.destroy()
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()

    def show_forgot_password(self):
        messagebox.showinfo(
            "忘记密码",
            "联系管理员重置：\nXXX-XXXXXXX"
        )


def main():
    root = tk.Tk()
    app = LoginPage(root)
    root.mainloop()


if __name__ == "__main__":
    main()