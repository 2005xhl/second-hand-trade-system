"""
我的发布页面
显示用户已发布的商品列表，点击进入商品详情页
"""
import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QGridLayout)
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor


class MyPostCard(QFrame):
    """已发布商品卡片"""
    clicked = None
    
    def __init__(self, product_data, parent=None):
        super().__init__(parent)
        self.product_data = product_data
        
        self.setFixedSize(200, 280)
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                border: 1px solid #E0E0E0;
            }
            QFrame:hover {
                border: 2px solid #FFA366;
                background-color: #FFF8F5;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # 商品图片
        image_label = QLabel()
        image_label.setFixedSize(180, 180)
        image_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                border-radius: 8px;
            }
        """)
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # 绘制占位图
        pixmap = QPixmap(180, 180)
        pixmap.fill(QColor(245, 245, 245))
        painter = QPainter(pixmap)
        painter.setPen(QColor(200, 200, 200))
        painter.setFont(QFont("Arial", 40))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "📷")
        painter.end()
        image_label.setPixmap(pixmap)
        
        layout.addWidget(image_label)
        
        # 商品标题
        title_label = QLabel(product_data.get("title", "商品标题"))
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        title_label.setWordWrap(True)
        title_label.setMaximumHeight(40)
        layout.addWidget(title_label)
        
        # 价格和状态
        price_status_layout = QHBoxLayout()
        price_status_layout.setContentsMargins(0, 0, 0, 0)
        
        price_label = QLabel(f"¥{product_data.get('price', 0)}")
        price_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        price_status_layout.addWidget(price_label)
        price_status_layout.addStretch()
        
        # 状态标签
        status = product_data.get("status", "审核中")
        status_label = QLabel(status)
        status_color = "#999" if status == "审核中" else "#52C41A" if status == "已上架" else "#FF4444"
        status_label.setStyleSheet(f"""
            QLabel {{
                color: {status_color};
                font-size: 12px;
                padding: 2px 8px;
                border-radius: 4px;
                background-color: rgba(0, 0, 0, 0.05);
            }}
        """)
        price_status_layout.addWidget(status_label)
        
        layout.addLayout(price_status_layout)
        
        layout.addStretch()
        self.setLayout(layout)
    
    def mousePressEvent(self, event):
        """点击事件"""
        if event.button() == Qt.MouseButton.LeftButton and self.clicked:
            self.clicked()


class MyPostsPage(QMainWindow):
    """我的发布页面"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("我的发布 - 闲转")
        self.setGeometry(100, 100, 1200, 800)
        self.setStyleSheet("background-color: #F8F8F8;")
        
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)
        
        # 商品列表
        self.create_product_list()
        main_layout.addWidget(self.product_list_area)
        
        main_widget.setLayout(main_layout)
        
        # 加载已发布商品
        self.load_my_posts()
    
    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        
        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333;
                border: none;
                font-size: 16px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #F5F5F5;
                border-radius: 5px;
            }
        """)
        back_btn.clicked.connect(self.close)
        layout.addWidget(back_btn)
        
        # 标题
        title_label = QLabel("我的发布")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label, 1)
        
        self.top_nav.setLayout(layout)
    
    def create_product_list(self):
        """创建商品列表"""
        self.product_list_area = QScrollArea()
        self.product_list_area.setWidgetResizable(True)
        self.product_list_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(20, 20, 20, 20)
        scroll_layout.setSpacing(20)
        
        # 商品网格
        self.product_grid = QWidget()
        self.grid_layout = QGridLayout()
        self.grid_layout.setSpacing(15)
        self.grid_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.product_grid.setLayout(self.grid_layout)
        
        scroll_layout.addWidget(self.product_grid)
        scroll_layout.addStretch()
        
        scroll_content.setLayout(scroll_layout)
        self.product_list_area.setWidget(scroll_content)
    
    def load_my_posts(self):
        """加载已发布商品"""
        # 模拟已发布商品数据
        my_posts = [
            {"id": 1, "title": "99新iPhone14 256G", "price": 1299, "status": "已上架"},
            {"id": 2, "title": "二手MacBook Pro 13寸", "price": 5999, "status": "已上架"},
            {"id": 3, "title": "AirPods Pro 2代", "price": 899, "status": "审核中"},
            {"id": 4, "title": "iPad Air 5代", "price": 2999, "status": "已下架"},
        ]
        
        row = 0
        col = 0
        for post in my_posts:
            card = MyPostCard(post)
            
            # 设置点击事件（使用闭包捕获正确的商品ID）
            product_id = post["id"]  # 在循环中创建局部变量
            card.clicked = lambda pid=product_id: self.open_product_detail(pid)
            
            self.grid_layout.addWidget(card, row, col)
            col += 1
            if col >= 5:  # 每行5个
                col = 0
                row += 1
    
    def open_product_detail(self, product_id):
        """打开商品详情页"""
        from product_detail_page import ProductDetailPage
        detail_window = ProductDetailPage()
        detail_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyPostsPage()
    window.show()
    sys.exit(app.exec())

