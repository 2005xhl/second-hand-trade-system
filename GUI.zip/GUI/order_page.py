import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QMessageBox, QDialog, QDialogButtonBox)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor


class FilterButton(QPushButton):
    """筛选按钮"""
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.is_selected = False
        self.update_style()

    def set_selected(self, selected):
        """设置选中状态"""
        self.is_selected = selected
        self.update_style()

    def update_style(self):
        """更新样式"""
        if self.is_selected:
            self.setStyleSheet("""
                QPushButton {
                    background-color: #FFA366;
                    color: white;
                    border: none;
                    border-radius: 15px;
                    padding: 6px 20px;
                    font-size: 14px;
                    font-weight: bold;
                }
            """)
        else:
            self.setStyleSheet("""
                QPushButton {
                    background-color: #F5F5F5;
                    color: #666;
                    border: none;
                    border-radius: 15px;
                    padding: 6px 20px;
                    font-size: 14px;
                }
                QPushButton:hover {
                    background-color: #E0E0E0;
                }
            """)


class OrderCard(QFrame):
    """订单卡片"""
    action_requested = pyqtSignal(str, str)  # 操作类型, 订单ID

    def __init__(self, order_data, parent=None):
        super().__init__(parent)
        self.order_data = order_data
        self.order_id = order_data.get('id', '')
        self.status = order_data.get('status', '待付款')

        # 根据状态设置边框颜色
        border_colors = {
            '待付款': '#FFD700',  # 黄色
            '待发货': '#1890FF',  # 蓝色
            '待收货': '#52C41A',  # 绿色
            '已完成': '#D0D0D0',  # 灰色
            '已取消': '#D0D0D0'   # 灰色
        }
        border_color = border_colors.get(self.status, '#E0E0E0')

        self.setStyleSheet(f"""
            QFrame {{
                background-color: white;
                border: 2px solid {border_color};
                border-radius: 12px;
                padding: 15px;
            }}
        """)

        layout = QVBoxLayout()
        layout.setSpacing(15)

        # 商品信息行
        product_layout = QHBoxLayout()
        product_layout.setSpacing(15)

        # 商品缩略图
        image_label = QLabel()
        image_label.setFixedSize(100, 100)
        image_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                border-radius: 8px;
            }
        """)
        # 创建占位图
        pixmap = QPixmap(100, 100)
        pixmap.fill(QColor(240, 240, 240))
        painter = QPainter(pixmap)
        painter.setPen(QColor(200, 200, 200))
        painter.setFont(QFont("Arial", 12))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "商品图")
        painter.end()
        image_label.setPixmap(pixmap)
        product_layout.addWidget(image_label)

        # 商品信息
        info_layout = QVBoxLayout()
        info_layout.setSpacing(8)
        info_layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        # 商品标题
        title_label = QLabel(order_data.get('title', '商品标题'))
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        title_label.setWordWrap(True)
        info_layout.addWidget(title_label)

        # 数量
        quantity_label = QLabel(f"x{order_data.get('quantity', 1)}")
        quantity_label.setStyleSheet("color: #999; font-size: 14px;")
        info_layout.addWidget(quantity_label)

        info_layout.addStretch()
        product_layout.addLayout(info_layout, 1)

        # 右侧价格和操作
        right_layout = QVBoxLayout()
        right_layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignRight)
        right_layout.setSpacing(10)

        # 价格
        price_label = QLabel(f"¥{order_data.get('price', 0)}")
        price_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 20px;
                font-weight: bold;
            }
        """)
        right_layout.addWidget(price_label)

        # 状态标签
        status_label = QLabel(self.status)
        status_colors = {
            '待付款': '#FFD700',
            '待发货': '#1890FF',
            '待收货': '#52C41A',
            '已完成': '#999999',
            '已取消': '#999999'
        }
        status_color = status_colors.get(self.status, '#999999')
        status_label.setStyleSheet(f"""
            QLabel {{
                color: {status_color};
                font-size: 14px;
                font-weight: bold;
                padding: 4px 8px;
                background-color: {status_color}20;
                border-radius: 4px;
            }}
        """)
        right_layout.addWidget(status_label)

        # 操作按钮
        self.create_action_buttons(right_layout)

        right_layout.addStretch()
        product_layout.addLayout(right_layout)
        layout.addLayout(product_layout)

        # 底部信息
        bottom_layout = QHBoxLayout()
        bottom_layout.setContentsMargins(0, 0, 0, 0)

        order_time = QLabel(f"下单时间：{order_data.get('order_time', '2024-01-01')}")
        order_time.setStyleSheet("color: #999; font-size: 12px;")
        bottom_layout.addWidget(order_time)

        bottom_layout.addStretch()

        order_number = QLabel(f"订单编号：{order_data.get('order_number', 'XXXXXXXXXX')}")
        order_number.setStyleSheet("color: #999; font-size: 12px;")
        bottom_layout.addWidget(order_number)

        layout.addLayout(bottom_layout)

        self.setLayout(layout)

    def create_action_buttons(self, layout):
        """创建操作按钮"""
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)

        if self.status == '待付款':
            # 立即付款
            pay_btn = QPushButton("立即付款")
            pay_btn.setFixedSize(90, 32)
            pay_btn.setStyleSheet("""
                QPushButton {
                    background-color: #FFA366;
                    color: white;
                    border: none;
                    border-radius: 16px;
                    font-size: 13px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #FFB380;
                }
            """)
            pay_btn.clicked.connect(lambda: self.action_requested.emit('pay', self.order_id))
            button_layout.addWidget(pay_btn)

            # 取消订单
            cancel_btn = QPushButton("取消订单")
            cancel_btn.setFixedSize(90, 32)
            cancel_btn.setStyleSheet("""
                QPushButton {
                    background-color: #F5F5F5;
                    color: #666;
                    border: 1px solid #E0E0E0;
                    border-radius: 16px;
                    font-size: 13px;
                }
                QPushButton:hover {
                    background-color: #E0E0E0;
                }
            """)
            cancel_btn.clicked.connect(lambda: self.action_requested.emit('cancel', self.order_id))
            button_layout.addWidget(cancel_btn)

        elif self.status == '待收货':
            # 确认收货
            confirm_btn = QPushButton("确认收货")
            confirm_btn.setFixedSize(90, 32)
            confirm_btn.setStyleSheet("""
                QPushButton {
                    background-color: #FFA366;
                    color: white;
                    border: none;
                    border-radius: 16px;
                    font-size: 13px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #FFB380;
                }
            """)
            confirm_btn.clicked.connect(lambda: self.action_requested.emit('confirm', self.order_id))
            button_layout.addWidget(confirm_btn)

            # 申请售后
            after_sale_btn = QPushButton("申请售后")
            after_sale_btn.setFixedSize(90, 32)
            after_sale_btn.setStyleSheet("""
                QPushButton {
                    background-color: #F5F5F5;
                    color: #666;
                    border: 1px solid #E0E0E0;
                    border-radius: 16px;
                    font-size: 13px;
                }
                QPushButton:hover {
                    background-color: #E0E0E0;
                }
            """)
            after_sale_btn.clicked.connect(lambda: self.action_requested.emit('after_sale', self.order_id))
            button_layout.addWidget(after_sale_btn)

        button_layout.addStretch()
        layout.addLayout(button_layout)


class EmptyStateWidget(QWidget):
    """空状态组件"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("background-color: transparent;")

        layout = QVBoxLayout()
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(20)

        # 插画（用文字模拟）
        illustration_label = QLabel("🐟")
        illustration_label.setStyleSheet("""
            QLabel {
                font-size: 80px;
            }
        """)
        illustration_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(illustration_label)

        # 提示文字
        hint_label = QLabel("暂无订单，快去逛逛～")
        hint_label.setStyleSheet("""
            QLabel {
                color: #999;
                font-size: 16px;
            }
        """)
        hint_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(hint_label)

        # 去首页按钮
        home_btn = QPushButton("去首页")
        home_btn.setFixedSize(120, 40)
        home_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        layout.addWidget(home_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        self.setLayout(layout)


class OrderPage(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("我的订单 - 闲转")
        self.setGeometry(100, 100, 1000, 800)
        self.setStyleSheet("background-color: #F8F8F8;")

        # 当前筛选状态
        self.current_filter = "全部"

        # 模拟订单数据
        self.all_orders = [
            {
                'id': '001',
                'title': '99新iPhone14 256G 几乎全新 无划痕',
                'price': 1299,
                'quantity': 1,
                'status': '待付款',
                'order_time': '2024-01-15 10:30',
                'order_number': 'ORD20240115001'
            },
            {
                'id': '002',
                'title': '二手MacBook Pro 13寸 M1芯片',
                'price': 5999,
                'quantity': 1,
                'status': '待发货',
                'order_time': '2024-01-14 15:20',
                'order_number': 'ORD20240114002'
            },
            {
                'id': '003',
                'title': '全新未拆封 AirPods Pro 2代',
                'price': 1299,
                'quantity': 1,
                'status': '待收货',
                'order_time': '2024-01-13 09:15',
                'order_number': 'ORD20240113003'
            },
            {
                'id': '004',
                'title': '二手相机 Canon EOS R5',
                'price': 8999,
                'quantity': 1,
                'status': '已完成',
                'order_time': '2024-01-10 14:45',
                'order_number': 'ORD20240110004'
            }
        ]

        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)

        # 筛选栏
        self.create_filter_bar()
        main_layout.addWidget(self.filter_bar)

        # 订单列表区域
        self.create_order_list()
        main_layout.addWidget(self.order_scroll_area)

        main_widget.setLayout(main_layout)

        # 初始化显示
        self.filter_orders("全部")

    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(70)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)

        nav_layout = QHBoxLayout()
        nav_layout.setContentsMargins(20, 15, 20, 15)

        # 标题
        title_label = QLabel("我的订单")
        title_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 24px;
                font-weight: bold;
            }
        """)
        nav_layout.addWidget(title_label)

        nav_layout.addStretch()

        self.top_nav.setLayout(nav_layout)

    def create_filter_bar(self):
        """创建筛选栏"""
        self.filter_bar = QFrame()
        self.filter_bar.setFixedHeight(60)
        self.filter_bar.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)

        filter_layout = QHBoxLayout()
        filter_layout.setContentsMargins(20, 10, 20, 10)
        filter_layout.setSpacing(10)

        # 筛选按钮
        self.filter_buttons = []
        filter_options = ["全部", "待付款", "待发货", "待收货", "已完成", "已取消"]
        
        for option in filter_options:
            btn = FilterButton(option)
            btn.clicked.connect(lambda checked, opt=option: self.filter_orders(opt))
            self.filter_buttons.append(btn)
            filter_layout.addWidget(btn)

        filter_layout.addStretch()
        self.filter_bar.setLayout(filter_layout)

        # 默认选中"全部"
        self.filter_buttons[0].set_selected(True)

    def create_order_list(self):
        """创建订单列表"""
        self.order_scroll_area = QScrollArea()
        self.order_scroll_area.setWidgetResizable(True)
        self.order_scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)

        self.order_container = QWidget()
        self.order_layout = QVBoxLayout()
        self.order_layout.setContentsMargins(20, 20, 20, 20)
        self.order_layout.setSpacing(15)

        self.order_container.setLayout(self.order_layout)
        self.order_scroll_area.setWidget(self.order_container)

    def filter_orders(self, status):
        """筛选订单"""
        self.current_filter = status

        # 更新按钮状态
        for btn in self.filter_buttons:
            btn.set_selected(btn.text() == status)

        # 筛选订单
        if status == "全部":
            filtered_orders = self.all_orders
        else:
            filtered_orders = [order for order in self.all_orders if order['status'] == status]

        # 清空现有订单卡片
        while self.order_layout.count():
            item = self.order_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # 显示订单或空状态
        if filtered_orders:
            for order_data in filtered_orders:
                order_card = OrderCard(order_data)
                order_card.action_requested.connect(self.handle_order_action)
                self.order_layout.addWidget(order_card)
        else:
            empty_state = EmptyStateWidget()
            self.order_layout.addWidget(empty_state)

        self.order_layout.addStretch()

    def handle_order_action(self, action_type, order_id):
        """处理订单操作"""
        if action_type == 'cancel':
            self.cancel_order(order_id)
        elif action_type == 'confirm':
            self.confirm_receipt(order_id)
        elif action_type == 'pay':
            self.pay_order(order_id)
        elif action_type == 'after_sale':
            self.apply_after_sale(order_id)

    def cancel_order(self, order_id):
        """取消订单"""
        reply = QMessageBox.question(
            self,
            "确认取消",
            "确定取消订单吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            # 更新订单状态
            for order in self.all_orders:
                if order['id'] == order_id:
                    order['status'] = '已取消'
                    break

            # 显示提示
            self.show_toast("订单已取消", "#52C41A")

            # 刷新列表
            self.filter_orders(self.current_filter)

    def confirm_receipt(self, order_id):
        """确认收货"""
        reply = QMessageBox.question(
            self,
            "确认收货",
            "确认收到宝贝了吗？",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            # 更新订单状态
            for order in self.all_orders:
                if order['id'] == order_id:
                    order['status'] = '已完成'
                    break

            # 显示提示
            self.show_toast("交易成功！", "#FFA366")

            # 刷新列表
            self.filter_orders(self.current_filter)

    def pay_order(self, order_id):
        """支付订单"""
        QMessageBox.information(self, "提示", "跳转到支付页面...")

    def show_toast(self, message, color="#FFA366"):
        """显示Toast提示"""
        toast = QLabel(message, self)
        toast.setStyleSheet(f"""
            QLabel {{
                background-color: {color};
                color: white;
                padding: 12px 24px;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }}
        """)
        toast.setAlignment(Qt.AlignmentFlag.AlignCenter)
        toast.adjustSize()
        
        # 居中显示
        x = (self.width() - toast.width()) // 2
        y = self.height() // 2
        toast.move(x, y)
        toast.show()

        # 2秒后隐藏
        QTimer.singleShot(2000, toast.hide)
    
    def apply_after_sale(self, order_id):
        """申请售后"""
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QTextEdit, QPushButton
        dialog = QDialog(self)
        dialog.setWindowTitle("申请售后")
        dialog.setFixedSize(500, 400)
        dialog.setStyleSheet("""
            QDialog {
                background-color: white;
                border-radius: 12px;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(30, 30, 30, 30)
        
        # 标题
        title_label = QLabel("申请售后")
        title_label.setStyleSheet("""
            QLabel {
                font-size: 18px;
                font-weight: bold;
                color: #333;
            }
        """)
        layout.addWidget(title_label)
        
        # 订单信息
        order_info = QLabel(f"订单编号：{order_id}")
        order_info.setStyleSheet("font-size: 14px; color: #666;")
        layout.addWidget(order_info)
        
        # 问题描述
        desc_label = QLabel("问题描述：")
        desc_label.setStyleSheet("font-size: 14px; color: #333;")
        layout.addWidget(desc_label)
        
        desc_input = QTextEdit()
        desc_input.setPlaceholderText("请详细描述您遇到的问题...")
        desc_input.setFixedHeight(150)
        desc_input.setStyleSheet("""
            QTextEdit {
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 10px;
                font-size: 14px;
            }
            QTextEdit:focus {
                border: 1px solid #FFA366;
            }
        """)
        layout.addWidget(desc_input)
        
        layout.addStretch()
        
        # 按钮
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        cancel_btn = QPushButton("取消")
        cancel_btn.setFixedSize(100, 40)
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                color: #666;
                border: none;
                border-radius: 20px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        cancel_btn.clicked.connect(dialog.reject)
        btn_layout.addWidget(cancel_btn)
        
        submit_btn = QPushButton("提交申请")
        submit_btn.setFixedSize(100, 40)
        submit_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        def submit_application():
            if desc_input.toPlainText().strip():
                dialog.accept()
                QMessageBox.information(self, "提示", "售后申请已提交，我们会在24小时内处理！")
            else:
                QMessageBox.warning(self, "提示", "请填写问题描述")
        submit_btn.clicked.connect(submit_application)
        btn_layout.addWidget(submit_btn)
        
        layout.addLayout(btn_layout)
        dialog.setLayout(layout)
        dialog.exec()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = OrderPage()
    window.show()
    sys.exit(app.exec())

