import sys
from PyQt6.QtWidgets import (QApplication, QDialog, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QFrame,
                             QLineEdit, QMessageBox)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor


class PaymentPage(QDialog):
    """付款界面"""
    payment_success = pyqtSignal(dict)  # 付款成功信号，传递订单信息

    def __init__(self, product_info, parent=None):
        super().__init__(parent)
        self.product_info = product_info
        self.setWindowTitle("付款 - 闲转")
        self.setFixedSize(500, 600)
        self.setStyleSheet("""
            QDialog {
                background-color: white;
                border-radius: 12px;
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # 标题
        title_label = QLabel("确认付款")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 24px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label)

        # 商品信息
        product_frame = QFrame()
        product_frame.setStyleSheet("""
            QFrame {
                background-color: #F8F8F8;
                border-radius: 8px;
                padding: 15px;
            }
        """)

        product_layout = QVBoxLayout()
        product_layout.setSpacing(10)

        product_title = QLabel(product_info.get('title', '商品标题'))
        product_title.setStyleSheet("color: #333; font-size: 16px; font-weight: bold;")
        product_title.setWordWrap(True)
        product_layout.addWidget(product_title)

        price_label = QLabel(f"¥{product_info.get('price', 0)}")
        price_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 28px;
                font-weight: bold;
            }
        """)
        product_layout.addWidget(price_label)

        product_frame.setLayout(product_layout)
        layout.addWidget(product_frame)

        # 支付方式
        payment_method_label = QLabel("支付方式")
        payment_method_label.setStyleSheet("color: #666; font-size: 14px; font-weight: bold;")
        layout.addWidget(payment_method_label)

        # 支付方式选项（简化处理，只显示一个）
        payment_frame = QFrame()
        payment_frame.setStyleSheet("""
            QFrame {
                background-color: #F8F8F8;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        payment_layout = QHBoxLayout()
        payment_icon = QLabel("💳")
        payment_icon.setStyleSheet("font-size: 24px;")
        payment_layout.addWidget(payment_icon)
        payment_text = QLabel("余额支付")
        payment_text.setStyleSheet("color: #333; font-size: 14px;")
        payment_layout.addWidget(payment_text)
        payment_layout.addStretch()
        payment_frame.setLayout(payment_layout)
        layout.addWidget(payment_frame)

        layout.addStretch()

        # 底部信息
        total_layout = QHBoxLayout()
        total_label = QLabel("实付金额：")
        total_label.setStyleSheet("color: #666; font-size: 16px;")
        total_layout.addWidget(total_label)
        total_price = QLabel(f"¥{product_info.get('price', 0)}")
        total_price.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 24px;
                font-weight: bold;
            }
        """)
        total_layout.addWidget(total_price)
        total_layout.addStretch()
        layout.addLayout(total_layout)

        # 按钮
        button_layout = QHBoxLayout()
        button_layout.setSpacing(10)

        cancel_btn = QPushButton("取消")
        cancel_btn.setFixedHeight(45)
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                color: #666;
                border: 1px solid #E0E0E0;
                border-radius: 22px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)

        pay_btn = QPushButton("确认付款")
        pay_btn.setFixedHeight(45)
        pay_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 22px;
                font-size: 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        pay_btn.clicked.connect(self.confirm_payment)
        button_layout.addWidget(pay_btn, 2)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def confirm_payment(self):
        """确认付款"""
        # 创建订单信息
        order_info = {
            'id': f"ORD{len(self.product_info) + 1}",
            'title': self.product_info.get('title', '商品标题'),
            'price': self.product_info.get('price', 0),
            'quantity': 1,
            'status': '待发货',  # 付款后状态为待发货
            'order_time': '2024-01-15 10:30',
            'order_number': f"ORD{len(self.product_info) + 1}"
        }
        
        # 发送付款成功信号
        self.payment_success.emit(order_info)
        
        # 显示成功提示
        QMessageBox.information(self, "付款成功", "付款成功！订单已创建")
        self.accept()

