"""
用户会话管理模块
用于管理当前登录用户的信息，确保所有操作都与当前用户绑定
"""
import json
import os

# 会话文件路径（用于持久化当前登录用户）
SESSION_FILE = os.path.join(os.path.dirname(__file__), ".user_session.json")

class UserSession:
    """用户会话管理类（单例模式）"""
    _instance = None
    _user_info = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(UserSession, cls).__new__(cls)
            cls._instance._load_session()
        return cls._instance
    
    def _load_session(self):
        """从文件加载会话信息"""
        if os.path.exists(SESSION_FILE):
            try:
                with open(SESSION_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self._user_info = data.get('user_info')
            except:
                self._user_info = None
        else:
            self._user_info = None
    
    def _save_session(self):
        """保存会话信息到文件"""
        try:
            data = {'user_info': self._user_info}
            with open(SESSION_FILE, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存会话失败: {e}")
    
    def login(self, user_info):
        """用户登录，保存用户信息"""
        self._user_info = user_info
        self._save_session()
    
    def logout(self):
        """用户登出，清除用户信息"""
        self._user_info = None
        try:
            if os.path.exists(SESSION_FILE):
                os.remove(SESSION_FILE)
        except:
            pass
    
    def get_user_info(self):
        """获取当前用户信息"""
        return self._user_info or {}
    
    def get_user_id(self):
        """获取当前用户ID"""
        if self._user_info:
            return self._user_info.get('user_id')
        return None
    
    def get_username(self):
        """获取当前用户名"""
        if self._user_info:
            return self._user_info.get('username')
        return None
    
    def is_logged_in(self):
        """检查是否已登录"""
        return self._user_info is not None
    
    def is_admin(self):
        """检查是否是管理员"""
        if self._user_info:
            role = self._user_info.get('role', '')
            return role == 'admin' or self.get_username() == 'admin'
        return False


# 全局函数，方便使用
def get_session():
    """获取用户会话实例"""
    return UserSession()

def get_current_user_id():
    """获取当前登录用户ID"""
    return get_session().get_user_id()

def get_current_user_info():
    """获取当前登录用户信息"""
    return get_session().get_user_info()

def is_user_logged_in():
    """检查用户是否已登录"""
    return get_session().is_logged_in()

