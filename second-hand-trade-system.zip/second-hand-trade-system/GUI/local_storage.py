"""
本地存储模块（用于前端测试，模拟服务器数据）
"""
import json
import os
from datetime import datetime

# 存储文件路径
STORAGE_FILE = os.path.join(os.path.dirname(__file__), "local_data.json")

def load_data():
    """加载本地数据，并做一次数据校验/归位"""
    data = None
    if os.path.exists(STORAGE_FILE):
        try:
            with open(STORAGE_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except:
            data = None
    if not data:
        data = {
            'pending_goods': [],
            'approved_goods': [],
            'sold_goods': [],
            'rejected_goods': [],
            'favorites': [],
            'orders': [],
            'users': [],  # 本地用户列表
            'chat_messages': []  # 聊天消息列表
        }
    # 确保字段存在
    data.setdefault('pending_goods', [])
    data.setdefault('approved_goods', [])
    data.setdefault('sold_goods', [])
    data.setdefault('rejected_goods', [])
    data.setdefault('favorites', [])
    data.setdefault('orders', [])
    data.setdefault('users', [])  # 本地用户列表
    data.setdefault('chat_messages', [])  # 聊天消息列表

    changed = False
    
    # 清理损坏的用户数据（username或password为null或空）
    users = data.get('users', [])
    valid_users = []
    seen_usernames = set()  # 用于去重，保留第一个出现的用户
    for u in users:
        username = u.get('username')
        password = u.get('password')
        # 只保留有效的用户（username和password都不为空）
        if username and password and username != 'null' and password != 'null':
            if username is not None and password is not None:
                # 检查用户名是否重复（保留第一个）
                if username not in seen_usernames:
                    valid_users.append(u)
                    seen_usernames.add(username)
                else:
                    print(f"[DEBUG] load_data: 发现重复用户名，移除: username={username}, user_id={u.get('user_id')}")
                    changed = True
            else:
                print(f"[DEBUG] load_data: 移除损坏的用户数据 user_id={u.get('user_id')}, username={username}, password={password}")
                changed = True
        else:
            print(f"[DEBUG] load_data: 移除损坏的用户数据 user_id={u.get('user_id')}, username={username}, password={password}")
            changed = True

    # 如果有商品指向不存在的用户ID，自动重定向到第一个有效用户，避免孤儿记录
    valid_user_ids = {str(u.get('user_id')) for u in valid_users}
    def _rebind_goods_user_id(goods_list):
        nonlocal changed
        if not goods_list:
            return goods_list
        for g in goods_list:
            uid = g.get('user_id')
            if uid is None:
                continue
            if str(uid) not in valid_user_ids and valid_user_ids:
                new_uid = next(iter(valid_user_ids))
                print(f"[DEBUG] load_data: 修正商品的user_id {uid} -> {new_uid}, goods_id={g.get('goods_id')}")
                g['user_id'] = int(new_uid) if str(new_uid).isdigit() else new_uid
                changed = True
        return goods_list

    data['pending_goods'] = _rebind_goods_user_id(data.get('pending_goods', []))
    data['approved_goods'] = _rebind_goods_user_id(data.get('approved_goods', []))
    data['sold_goods'] = _rebind_goods_user_id(data.get('sold_goods', []))
    data['rejected_goods'] = _rebind_goods_user_id(data.get('rejected_goods', []))

    if changed:
        data['users'] = valid_users

    # 修复商品里的 user_id 若对应用户已被清理
    valid_user_ids = {str(u.get('user_id')) for u in valid_users if u.get('user_id') is not None}
    def _fix_user_id_in_goods_list(goods_list):
        nonlocal changed
        for g in goods_list:
            uid = g.get('user_id')
            if uid is None:
                continue
            if str(uid) not in valid_user_ids:
                # 若无有效用户，回退到1
                new_uid = next(iter(valid_user_ids), 1)
                g['user_id'] = new_uid
                changed = True
                print(f"[DEBUG] load_data: 修复商品 user_id={uid} -> {new_uid}, goods_id={g.get('goods_id')}")

    _fix_user_id_in_goods_list(data.get('pending_goods', []))
    _fix_user_id_in_goods_list(data.get('approved_goods', []))
    _fix_user_id_in_goods_list(data.get('sold_goods', []))
    _fix_user_id_in_goods_list(data.get('rejected_goods', []))

    # 统一清洗并修复 goods_id（去掉 False/None/空，去重，补发新ID）
    fixed = _sanitize_goods_ids(data)
    if fixed:
        changed = True

    # 归位：曾被错误放入 sold_goods 的下架商品，挪回 approved 并标记 off
    moved = False
    fixed_sold = []
    for g in data.get('sold_goods', []):
        status_val = g.get('status')
        if status_val == 'off':
            # 移回已上架列表并保留下架状态
            g['status'] = 'off'
            g.setdefault('off_time', g.get('sold_time'))
            data['approved_goods'].append(g)
            moved = True
        else:
            fixed_sold.append(g)
    if moved:
        data['sold_goods'] = fixed_sold
        changed = True

    if changed:
        save_data(data)
    return data

def get_favorites(user_id=None):
    """获取收藏列表，按用户过滤（user_id=None 时返回全部）"""
    data = load_data()
    favorites = data.get('favorites', [])
    if user_id is None:
        return favorites
    return [f for f in favorites if str(f.get('user_id')) == str(user_id)]

def is_favorited(user_id, goods_id):
    """判断是否已收藏"""
    favs = get_favorites(user_id)
    for f in favs:
        if str(f.get('goods_id')) == str(goods_id):
            return True
    return False

def add_favorite(user_id, goods):
    """添加收藏：goods 包含 goods_id, title, price, img_path 等"""
    if user_id is None or goods is None:
        return False
    data = load_data()
    favorites = data.get('favorites', [])
    for f in favorites:
        if str(f.get('user_id')) == str(user_id) and str(f.get('goods_id')) == str(goods.get('goods_id')):
            return True  # 已存在
    entry = {
        'user_id': user_id,
        'goods_id': goods.get('goods_id'),
        'title': goods.get('title', ''),
        'price': goods.get('price', 0),
        'img_path': goods.get('img_path', ''),
        'description': goods.get('description', ''),
        'category': goods.get('category', ''),
        'condition': goods.get('condition', ''),
        'create_time': goods.get('create_time', '')
    }
    favorites.append(entry)
    data['favorites'] = favorites
    save_data(data)
    return True

def remove_favorite(user_id, goods_id):
    """取消收藏"""
    data = load_data()
    favorites = data.get('favorites', [])
    new_favs = [f for f in favorites if not (str(f.get('user_id')) == str(user_id) and str(f.get('goods_id')) == str(goods_id))]
    data['favorites'] = new_favs
    save_data(data)
    return True

def get_favorite_count(goods_id):
    """获取某商品收藏数"""
    data = load_data()
    favorites = data.get('favorites', [])
    return len([f for f in favorites if str(f.get('goods_id')) == str(goods_id)])

def save_data(data):
    """保存本地数据"""
    try:
        with open(STORAGE_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print(f"保存数据失败: {e}")
        return False

def _next_goods_id(data):
    """生成全局唯一ID（遍历所有列表）"""
    all_ids = []
    for key in ['pending_goods', 'approved_goods', 'sold_goods', 'rejected_goods']:
        for g in data.get(key, []):
            gid = g.get('goods_id')
            if gid is None or gid is False or gid == '':
                continue
            try:
                all_ids.append(int(gid))
            except Exception:
                # 如果是非数字的旧ID，忽略
                continue
    return (max(all_ids) + 1) if all_ids else 1

def _next_order_id(data):
    """生成订单ID（简单自增字符串）"""
    orders = data.get('orders', [])
    if not orders:
        return "1001"
    try:
        ids = [int(str(o.get('id'))) for o in orders if o.get('id') is not None]
        return str(max(ids) + 1) if ids else "1001"
    except Exception:
        return "1001"

def _is_valid_id(gid):
    """判断ID是否为有效数字"""
    try:
        if gid is None or gid is False or gid == '':
            return False
        if isinstance(gid, str) and gid.strip().lower() == 'false':
            return False
        int(gid)
        return True
    except Exception:
        return False


def _sanitize_goods_ids(data):
    """修复无效ID（None/False/空/非数字），为其分配新ID；已是有效数字的不改，允许重复保留。返回是否有变更。"""
    valid_max = 0
    seen = set()
    changed = False

    # 先收集已有有效ID的最大值
    for key in ['pending_goods', 'approved_goods', 'sold_goods', 'rejected_goods']:
        for g in data.get(key, []):
            gid = g.get('goods_id')
            try:
                if gid is None or gid is False or gid == '':
                    continue
                num = int(gid)
                valid_max = max(valid_max, num)
            except Exception:
                continue

    def assign_new_id():
        nonlocal valid_max
        valid_max += 1
        return valid_max

    for key in ['pending_goods', 'approved_goods', 'sold_goods', 'rejected_goods']:
        fixed_list = []
        for g in data.get(key, []):
            gid = g.get('goods_id')
            need_new = False
            try:
                if gid is None or gid is False or gid == '' or (isinstance(gid, str) and gid.strip().lower() == 'false'):
                    need_new = True
                else:
                    gid_num = int(gid)
            except Exception:
                need_new = True

            if need_new:
                gid_num = assign_new_id()
                g['goods_id'] = gid_num
                changed = True
            else:
                gid_num = int(g.get('goods_id'))

            seen.add(gid_num)
            fixed_list.append(g)
        data[key] = fixed_list
    return changed


def fix_pending_invalid_ids():
    """修复 pending_goods 中的无效ID，返回修复后的列表"""
    data = load_data()
    changed = False
    for g in data.get('pending_goods', []):
        if not _is_valid_id(g.get('goods_id')):
            g['goods_id'] = _next_goods_id(data)
            changed = True
    if changed:
        save_data(data)
    return data.get('pending_goods', [])

def add_pending_goods(goods_data):
    """添加待审核商品（自动绑定当前登录用户）"""
    # 如果没有user_id，尝试从会话中获取
    if 'user_id' not in goods_data or goods_data.get('user_id') is None:
        try:
            from user_session import get_current_user_id
            current_user_id = get_current_user_id()
            if current_user_id:
                goods_data['user_id'] = current_user_id
                print(f"[DEBUG] add_pending_goods: 从会话获取user_id={current_user_id}")
        except Exception as e:
            print(f"[DEBUG] add_pending_goods: 从会话获取user_id失败: {e}")
    
    data = load_data()
    goods_id = _next_goods_id(data)
    
    goods_data['goods_id'] = goods_id
    goods_data['create_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    goods_data['status'] = 'pending'
    
    # 确保user_id存在
    if 'user_id' not in goods_data or goods_data.get('user_id') is None:
        goods_data['user_id'] = 1  # 默认值，但应该从会话获取
        print(f"[DEBUG] add_pending_goods: 使用默认user_id=1")
    
    print(f"[DEBUG] add_pending_goods: 准备添加商品 goods_id={goods_id}, user_id={goods_data.get('user_id')}, title={goods_data.get('title')}")
    
    data['pending_goods'].append(goods_data)
    
    # 保存数据
    success = save_data(data)
    if not success:
        print(f"[ERROR] add_pending_goods: 保存数据失败")
        raise Exception("保存数据到本地文件失败")
    
    # 验证保存是否成功
    data_after = load_data()
    pending_count = len(data_after.get('pending_goods', []))
    print(f"[DEBUG] add_pending_goods: 保存成功，当前待审核商品数量: {pending_count}")
    
    return goods_id

def get_pending_goods(user_id=None):
    """获取待审核商品列表（可选：按用户ID过滤）"""
    data = load_data()
    goods_list = data['pending_goods']
    if user_id is not None:
        return [g for g in goods_list if str(g.get('user_id')) == str(user_id)]
    return goods_list

def get_approved_goods(user_id=None):
    """获取已审核通过的商品列表（可选：按用户ID过滤）"""
    data = load_data()
    goods_list = data.get('approved_goods', [])
    if user_id is not None:
        return [g for g in goods_list if str(g.get('user_id')) == str(user_id)]
    return goods_list

def get_sold_goods(user_id=None):
    """获取已卖出商品列表（可选：按用户ID过滤）"""
    data = load_data()
    goods_list = [g for g in data.get('sold_goods', []) if g.get('status') == 'sold']
    if user_id is not None:
        return [g for g in goods_list if str(g.get('user_id')) == str(user_id)]
    return goods_list

def get_rejected_goods(user_id=None):
    """获取审核未通过的商品列表（可选：按用户ID过滤）"""
    data = load_data()
    goods_list = data.get('rejected_goods', [])
    if user_id is not None:
        return [g for g in goods_list if str(g.get('user_id')) == str(user_id)]
    return goods_list

def _find_goods(data, goods_id):
    """在三个列表里找到商品并返回所在列表名和索引"""
    gid = str(goods_id)
    for key in ['pending_goods', 'approved_goods', 'sold_goods']:
        for idx, g in enumerate(data.get(key, [])):
            if str(g.get('goods_id')) == gid:
                return key, idx, g
    return None, None, None

def update_goods(goods_id, updates: dict):
    """更新商品字段，不改变所在列表"""
    data = load_data()
    key, idx, g = _find_goods(data, goods_id)
    if g is None:
        return False
    g.update(updates)
    data[key][idx] = g
    save_data(data)
    return True

def audit_goods(goods_id, status):
    """审核商品（通过或拒绝）"""
    data = load_data()
    
    # 从待审核列表中移除
    goods = None
    gid = str(goods_id)
    for i, g in enumerate(data['pending_goods']):
        if str(g.get('goods_id')) == gid:
            goods = data['pending_goods'].pop(i)
            break
    
    if goods:
        goods['status'] = status
        goods['audit_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        if status == 'approved':
            data['approved_goods'].append(goods)
        elif status == 'rejected':
            data.setdefault('rejected_goods', []).append(goods)
        
        save_data(data)
        return True
    return False

def mark_goods_sold(goods_id, buyer_id=None, create_order=True, order_id=None):
    """标记商品为已售出：从approved移到sold
    create_order=False 时不再生成新订单（用于已存在订单的支付）"""
    data = load_data()
    target_idx = None
    goods = None
    gid = str(goods_id) if goods_id is not None else None
    
    if gid is None:
        print(f"[DEBUG] mark_goods_sold: goods_id为None")
        return False
    
    print(f"[DEBUG] mark_goods_sold: 查找商品 goods_id={gid}, approved_goods数量={len(data.get('approved_goods', []))}")
    
    # 尝试多种ID字段匹配
    for i, g in enumerate(data.get('approved_goods', [])):
        # 尝试多种ID字段
        g_goods_id = str(g.get('goods_id', ''))
        g_id = str(g.get('id', ''))
        g_uid = str(g.get('uid', ''))
        
        if g_goods_id == gid or g_id == gid or g_uid == gid:
            target_idx = i
            goods = g
            print(f"[DEBUG] mark_goods_sold: 找到商品 goods_id={g.get('goods_id')}, id={g.get('id')}, title={g.get('title')}")
            break
    
    if goods is None:
        print(f"[DEBUG] mark_goods_sold: 未找到商品 goods_id={gid}")
        # 打印所有商品的ID用于调试
        for i, g in enumerate(data.get('approved_goods', [])):
            print(f"[DEBUG] 商品{i}: goods_id={g.get('goods_id')}, id={g.get('id')}, title={g.get('title')}")
        return False
    
    # 从在售列表移除
    data['approved_goods'].pop(target_idx)
    
    # 标记售出信息并放入已卖出列表
    goods['status'] = 'sold'
    goods['sold_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    goods['buyer_id'] = buyer_id
    goods['order_id'] = order_id if order_id else goods.get('order_id')
    goods['after_sale_status'] = goods.get('after_sale_status', '')
    # 方案A：在已卖出商品里直接记录订单状态，初始为“待发货”
    goods['order_status'] = goods.get('order_status') or '待发货'
    # 同步生成订单（可选）
    if create_order:
        try:
            order = _create_order_from_goods(goods, buyer_id, data)
            if order_id:
                order['id'] = str(order_id)
                order['order_number'] = str(order_id)
            goods['order_id'] = order.get('id')
            data.setdefault('orders', []).append(order)
        except Exception as e:
            print(f"创建订单失败: {e}")
    data.setdefault('sold_goods', []).append(goods)
    
    save_data(data)
    return True

def set_sold_order_status_by_order_id(order_id, status):
    """根据订单ID更新 sold_goods 里的 order_status（给“我卖出的”用）"""
    data = load_data()
    updated = False
    oid = str(order_id)
    for g in data.get('sold_goods', []):
        # 同时兼容 order_id 和 id 字段
        g_oid = str(g.get('order_id'))
        g_id = str(g.get('id'))
        if g_oid == oid or g_id == oid:
            old = g.get('order_status')
            g['order_status'] = status
            print(f"[DEBUG] set_sold_order_status_by_order_id: order_id={oid}, {old} -> {status}")
            updated = True
            break
    if updated:
        save_data(data)
    else:
        print(f"[DEBUG] set_sold_order_status_by_order_id: 未找到 sold_goods, order_id={oid}")
    return updated

def _create_order_from_goods(goods, buyer_id, data):
    """基于商品生成订单字典"""
    order_id = _next_order_id(data)
    order_number = f"ORD{datetime.now().strftime('%Y%m%d%H%M%S')}{order_id}"
    title = goods.get('title') or goods.get('name') or "商品"
    price = goods.get('price', 0)
    img_path = goods.get('image') or goods.get('img_path') or ""
    seller_id = goods.get('user_id')
    return {
        'id': order_id,
        'order_number': order_number,
        'goods_id': goods.get('goods_id'),
        'buyer_id': buyer_id,
        'seller_id': seller_id,
        'title': title,
        'price': price,
        'quantity': 1,
        'status': '待发货',  # 付款成功后直接待发货
        'order_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'img_path': img_path,
        'after_sale_reason': '',
        'after_sale_status': ''
    }

def create_cart_order(goods, buyer_id=None):
    """创建待付款订单（加入购物车，自动绑定当前登录用户）"""
    # 如果没有buyer_id，尝试从会话中获取
    if buyer_id is None:
        try:
            from user_session import get_current_user_id
            buyer_id = get_current_user_id()
        except:
            pass
    
    data = load_data()
    order = _create_order_from_goods(goods, buyer_id, data)
    order['status'] = '待付款'
    order['after_sale_reason'] = ''
    order['after_sale_status'] = ''
    data.setdefault('orders', []).append(order)
    save_data(data)
    return order

def get_orders(user_id=None):
    """获取订单列表，按买家过滤"""
    data = load_data()
    orders = data.get('orders', [])
    if user_id is None:
        return orders
    return [o for o in orders if str(o.get('buyer_id')) == str(user_id)]

def get_order_by_id(order_id):
    """按ID获取订单（支持id和order_id字段）"""
    data = load_data()
    for o in data.get('orders', []):
        # 同时检查 id 和 order_id 字段
        if str(o.get('id')) == str(order_id) or str(o.get('order_id')) == str(order_id):
            return o
    return None

def update_order_status(order_id, status):
    """更新订单状态（支持id和order_id字段）"""
    data = load_data()
    updated = False
    print(f"[DEBUG] update_order_status: 查找订单 order_id={order_id}, 新状态={status}")
    for o in data.get('orders', []):
        # 同时检查 id 和 order_id 字段
        o_id = str(o.get('id', ''))
        o_order_id = str(o.get('order_id', ''))
        order_id_str = str(order_id)
        
        if o_id == order_id_str or o_order_id == order_id_str:
            old_status = o.get('status')
            o['status'] = status
            updated = True
            print(f"[DEBUG] update_order_status: 找到订单并更新状态: {old_status} -> {status}")
            break
    
    if not updated:
        print(f"[DEBUG] update_order_status: 未找到订单 order_id={order_id}")
        # 打印所有订单ID用于调试
        for i, o in enumerate(data.get('orders', [])):
            print(f"[DEBUG] 订单{i}: id={o.get('id')}, order_id={o.get('order_id')}, status={o.get('status')}")
    
    if updated:
        save_data(data)
        print(f"[DEBUG] update_order_status: 已保存数据")
    return updated

def update_order_after_sale(order_id, reason=None, status=None):
    """记录售后原因/状态"""
    data = load_data()
    updated = False
    for o in data.get('orders', []):
        if str(o.get('id')) == str(order_id):
            if reason is not None:
                o['after_sale_reason'] = reason
            if status is not None:
                o['after_sale_status'] = status
            updated = True
            break
    if updated:
        save_data(data)
    return updated

def set_goods_after_sale(goods_id, reason):
    """在已售商品上标记售后原因"""
    data = load_data()
    gid = str(goods_id)
    for g in data.get('sold_goods', []):
        if str(g.get('goods_id')) == gid:
            g['after_sale_reason'] = reason
            save_data(data)
            return True
    return False

def set_goods_after_sale_status(goods_id, status):
    """在已售商品上标记售后状态"""
    data = load_data()
    gid = str(goods_id)
    for g in data.get('sold_goods', []):
        if str(g.get('goods_id')) == gid:
            g['after_sale_status'] = status
            save_data(data)
            return True
    return False

def mark_goods_off(goods_id):
    """下架商品：标记status=off并保留在数据中（不进入已卖出）"""
    data = load_data()
    gid = str(goods_id)
    # 优先在已上架列表处理
    for i, g in enumerate(data.get('approved_goods', [])):
        if str(g.get('goods_id')) == gid:
            goods = data['approved_goods'][i]
            goods['status'] = 'off'
            goods['off_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            data['approved_goods'][i] = goods
            save_data(data)
            return True
    # pending 状态下架，直接标记off并放入rejected列表以便展示
    for i, g in enumerate(data.get('pending_goods', [])):
        if str(g.get('goods_id')) == gid:
            goods = data['pending_goods'].pop(i)
            goods['status'] = 'off'
            goods['off_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            data.setdefault('rejected_goods', []).append(goods)
            save_data(data)
            return True
    return False

# ========== 用户管理相关函数 ==========

def _next_user_id(data):
    """生成新的用户ID"""
    users = data.get('users', [])
    if not users:
        return 1
    max_id = 0
    for u in users:
        uid = u.get('user_id')
        if uid and isinstance(uid, int):
            max_id = max(max_id, uid)
    return max_id + 1

def register_user(username, password, nickname=None, phone=None, role='normal'):
    """注册新用户（本地存储）"""
    # 验证必填字段
    if not username or username.strip() == "":
        return None, "用户名不能为空"
    if not password or password.strip() == "":
        return None, "密码不能为空"
    
    # 清理输入
    username = username.strip()
    password = password.strip()
    nickname = nickname.strip() if nickname else None
    phone = phone.strip() if phone else None
    
    data = load_data()
    users = data.get('users', [])
    
    # 检查用户名是否已存在
    for u in users:
        if u.get('username') == username:
            return None, "用户名已存在"
    
    # 创建新用户（确保所有字段都有有效值）
    user_id = _next_user_id(data)
    new_user = {
        'user_id': user_id,
        'username': username,  # 必填，已验证
        'password': password,  # 必填，已验证
        'nickname': nickname if nickname else username,  # 如果没有提供昵称，使用用户名
        'phone': phone if phone else None,  # 可选字段
        'role': role if role else 'normal',  # 默认角色
        'avatar_path': None,  # 初始化为None
        'create_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    # 验证新用户数据完整性
    if not new_user.get('username') or not new_user.get('password'):
        return None, "用户数据不完整"
    
    users.append(new_user)
    data['users'] = users
    
    # 保存数据并验证
    if not save_data(data):
        return None, "保存用户数据失败"
    
    # 验证保存是否成功
    verify_data = load_data()
    saved_users = verify_data.get('users', [])
    saved_user = None
    for u in saved_users:
        if u.get('username') == username:
            saved_user = u
            break
    
    if not saved_user or saved_user.get('username') != username:
        print(f"[ERROR] register_user: 保存后验证失败，用户未正确保存")
        return None, "用户保存验证失败"
    
    print(f"[DEBUG] register_user: 成功注册用户 username={username}, user_id={user_id}, nickname={new_user.get('nickname')}")
    
    # 返回用户信息（不包含密码）
    user_info = {
        'user_id': user_id,
        'username': username,
        'nickname': new_user.get('nickname'),
        'phone': phone,
        'role': role if role else 'normal'
    }
    
    return user_info, None

def login_user(username, password):
    """用户登录验证（本地存储）"""
    data = load_data()
    users = data.get('users', [])
    
    for u in users:
        if u.get('username') == username and u.get('password') == password:
            # 返回用户信息（不包含密码，但包含头像路径）
            user_info = {
                'user_id': u.get('user_id'),
                'username': u.get('username'),
                'nickname': u.get('nickname'),
                'phone': u.get('phone'),
                'role': u.get('role', 'normal'),
                'avatar_path': u.get('avatar_path')  # 头像路径（可能为None）
            }
            return user_info, None
    
    return None, "用户名或密码错误"

def get_user_by_id(user_id):
    """根据用户ID获取用户信息"""
    data = load_data()
    users = data.get('users', [])
    
    # 统一转换为字符串进行比较，避免类型不匹配
    user_id_str = str(user_id) if user_id is not None else None
    
    for u in users:
        # 统一转换为字符串进行比较
        stored_user_id = u.get('user_id')
        if stored_user_id is not None and str(stored_user_id) == user_id_str:
            return {
                'user_id': u.get('user_id'),
                'username': u.get('username'),
                'nickname': u.get('nickname') or u.get('username', '用户'),
                'phone': u.get('phone'),
                'role': u.get('role', 'normal'),
                'avatar_path': u.get('avatar_path')
            }
    return None

def update_user_profile(user_id, nickname=None, avatar_path=None):
    """更新用户资料（本地存储）"""
    if user_id is None:
        print(f"[DEBUG] update_user_profile: user_id为None，无法更新")
        return False, "用户ID不能为空"
    
    data = load_data()
    users = data.get('users', [])
    
    # 统一转换为字符串进行比较，避免类型不匹配
    user_id_str = str(user_id) if user_id is not None else None
    
    for u in users:
        # 统一转换为字符串进行比较
        stored_user_id = u.get('user_id')
        if stored_user_id is not None and str(stored_user_id) == user_id_str:
            if nickname is not None:
                u['nickname'] = nickname
            if avatar_path is not None:
                u['avatar_path'] = avatar_path
            data['users'] = users
            save_data(data)
            print(f"[DEBUG] update_user_profile: 成功更新用户 user_id={user_id}, nickname={nickname}")
            return True, None
    
    # 如果找不到用户，打印调试信息
    print(f"[DEBUG] update_user_profile: 找不到用户 user_id={user_id} (类型: {type(user_id)})")
    print(f"[DEBUG] 当前用户列表中的user_id: {[str(u.get('user_id')) for u in users]}")
    
    return False, "用户不存在"

# ========== 聊天相关函数 ==========

def _next_message_id(data):
    """生成新的消息ID"""
    messages = data.get('chat_messages', [])
    if not messages:
        return 1
    max_id = 0
    for m in messages:
        mid = m.get('message_id')
        if mid and isinstance(mid, int):
            max_id = max(max_id, mid)
    return max_id + 1

def add_chat_message(sender_id, receiver_id, message):
    """添加聊天消息（本地存储）"""
    data = load_data()
    if 'chat_messages' not in data:
        data['chat_messages'] = []
    
    message_id = _next_message_id(data)
    new_message = {
        'message_id': message_id,
        'sender_id': sender_id,
        'receiver_id': receiver_id,
        'content': message,
        'status': '已发送',
        'create_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    data['chat_messages'].append(new_message)
    save_data(data)
    return message_id

def get_chat_messages(user_id, other_user_id):
    """获取两个用户之间的聊天记录（本地存储）"""
    data = load_data()
    messages = data.get('chat_messages', [])
    
    # 筛选出两个用户之间的消息
    chat_messages = []
    for m in messages:
        sender_id = m.get('sender_id')
        receiver_id = m.get('receiver_id')
        if (sender_id == user_id and receiver_id == other_user_id) or \
           (sender_id == other_user_id and receiver_id == user_id):
            chat_messages.append(m)
    
    # 按时间排序
    chat_messages.sort(key=lambda x: x.get('create_time', ''))
    return chat_messages

def get_chat_list(user_id):
    """获取用户的聊天会话列表（本地存储）"""
    data = load_data()
    messages = data.get('chat_messages', [])
    users = data.get('users', [])
    
    # 找出所有与当前用户有聊天记录的用户
    conversations = {}
    for m in messages:
        sender_id = m.get('sender_id')
        receiver_id = m.get('receiver_id')
        
        if sender_id == user_id:
            other_id = receiver_id
        elif receiver_id == user_id:
            other_id = sender_id
        else:
            continue
        
        # 获取对方用户信息
        other_user = None
        for u in users:
            if u.get('user_id') == other_id:
                other_user = u
                break
        
        if other_user:
            other_name = other_user.get('nickname') or other_user.get('username', '用户')
        else:
            other_name = f"用户{other_id}"
        
        # 更新会话信息
        if other_id not in conversations:
            conversations[other_id] = {
                'other_user_id': other_id,
                'other_user_name': other_name,
                'last_message': m.get('content', ''),
                'last_time': m.get('create_time', ''),
                'unread_count': 0  # 简化处理，不计算未读数
            }
        else:
            # 更新最后一条消息
            if m.get('create_time', '') > conversations[other_id]['last_time']:
                conversations[other_id]['last_message'] = m.get('content', '')
                conversations[other_id]['last_time'] = m.get('create_time', '')
    
    # 转换为列表并按时间排序
    result = list(conversations.values())
    result.sort(key=lambda x: x.get('last_time', ''), reverse=True)
    return result

