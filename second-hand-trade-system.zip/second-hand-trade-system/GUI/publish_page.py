import sys
import os
import json
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QLineEdit, QPushButton,
                             QScrollArea, QFrame, QComboBox, QTextEdit,
                             QFileDialog, QMessageBox, QGraphicsDropShadowEffect,
                             QProgressBar, QDialog, QDialogButtonBox)
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer, pyqtSignal, QPoint, QSize, QRect
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor, QDragEnterEvent, QDropEvent, QMouseEvent


class ImageUploadWidget(QFrame):
    """图片上传组件，支持拖拽排序和删除"""
    delete_requested = pyqtSignal(int)  # 删除图片信号
    reorder_requested = pyqtSignal(int, int)  # 重新排序信号（from_index, to_index）

    def __init__(self, image_path, index, parent=None):
        super().__init__(parent)
        self.image_path = image_path
        self.index = index
        self.is_dragging = False
        self.drag_start_pos = None

        # 增大尺寸到250x250，让图片完整显示
        self.setFixedSize(250, 250)
        self.setStyleSheet("""
            QFrame {
                background-color: transparent;
                border: none;
                border-radius: 8px;
            }
        """)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # 图片显示（占满整个区域，无边框）
        self.image_label = QLabel()
        self.image_label.setFixedSize(250, 250)
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet("""
            QLabel {
                border-radius: 8px;
                background-color: #F5F5F5;
            }
        """)
        
        pixmap = QPixmap(image_path)
        if not pixmap.isNull():
            # 使用KeepAspectRatio确保图片完整显示，不裁剪
            pixmap = pixmap.scaled(250, 250, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
            self.image_label.setPixmap(pixmap)
        else:
            # 占位图
            placeholder = QPixmap(250, 250)
            placeholder.fill(QColor(240, 240, 240))
            painter = QPainter(placeholder)
            painter.setPen(QColor(200, 200, 200))
            painter.setFont(QFont("Arial", 16))
            painter.drawText(placeholder.rect(), Qt.AlignmentFlag.AlignCenter, "图片")
            painter.end()
            self.image_label.setPixmap(placeholder)
        
        layout.addWidget(self.image_label)

        # 删除按钮（右上角）
        self.delete_btn = QPushButton("×")
        self.delete_btn.setFixedSize(32, 32)
        self.delete_btn.setStyleSheet("""
            QPushButton {
                background-color: rgba(0, 0, 0, 0.6);
                color: white;
                border: none;
                border-radius: 16px;
                font-size: 22px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: rgba(255, 77, 79, 0.8);
            }
        """)
        self.delete_btn.clicked.connect(lambda: self.delete_requested.emit(self.index))
        self.delete_btn.setParent(self.image_label)
        self.delete_btn.move(218, 0)

        # 成功标记（右下角绿色对勾）
        self.success_label = QLabel("✓")
        self.success_label.setFixedSize(26, 26)
        self.success_label.setStyleSheet("""
            QLabel {
                background-color: #52C41A;
                color: white;
                border-radius: 13px;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        self.success_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.success_label.setParent(self.image_label)
        self.success_label.move(224, 224)
        self.success_label.show()

        self.setLayout(layout)

    def mousePressEvent(self, event: QMouseEvent):
        """开始拖拽"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.is_dragging = True
            self.drag_start_pos = event.position().toPoint()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        """拖拽中"""
        if self.is_dragging and self.drag_start_pos:
            # 这里可以实现拖拽排序的视觉反馈
            pass
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        """结束拖拽"""
        if self.is_dragging:
            self.is_dragging = False
            self.drag_start_pos = None
        super().mouseReleaseEvent(event)


class ImageUploadArea(QFrame):
    """图片上传区域"""
    images_changed = pyqtSignal(list)  # 图片列表变化信号

    def __init__(self, parent=None):
        super().__init__(parent)
        self.image_paths = []
        self.max_images = 9
        self.image_widgets = []

        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
            }
        """)

        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)  # 确保有足够的内边距

        # 标题
        title_label = QLabel("宝贝图片")
        title_label.setStyleSheet("""
            QLabel {
                font-size: 16px;
                font-weight: bold;
                color: #333;
            }
        """)
        layout.addWidget(title_label)

        # 图片容器（水平滚动，设置最小高度确保有足够空间）
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setMinimumHeight(280)  # 设置最小高度，确保图片有足够显示空间
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: transparent;
            }
        """)

        self.images_container = QWidget()
        self.images_container.setMinimumHeight(250)  # 确保容器有足够高度
        self.images_layout = QHBoxLayout()
        self.images_layout.setSpacing(15)  # 增加间距
        self.images_layout.setContentsMargins(0, 0, 0, 0)
        self.images_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.images_container.setLayout(self.images_layout)
        scroll_area.setWidget(self.images_container)

        layout.addWidget(scroll_area)

        # 添加图片按钮（增大尺寸，与图片显示区域一致）
        self.add_btn = QPushButton("+ 添加宝贝图片")
        self.add_btn.setFixedSize(250, 250)
        self.add_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                border: 2px dashed #D0D0D0;
                border-radius: 8px;
                color: #999;
                font-size: 18px;
            }
            QPushButton:hover {
                background-color: #F0F0F0;
                border-color: #FFA366;
                color: #FFA366;
            }
        """)
        self.add_btn.clicked.connect(self.select_images)
        self.images_layout.addWidget(self.add_btn)

        # 提示文字
        hint_label = QLabel("清晰的图片更容易卖出哦～")
        hint_label.setStyleSheet("""
            QLabel {
                color: #999;
                font-size: 12px;
            }
        """)
        layout.addWidget(hint_label)

        self.setLayout(layout)

    def select_images(self):
        """选择图片文件"""
        files, _ = QFileDialog.getOpenFileNames(
            self,
            "选择图片",
            "",
            "图片文件 (*.png *.jpg *.jpeg *.bmp *.gif)"
        )

        if files:
            remaining_slots = self.max_images - len(self.image_paths)
            if remaining_slots <= 0:
                QMessageBox.warning(self, "提示", f"最多只能上传{self.max_images}张图片")
                return

            # 限制上传数量
            files_to_add = files[:remaining_slots]
            if len(files) > remaining_slots:
                QMessageBox.information(self, "提示", f"最多只能上传{self.max_images}张图片，已选择前{remaining_slots}张")

            # 添加图片
            for file_path in files_to_add:
                self.add_image(file_path)

    def add_image(self, image_path):
        """添加一张图片"""
        if len(self.image_paths) >= self.max_images:
            return

        self.image_paths.append(image_path)
        
        # 创建图片组件
        image_widget = ImageUploadWidget(image_path, len(self.image_paths) - 1)
        image_widget.delete_requested.connect(self.delete_image)
        self.image_widgets.append(image_widget)
        
        # 插入到添加按钮之前
        self.images_layout.insertWidget(len(self.image_paths) - 1, image_widget)
        
        # 如果达到最大数量，隐藏添加按钮
        if len(self.image_paths) >= self.max_images:
            self.add_btn.hide()
        
        self.images_changed.emit(self.image_paths)

    def delete_image(self, index):
        """删除图片"""
        if 0 <= index < len(self.image_paths):
            # 移除图片
            self.image_paths.pop(index)
            widget = self.image_widgets.pop(index)
            widget.deleteLater()
            
            # 更新索引
            for i, widget in enumerate(self.image_widgets):
                widget.index = i
            
            # 显示添加按钮
            if len(self.image_paths) < self.max_images:
                self.add_btn.show()
            
            self.images_changed.emit(self.image_paths)


class PublishPage(QMainWindow):
    def __init__(self, user_info=None):
        try:
            print("PublishPage.__init__ 开始")
            super().__init__()
            print("PublishPage 父类初始化完成")
            
            self.setWindowTitle("发布闲置宝贝 - 闲转")
            self.setGeometry(100, 100, 1200, 1000)  # 增大窗口宽度
            self.setStyleSheet("background-color: #F8F8F8;")
            
            # 设置窗口属性，确保窗口独立存在
            self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, False)
            
            # 保存用户信息（优先从会话获取）
            try:
                from user_session import get_current_user_info, get_current_user_id
                session_user_info = get_current_user_info()
                if session_user_info:
                    self.user_info = session_user_info
                    self.user_id = get_current_user_id()
                else:
                    self.user_info = user_info or {}
                    self.user_id = self.user_info.get('user_id', 1)
            except:
                self.user_info = user_info or {}
                self.user_id = self.user_info.get('user_id', 1)
            print(f"用户ID: {self.user_id}")
            
            # 使用本地存储（前端测试模式）
            from local_storage import add_pending_goods
            self.add_pending_goods = add_pending_goods
            print("本地存储导入成功")

            # 主窗口部件
            main_widget = QWidget()
            self.setCentralWidget(main_widget)
            main_layout = QVBoxLayout()
            main_layout.setContentsMargins(0, 0, 0, 0)
            main_layout.setSpacing(0)
            print("主窗口布局创建完成")

            # 顶部导航栏
            print("开始创建顶部导航栏...")
            self.create_top_nav()
            main_layout.addWidget(self.top_nav)
            print("顶部导航栏创建完成")

            # 滚动区域
            scroll_area = QScrollArea()
            scroll_area.setWidgetResizable(True)
            scroll_area.setStyleSheet("""
                QScrollArea {
                    border: none;
                    background-color: #F8F8F8;
                }
            """)

            scroll_content = QWidget()
            scroll_layout = QVBoxLayout()
            scroll_layout.setContentsMargins(20, 20, 20, 20)
            scroll_layout.setSpacing(20)

            # 图片上传区域
            print("开始创建图片上传区域...")
            self.image_upload_area = ImageUploadArea()
            scroll_layout.addWidget(self.image_upload_area)
            print("图片上传区域创建完成")

            # 基础信息区域
            print("开始创建基础信息区域...")
            self.create_info_section()
            scroll_layout.addWidget(self.info_section)
            print("基础信息区域创建完成")

            # 描述区域
            print("开始创建描述区域...")
            self.create_description_section()
            scroll_layout.addWidget(self.description_section)
            print("描述区域创建完成")

            scroll_layout.addStretch()

            scroll_content.setLayout(scroll_layout)
            scroll_area.setWidget(scroll_content)
            main_layout.addWidget(scroll_area)

            # 底部提交按钮
            print("开始创建底部按钮...")
            self.create_bottom_bar()
            main_layout.addWidget(self.bottom_bar)
            print("底部按钮创建完成")

            main_widget.setLayout(main_layout)

            # 初始化表单验证
            self.update_publish_button_state()
            print("PublishPage.__init__ 完成")
        except Exception as e:
            print(f"PublishPage初始化失败: {e}")
            import traceback
            traceback.print_exc()
            raise  # 重新抛出异常，让调用者知道初始化失败

    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)

        nav_layout = QHBoxLayout()
        nav_layout.setContentsMargins(20, 10, 20, 10)

        # 取消按钮
        cancel_btn = QPushButton("← 取消")
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #666;
                border: none;
                font-size: 14px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                color: #333;
                background-color: #F5F5F5;
                border-radius: 4px;
            }
        """)
        cancel_btn.clicked.connect(self.close)
        nav_layout.addWidget(cancel_btn)

        nav_layout.addStretch()

        # 标题
        title_label = QLabel("发布闲置宝贝")
        title_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        nav_layout.addWidget(title_label)

        nav_layout.addStretch()

        # 占位，保持标题居中
        placeholder = QLabel()
        placeholder.setFixedWidth(cancel_btn.width())
        nav_layout.addWidget(placeholder)

        self.top_nav.setLayout(nav_layout)

    def create_info_section(self):
        """创建基础信息区域"""
        self.info_section = QFrame()
        self.info_section.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
            }
        """)

        layout = QVBoxLayout()
        layout.setSpacing(20)

        # 标题
        title_label = QLabel("基础信息")
        title_label.setStyleSheet("""
            QLabel {
                font-size: 16px;
                font-weight: bold;
                color: #333;
            }
        """)
        layout.addWidget(title_label)

        # 宝贝标题
        title_frame = QVBoxLayout()
        title_frame.setSpacing(5)

        title_label = QLabel("宝贝标题 *")
        title_label.setStyleSheet("color: #666; font-size: 14px;")
        title_frame.addWidget(title_label)

        self.title_input = QLineEdit()
        self.title_input.setPlaceholderText("描述宝贝的关键词，如：99新iPhone14 256G")
        self.title_input.setFixedHeight(45)
        self.title_input.setStyleSheet("""
            QLineEdit {
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 0 15px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #FFA366;
            }
        """)
        self.title_input.textChanged.connect(self.on_title_changed)
        title_frame.addWidget(self.title_input)

        # 字数提示
        self.title_count_label = QLabel("0/30")
        self.title_count_label.setStyleSheet("color: #999; font-size: 12px;")
        self.title_count_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        title_frame.addWidget(self.title_count_label)

        layout.addLayout(title_frame)

        # 分类
        category_frame = QVBoxLayout()
        category_frame.setSpacing(5)

        category_label = QLabel("宝贝分类 *")
        category_label.setStyleSheet("color: #666; font-size: 14px;")
        category_frame.addWidget(category_label)

        self.category_combo = QComboBox()
        self.category_combo.setFixedHeight(45)
        self.category_combo.addItem("请选择")
        self.category_combo.addItem("数码 - 手机 - 苹果")
        self.category_combo.addItem("数码 - 手机 - 安卓")
        self.category_combo.addItem("数码 - 电脑 - 笔记本")
        self.category_combo.addItem("数码 - 电脑 - 台式机")
        self.category_combo.addItem("服饰 - 男装")
        self.category_combo.addItem("服饰 - 女装")
        self.category_combo.addItem("图书 - 教材")
        self.category_combo.addItem("图书 - 小说")
        self.category_combo.addItem("家居 - 家具")
        self.category_combo.addItem("家居 - 装饰")
        self.category_combo.addItem("其他")
        self.category_combo.setStyleSheet("""
            QComboBox {
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 0 15px;
                font-size: 14px;
                background-color: white;
            }
            QComboBox:focus {
                border: 1px solid #FFA366;
            }
            QComboBox::drop-down {
                border: none;
                width: 30px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 6px solid #666;
                margin-right: 10px;
            }
        """)
        self.category_combo.currentIndexChanged.connect(self.update_publish_button_state)
        category_frame.addWidget(self.category_combo)

        layout.addLayout(category_frame)

        # 价格区域
        price_frame = QVBoxLayout()
        price_frame.setSpacing(5)

        price_label = QLabel("价格 *")
        price_label.setStyleSheet("color: #666; font-size: 14px;")
        price_frame.addWidget(price_label)

        price_input_layout = QHBoxLayout()
        price_input_layout.setSpacing(10)

        # ¥ 符号
        yuan_label = QLabel("¥")
        yuan_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 18px;
                font-weight: bold;
                padding: 0 5px;
            }
        """)
        price_input_layout.addWidget(yuan_label)

        # 价格输入框
        self.price_input = QLineEdit()
        self.price_input.setPlaceholderText("0.00")
        self.price_input.setFixedHeight(45)
        self.price_input.setStyleSheet("""
            QLineEdit {
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 0 15px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #FFA366;
            }
        """)
        self.price_input.textChanged.connect(self.update_publish_button_state)
        price_input_layout.addWidget(self.price_input)

        # 原价选填
        original_price_layout = QHBoxLayout()
        original_price_layout.setSpacing(5)

        original_label = QLabel("原价¥")
        original_label.setStyleSheet("color: #999; font-size: 14px;")
        original_price_layout.addWidget(original_label)

        self.original_price_input = QLineEdit()
        self.original_price_input.setPlaceholderText("选填")
        self.original_price_input.setFixedHeight(45)
        self.original_price_input.setStyleSheet("""
            QLineEdit {
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 0 15px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #FFA366;
            }
        """)
        original_price_layout.addWidget(self.original_price_input)

        price_input_layout.addLayout(original_price_layout)
        price_frame.addLayout(price_input_layout)

        layout.addLayout(price_frame)

        # 成色
        condition_frame = QVBoxLayout()
        condition_frame.setSpacing(5)

        condition_label = QLabel("宝贝成色")
        condition_label.setStyleSheet("color: #666; font-size: 14px;")
        condition_frame.addWidget(condition_label)

        self.condition_combo = QComboBox()
        self.condition_combo.setFixedHeight(45)
        self.condition_combo.addItems(["全新", "99新", "95新", "9成新", "8成新", "其他"])
        self.condition_combo.setStyleSheet("""
            QComboBox {
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 0 15px;
                font-size: 14px;
                background-color: white;
            }
            QComboBox:focus {
                border: 1px solid #FFA366;
            }
            QComboBox::drop-down {
                border: none;
                width: 30px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 6px solid #666;
                margin-right: 10px;
            }
        """)
        condition_frame.addWidget(self.condition_combo)

        layout.addLayout(condition_frame)

        self.info_section.setLayout(layout)

    def create_description_section(self):
        """创建描述区域"""
        self.description_section = QFrame()
        self.description_section.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                padding: 20px;
            }
        """)

        layout = QVBoxLayout()
        layout.setSpacing(5)

        # 标题
        desc_label = QLabel("宝贝描述")
        desc_label.setStyleSheet("color: #666; font-size: 14px;")
        layout.addWidget(desc_label)

        # 文本输入框
        self.description_input = QTextEdit()
        self.description_input.setPlaceholderText("描述宝贝的品牌、型号、使用情况、配件等信息")
        self.description_input.setFixedHeight(150)
        self.description_input.setStyleSheet("""
            QTextEdit {
                border: 1px solid #E0E0E0;
                border-radius: 8px;
                padding: 10px 15px;
                font-size: 14px;
            }
            QTextEdit:focus {
                border: 1px solid #FFA366;
            }
        """)
        self.description_input.textChanged.connect(self.on_description_changed)
        layout.addWidget(self.description_input)

        # 字数提示
        self.desc_count_label = QLabel("0/200")
        self.desc_count_label.setStyleSheet("color: #999; font-size: 12px;")
        self.desc_count_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        layout.addWidget(self.desc_count_label)

        self.description_section.setLayout(layout)

    def create_bottom_bar(self):
        """创建底部提交栏"""
        self.bottom_bar = QFrame()
        self.bottom_bar.setFixedHeight(70)
        self.bottom_bar.setStyleSheet("""
            QFrame {
                background-color: white;
                border-top: 1px solid #E0E0E0;
            }
        """)

        layout = QHBoxLayout()
        layout.setContentsMargins(20, 15, 20, 15)

        layout.addStretch()

        # 发布按钮
        self.publish_btn = QPushButton("发布宝贝")
        self.publish_btn.setFixedSize(200, 45)
        self.publish_btn.setStyleSheet("""
            QPushButton {
                background-color: #CCCCCC;
                color: white;
                border: none;
                border-radius: 22px;
                font-size: 16px;
                font-weight: bold;
            }
            QPushButton:hover:!disabled {
                background-color: #FFB380;
            }
            QPushButton:pressed:!disabled {
                background-color: #E55A2B;
            }
        """)
        self.publish_btn.setEnabled(False)
        self.publish_btn.clicked.connect(self.publish_product)
        layout.addWidget(self.publish_btn)

        layout.addStretch()

        self.bottom_bar.setLayout(layout)

    def on_title_changed(self):
        """标题改变事件"""
        text = self.title_input.text()
        count = len(text)
        self.title_count_label.setText(f"{count}/30")
        
        # 限制字数
        if count > 30:
            self.title_input.setText(text[:30])
            self.title_count_label.setText("30/30")
        
        self.update_publish_button_state()

    def on_description_changed(self):
        """描述改变事件"""
        text = self.description_input.toPlainText()
        count = len(text)
        self.desc_count_label.setText(f"{count}/200")
        
        # 限制字数
        if count > 200:
            self.description_input.setPlainText(text[:200])
            self.desc_count_label.setText("200/200")

    def update_publish_button_state(self):
        """更新发布按钮状态"""
        title = self.title_input.text().strip()
        category = self.category_combo.currentText()
        price = self.price_input.text().strip()

        # 检查必填项
        is_valid = (
            len(title) > 0 and
            category != "请选择" and
            len(price) > 0 and
            self.is_valid_price(price)
        )

        if is_valid:
            self.publish_btn.setEnabled(True)
            self.publish_btn.setStyleSheet("""
                QPushButton {
                    background-color: #FFA366;
                    color: white;
                    border: none;
                    border-radius: 22px;
                    font-size: 16px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #FFB380;
                }
                QPushButton:pressed {
                    background-color: #E55A2B;
                }
            """)
        else:
            self.publish_btn.setEnabled(False)
            self.publish_btn.setStyleSheet("""
                QPushButton {
                    background-color: #CCCCCC;
                    color: white;
                    border: none;
                    border-radius: 22px;
                    font-size: 16px;
                    font-weight: bold;
                }
            """)
            # 添加提示
            if not self.publish_btn.toolTip():
                self.publish_btn.setToolTip("请完善必填信息")

    def is_valid_price(self, price_str):
        """验证价格格式"""
        try:
            price = float(price_str)
            return price > 0
        except ValueError:
            return False

    def publish_product(self):
        """发布商品"""
        # 验证表单
        title = self.title_input.text().strip()
        category = self.category_combo.currentText()
        price_text = self.price_input.text().strip()
        condition = self.condition_combo.currentText()
        description = self.description_input.toPlainText().strip()
        image_paths = self.image_upload_area.image_paths
        
        if not title:
            QMessageBox.warning(self, "提示", "请输入宝贝标题")
            return
        if category == "请选择":
            QMessageBox.warning(self, "提示", "请选择宝贝分类")
            return
        try:
            price = float(price_text)
            if price <= 0:
                raise ValueError
        except ValueError:
            QMessageBox.warning(self, "提示", "请输入有效的价格")
            return
        if not image_paths:
            QMessageBox.warning(self, "提示", "请至少上传一张图片")
            return
        
        # 显示加载遮罩
        self.show_loading_overlay()
        
        # 在后台线程中执行发布
        import threading
        threading.Thread(target=self._publish_product_thread, daemon=True, args=(
            title, category, price, condition, description, image_paths
        )).start()
    
    def _publish_product_thread(self, title, category, price, condition, description, image_paths):
        """在后台线程中发布商品（使用本地存储）"""
        try:
            # 模拟延迟
            import time
            time.sleep(1)
            
            # 先确定当前发布使用的用户ID，优先以本地用户表匹配当前登录用户名，避免用错会话中的user_id
            chosen_user_id = None
            try:
                session_username = None
                session_uid = None
                try:
                    from user_session import get_session
                    session_info = get_session().get_user_info() or {}
                    session_username = session_info.get("username")
                    session_uid = session_info.get("user_id") or session_info.get("id")
                except Exception as e:
                    print(f"[DEBUG] 获取会话用户失败: {e}")
                
                from local_storage import load_data
                data_users = (load_data() or {}).get("users", [])
                
                # 1) 用会话里的用户名在本地用户表匹配
                if session_username:
                    for u in data_users:
                        if u.get("username") == session_username:
                            chosen_user_id = u.get("user_id")
                            break
                
                # 2) 如果还没有，用当前实例的user_id兜底
                if chosen_user_id is None and getattr(self, "user_id", None):
                    chosen_user_id = self.user_id
                
                # 3) 如果还没有，用会话里的user_id兜底
                if chosen_user_id is None and session_uid is not None:
                    chosen_user_id = session_uid
                
                # 4) 如果还没有，但本地只剩一个用户，则用该用户
                if chosen_user_id is None and len(data_users) == 1:
                    chosen_user_id = data_users[0].get("user_id")
                    session_username = session_username or data_users[0].get("username")
                
                if chosen_user_id is None:
                    raise Exception("未找到有效用户，请先登录后再发布。")
                
                # 更新当前实例的user_id，并记录当前用户名
                self.user_id = chosen_user_id
                current_username = session_username
                print(f"[DEBUG] 发布使用用户: username={current_username}, user_id={chosen_user_id}")
            except Exception as e:
                import traceback
                traceback.print_exc()
                raise Exception(f"获取用户信息失败: {e}")
            
            # 获取原价
            original_price = None
            try:
                original_price_text = self.original_price_input.text().strip()
                if original_price_text:
                    original_price = float(original_price_text)
            except:
                pass
            
            # 保存图片路径（本地测试，直接使用本地路径）
            img_path_str = ','.join(image_paths)
            
            # 保存到本地存储（必须成功）
            goods_data = {
                'user_id': self.user_id,
                'title': title,
                'category': category.split(' - ')[0] if ' - ' in category else category,  # 只取主分类
                'price': price,
                'original_price': original_price,
                'condition': condition,
                'description': description,
                'img_path': img_path_str,
                'status': 'pending'  # 待审核
            }
            
            print(f"[DEBUG] 准备保存到本地: user_id={self.user_id}, title={title}")
            
            # 添加到待审核列表（本地存储，必须成功）
            try:
                goods_id = self.add_pending_goods(goods_data)
                if goods_id is None:
                    raise Exception("本地保存失败：add_pending_goods返回None")
                print(f"[DEBUG] 商品已保存到本地，ID: {goods_id}")
            except Exception as e:
                print(f"[ERROR] 本地保存失败: {e}")
                import traceback
                traceback.print_exc()
                # 本地保存失败，抛出异常，不继续执行
                raise Exception(f"本地保存失败: {str(e)}")
            
            # 必须同步到服务器（不是静默，必须成功）
            # 使用上面确定的 user_id 发送到服务器
            server_user_id = self.user_id
            try:
                print(f"[DEBUG] 准备发送到服务器: user_id={server_user_id}, 本地user_id={self.user_id}")
                if server_user_id is None:
                    raise Exception("用户未在服务器注册，无法发布商品到服务器")
            except Exception as e:
                print(f"[DEBUG] 获取服务器user_id失败: {e}")
                raise Exception(f"获取用户信息失败: {str(e)}")
            
            # 连接服务器并发送商品数据
            from socket_client import SocketClient
            import json
            socket_client = SocketClient()
            
            try:
                # 连接服务器（增加超时时间，确保连接成功）
                connect_result = socket_client.connect("10.129.106.38", 8888, timeout=5.0)
                if not connect_result.startswith("连接成功") and connect_result != "已连接":
                    raise Exception(f"连接服务器失败: {connect_result}")
                
                # 准备发送到服务器的数据（严格按照API文档格式）
                server_goods_data = {
                    'user_id': server_user_id,  # 必填：发布者用户ID
                    'title': title,  # 必填：商品标题
                    'category': category.split(' - ')[0] if ' - ' in category else category,  # 必填：商品分类（只取主分类）
                    'price': float(price),  # 必填：商品价格（现价）
                    'description': description if description else '',  # 可选：商品描述
                    'stock_quantity': 1  # 可选：库存量（默认1）
                }
                
                # 可选字段
                if original_price:
                    server_goods_data['original_price'] = float(original_price)  # 可选：商品原价
                
                # 图片路径：如果有图片，使用第一张作为主图
                if image_paths and len(image_paths) > 0:
                    # 使用第一张图片作为主图
                    server_goods_data['img_path'] = image_paths[0]  # 可选：主图路径
                
                # 注意：API文档中没有condition字段，所以不发送
                # 注意：API文档中没有brand字段，如果有需要可以从category中提取或添加输入框
                
                print(f"[DEBUG] 准备发送到服务器（GOODS_ADD）:")
                print(f"[DEBUG] {json.dumps(server_goods_data, ensure_ascii=False, indent=2)}")
                
                # 直接使用socket_client发送命令（与注册流程一致）
                response = socket_client.send_command("GOODS_ADD", server_goods_data)
                print(f"[DEBUG] 服务器响应: {response}")
                
                # 解析响应
                if "|" not in response:
                    raise Exception("服务器响应格式错误")
                
                cmd, resp_body = response.split("|", 1)
                resp_data = json.loads(resp_body)
                code = resp_data.get("code", 500)
                msg = resp_data.get("msg", "未知错误")
                server_goods_id = resp_data.get("goods_id")
                
                if code == 200 and server_goods_id:
                    print(f"[DEBUG] 服务器发布成功，服务器商品ID: {server_goods_id}")
                    # 使用服务器返回的goods_id更新本地存储
                    try:
                        import GUI.local_storage as ls
                        data = ls.load_data()
                        # 查找本地商品并更新goods_id
                        for g in data.get('pending_goods', []):
                            if str(g.get('goods_id')) == str(goods_id):
                                old_goods_id = g.get('goods_id')
                                g['goods_id'] = server_goods_id
                                g['server_goods_id'] = server_goods_id  # 同时保存服务器ID作为备份
                                print(f"[DEBUG] 更新本地goods_id: {old_goods_id} -> {server_goods_id}")
                                break
                        ls.save_data(data)
                    except Exception as e:
                        print(f"[DEBUG] 更新本地goods_id失败（不影响服务器发布）: {e}")
                else:
                    raise Exception(f"服务器发布失败: {msg} (code={code})")
            finally:
                # 确保关闭连接
                try:
                    socket_client.close()
                except:
                    pass
            
            # 发布成功，直接跳转到审核页面（在主线程中执行）
            QTimer.singleShot(0, self._on_publish_success)
        except Exception as e:
            import traceback
            traceback.print_exc()
            QTimer.singleShot(0, lambda: (
                self._hide_loading_overlay(),
                QMessageBox.warning(self, "错误", f"发布失败: {str(e)}")
            ))
    
    
    def _hide_loading_overlay(self):
        """隐藏加载遮罩"""
        if hasattr(self, 'loading_overlay'):
            self.loading_overlay.hide()
            if hasattr(self, 'animation_timer'):
                self.animation_timer.stop()
    
    def _on_publish_success(self):
        """发布成功后的处理"""
        try:
            # 隐藏加载遮罩
            self._hide_loading_overlay()
            
            # 显示成功提示
            QMessageBox.information(self, "提示", "商品已提交给管理员审核！\n请前往管理员账号查看审核结果。")
            
            # 关闭发布页面
            self.close()
        except Exception as e:
            print(f"发布成功处理失败: {e}")
            import traceback
            traceback.print_exc()
            # 至少隐藏加载遮罩
            self._hide_loading_overlay()

    def show_loading_overlay(self):
        """显示加载遮罩"""
        self.loading_overlay = QWidget(self)
        self.loading_overlay.setGeometry(0, 0, self.width(), self.height())
        self.loading_overlay.setStyleSheet("background-color: rgba(0, 0, 0, 0.5);")
        
        overlay_layout = QVBoxLayout()
        overlay_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # 加载文字
        loading_label = QLabel("宝贝发布中...")
        loading_label.setStyleSheet("""
            QLabel {
                color: white;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        loading_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        overlay_layout.addWidget(loading_label)

        # 加载动画（简单的旋转效果）
        self.loading_animation_label = QLabel("⏳")
        self.loading_animation_label.setStyleSheet("""
            QLabel {
                color: white;
                font-size: 48px;
            }
        """)
        self.loading_animation_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        overlay_layout.addWidget(self.loading_animation_label)

        self.loading_overlay.setLayout(overlay_layout)
        self.loading_overlay.show()

        # 简单的旋转动画
        self.animation_timer = QTimer()
        self.animation_timer.timeout.connect(self.rotate_loading_icon)
        self.animation_timer.start(100)

    def rotate_loading_icon(self):
        """旋转加载图标"""
        # 简单的字符切换来模拟旋转
        icons = ["⏳", "🔄", "⏳", "🔄"]
        current_text = self.loading_animation_label.text()
        try:
            current_index = icons.index(current_text)
            next_index = (current_index + 1) % len(icons)
        except ValueError:
            next_index = 0
        self.loading_animation_label.setText(icons[next_index])

    def show_success_dialog(self):
        """显示成功弹窗"""
        # 隐藏加载遮罩
        if hasattr(self, 'loading_overlay'):
            self.loading_overlay.hide()
            if hasattr(self, 'animation_timer'):
                self.animation_timer.stop()

        dialog = QDialog(self)
        dialog.setWindowTitle("发布成功")
        dialog.setFixedSize(400, 250)
        dialog.setStyleSheet("""
            QDialog {
                background-color: white;
                border-radius: 12px;
            }
        """)

        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(30, 30, 30, 30)

        # 成功图标
        success_icon = QLabel("✓")
        success_icon.setStyleSheet("""
            QLabel {
                color: #52C41A;
                font-size: 64px;
                font-weight: bold;
            }
        """)
        success_icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(success_icon)

        # 成功文字
        success_text = QLabel("已提交给管理员审核！\n审核通过后商品将展示")
        success_text.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 14px;
                line-height: 1.5;
            }
        """)
        success_text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(success_text)

        # 按钮区域
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)

        # 返回首页按钮
        home_btn = QPushButton("返回首页")
        home_btn.setFixedHeight(40)
        home_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                color: #666;
                border: 1px solid #E0E0E0;
                border-radius: 20px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        home_btn.clicked.connect(lambda: (dialog.accept(), self.close()))
        button_layout.addWidget(home_btn)

        # 继续发布按钮
        continue_btn = QPushButton("继续发布")
        continue_btn.setFixedHeight(40)
        continue_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        continue_btn.clicked.connect(lambda: (dialog.accept(), self.reset_form()))
        button_layout.addWidget(continue_btn)

        layout.addLayout(button_layout)
        dialog.setLayout(layout)

        dialog.exec()

    def reset_form(self):
        """重置表单"""
        self.title_input.clear()
        self.category_combo.setCurrentIndex(0)
        self.price_input.clear()
        self.original_price_input.clear()
        self.condition_combo.setCurrentIndex(0)
        self.description_input.clear()
        
        # 清空图片
        self.image_upload_area.image_paths.clear()
        for widget in self.image_upload_area.image_widgets:
            widget.deleteLater()
        self.image_upload_area.image_widgets.clear()
        self.image_upload_area.add_btn.show()
        
        self.update_publish_button_state()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PublishPage()
    window.show()
    sys.exit(app.exec())

