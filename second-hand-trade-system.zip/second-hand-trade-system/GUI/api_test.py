"""
API连接测试工具
用于测试与后端的Socket连接和API调用
"""
import sys
import os
import json
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QTextEdit,
                             QLineEdit, QComboBox, QMessageBox, QFrame)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont

from api_service import get_api_service


class ApiTestThread(QThread):
    """API测试线程"""
    result_ready = pyqtSignal(str, bool)  # message, is_success
    
    def __init__(self, test_type, test_data):
        super().__init__()
        self.test_type = test_type
        self.test_data = test_data
    
    def run(self):
        """执行测试"""
        api = get_api_service()
        try:
            if self.test_type == "连接测试":
                success = api._connect()
                if success:
                    self.result_ready.emit("连接成功！", True)
                else:
                    self.result_ready.emit("连接失败，请检查服务器地址和端口", False)
            
            elif self.test_type == "获取商品列表":
                goods_list, total, error = api.goods_get(
                    category=self.test_data.get('category'),
                    status=self.test_data.get('status'),
                    page=self.test_data.get('page', 1),
                    page_size=self.test_data.get('page_size', 20)
                )
                if error:
                    self.result_ready.emit(f"获取失败: {error}", False)
                else:
                    self.result_ready.emit(
                        f"获取成功！共 {total} 条，返回 {len(goods_list)} 条\n"
                        f"示例数据: {json.dumps(goods_list[:2] if goods_list else [], ensure_ascii=False, indent=2)}",
                        True
                    )
            
            elif self.test_type == "发布商品":
                goods_id, error = api.goods_add(self.test_data)
                if error:
                    self.result_ready.emit(f"发布失败: {error}", False)
                else:
                    self.result_ready.emit(f"发布成功！商品ID: {goods_id}", True)
            
            elif self.test_type == "审核商品":
                success, error = api.goods_audit(
                    goods_id=self.test_data.get('goods_id'),
                    status=self.test_data.get('status'),
                    admin_user_id=self.test_data.get('admin_user_id')
                )
                if error:
                    self.result_ready.emit(f"审核失败: {error}", False)
                else:
                    self.result_ready.emit("审核成功！", True)
            
            elif self.test_type == "创建订单":
                order_id, order_no, error = api.order_add(
                    buyer_id=self.test_data.get('buyer_id'),
                    goods_id=self.test_data.get('goods_id'),
                    quantity=self.test_data.get('quantity', 1)
                )
                if error:
                    self.result_ready.emit(f"创建订单失败: {error}", False)
                else:
                    self.result_ready.emit(f"创建订单成功！订单ID: {order_id}, 订单号: {order_no}", True)
            
            elif self.test_type == "获取订单":
                orders, error = api.order_get(
                    buyer_id=self.test_data.get('buyer_id'),
                    status=self.test_data.get('status')
                )
                if error:
                    self.result_ready.emit(f"获取失败: {error}", False)
                else:
                    self.result_ready.emit(
                        f"获取成功！共 {len(orders)} 条订单\n"
                        f"示例数据: {json.dumps(orders[:2] if orders else [], ensure_ascii=False, indent=2)}",
                        True
                    )
            
            elif self.test_type == "更新订单状态":
                success, error = api.order_update(
                    order_id=self.test_data.get('order_id'),
                    status=self.test_data.get('status')
                )
                if error:
                    self.result_ready.emit(f"更新失败: {error}", False)
                else:
                    self.result_ready.emit("更新成功！", True)
        
        except Exception as e:
            self.result_ready.emit(f"测试异常: {str(e)}", False)
        finally:
            api.close()


class ApiTestWindow(QMainWindow):
    """API测试窗口"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("API连接测试工具")
        self.setGeometry(100, 100, 800, 700)
        self.setStyleSheet("background-color: #F8F8F8;")
        
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(15)
        
        # 标题
        title = QLabel("后端API连接测试工具")
        title.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 24px;
                font-weight: bold;
            }
        """)
        main_layout.addWidget(title)
        
        # 测试类型选择
        test_type_frame = QFrame()
        test_type_frame.setStyleSheet("background-color: white; border-radius: 8px; padding: 15px;")
        test_type_layout = QVBoxLayout()
        test_type_layout.setSpacing(10)
        
        type_label = QLabel("选择测试类型:")
        type_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        test_type_layout.addWidget(type_label)
        
        self.test_type_combo = QComboBox()
        self.test_type_combo.addItems([
            "连接测试",
            "获取商品列表",
            "发布商品",
            "审核商品",
            "创建订单",
            "获取订单",
            "更新订单状态"
        ])
        self.test_type_combo.currentTextChanged.connect(self.on_test_type_changed)
        test_type_layout.addWidget(self.test_type_combo)
        
        test_type_frame.setLayout(test_type_layout)
        main_layout.addWidget(test_type_frame)
        
        # 测试参数输入区域
        self.params_frame = QFrame()
        self.params_frame.setStyleSheet("background-color: white; border-radius: 8px; padding: 15px;")
        self.params_layout = QVBoxLayout()
        self.params_layout.setSpacing(10)
        
        params_label = QLabel("测试参数 (JSON格式):")
        params_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.params_layout.addWidget(params_label)
        
        self.params_input = QTextEdit()
        self.params_input.setPlaceholderText('例如: {"category": "电子产品", "status": "on_sale", "page": 1, "page_size": 20}')
        self.params_input.setFixedHeight(150)
        self.params_input.setStyleSheet("""
            QTextEdit {
                border: 1px solid #E0E0E0;
                border-radius: 4px;
                padding: 8px;
                font-family: 'Consolas', 'Monaco', monospace;
            }
        """)
        self.params_layout.addWidget(self.params_input)
        
        # 示例按钮
        example_btn = QPushButton("加载示例参数")
        example_btn.setStyleSheet("""
            QPushButton {
                background-color: #F5F5F5;
                border: 1px solid #E0E0E0;
                border-radius: 4px;
                padding: 6px 15px;
            }
            QPushButton:hover {
                background-color: #E0E0E0;
            }
        """)
        example_btn.clicked.connect(self.load_example)
        self.params_layout.addWidget(example_btn)
        
        self.params_frame.setLayout(self.params_layout)
        main_layout.addWidget(self.params_frame)
        
        # 测试按钮
        test_btn = QPushButton("执行测试")
        test_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px;
                font-size: 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FF8C42;
            }
        """)
        test_btn.clicked.connect(self.run_test)
        main_layout.addWidget(test_btn)
        
        # 结果显示区域
        result_frame = QFrame()
        result_frame.setStyleSheet("background-color: white; border-radius: 8px; padding: 15px;")
        result_layout = QVBoxLayout()
        result_layout.setSpacing(10)
        
        result_label = QLabel("测试结果:")
        result_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        result_layout.addWidget(result_label)
        
        self.result_output = QTextEdit()
        self.result_output.setReadOnly(True)
        self.result_output.setStyleSheet("""
            QTextEdit {
                border: 1px solid #E0E0E0;
                border-radius: 4px;
                padding: 8px;
                background-color: #FAFAFA;
                font-family: 'Consolas', 'Monaco', monospace;
            }
        """)
        result_layout.addWidget(self.result_output)
        
        result_frame.setLayout(result_layout)
        main_layout.addWidget(result_frame)
        
        main_widget.setLayout(main_layout)
        
        # 初始化示例参数
        self.on_test_type_changed()
    
    def on_test_type_changed(self):
        """测试类型改变时更新示例参数"""
        test_type = self.test_type_combo.currentText()
        examples = {
            "连接测试": "{}",
            "获取商品列表": '{"category": "电子产品", "status": "on_sale", "page": 1, "page_size": 20}',
            "发布商品": '{"user_id": 1, "title": "测试商品", "category": "电子产品", "price": 100.0, "description": "这是一个测试商品"}',
            "审核商品": '{"goods_id": 1, "status": "on_sale", "admin_user_id": 1}',
            "创建订单": '{"buyer_id": 2, "goods_id": 1, "quantity": 1}',
            "获取订单": '{"buyer_id": 2, "status": "pending_payment"}',
            "更新订单状态": '{"order_id": 1, "status": "pending_shipment"}'
        }
        self.params_input.setPlainText(examples.get(test_type, "{}"))
    
    def load_example(self):
        """加载示例参数"""
        self.on_test_type_changed()
    
    def run_test(self):
        """执行测试"""
        test_type = self.test_type_combo.currentText()
        params_text = self.params_input.toPlainText().strip()
        
        # 解析参数
        try:
            test_data = json.loads(params_text) if params_text else {}
        except json.JSONDecodeError:
            QMessageBox.warning(self, "错误", "参数格式错误，请输入有效的JSON格式")
            return
        
        # 显示测试开始
        self.result_output.clear()
        self.result_output.append(f"开始测试: {test_type}")
        self.result_output.append(f"参数: {params_text}")
        self.result_output.append("正在连接服务器...\n")
        
        # 创建测试线程
        self.test_thread = ApiTestThread(test_type, test_data)
        self.test_thread.result_ready.connect(self.on_test_result)
        self.test_thread.start()
    
    def on_test_result(self, message, is_success):
        """测试结果回调"""
        if is_success:
            self.result_output.append(f"✓ {message}")
            self.result_output.setStyleSheet("""
                QTextEdit {
                    border: 1px solid #52C41A;
                    border-radius: 4px;
                    padding: 8px;
                    background-color: #F6FFED;
                    font-family: 'Consolas', 'Monaco', monospace;
                }
            """)
        else:
            self.result_output.append(f"✗ {message}")
            self.result_output.setStyleSheet("""
                QTextEdit {
                    border: 1px solid #FF4D4F;
                    border-radius: 4px;
                    padding: 8px;
                    background-color: #FFF1F0;
                    font-family: 'Consolas', 'Monaco', monospace;
                }
            """)
        
        QMessageBox.information(self, "测试完成", message)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ApiTestWindow()
    window.show()
    sys.exit(app.exec())

