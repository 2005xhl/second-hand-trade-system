"""
用户管理页面（管理员专用）
"""
import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QLineEdit, QTableWidget, QTableWidgetItem,
                             QHeaderView)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont


class UserManagementPage(QMainWindow):
    """用户管理页面"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("用户管理 - 闲转")
        self.setGeometry(100, 100, 1200, 800)
        self.setStyleSheet("background-color: #F8F8F8;")
        
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)
        
        # 内容区
        self.create_content()
        main_layout.addWidget(self.content_area)
        
        main_widget.setLayout(main_layout)
        
        # 加载用户数据
        self.load_users()
    
    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        
        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333;
                border: none;
                font-size: 16px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #F5F5F5;
                border-radius: 5px;
            }
        """)
        back_btn.clicked.connect(self.close)
        layout.addWidget(back_btn)
        
        # 标题
        title_label = QLabel("用户管理")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label, 1)
        
        self.top_nav.setLayout(layout)
    
    def create_content(self):
        """创建内容区"""
        self.content_area = QScrollArea()
        self.content_area.setWidgetResizable(True)
        self.content_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(20, 20, 20, 20)
        scroll_layout.setSpacing(20)
        
        # 搜索栏和刷新按钮
        search_frame = QFrame()
        search_frame.setFixedHeight(50)
        search_frame.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 8px;
                border: 1px solid #E0E0E0;
            }
        """)
        
        search_layout = QHBoxLayout()
        search_layout.setContentsMargins(15, 10, 15, 10)
        
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("搜索用户名或ID...")
        self.search_input.setStyleSheet("""
            QLineEdit {
                border: none;
                font-size: 14px;
            }
        """)
        self.search_input.textChanged.connect(self.on_search_changed)
        search_layout.addWidget(self.search_input)
        
        search_btn = QPushButton("搜索")
        search_btn.setFixedSize(80, 30)
        search_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 15px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        search_btn.clicked.connect(self.on_search_clicked)
        search_layout.addWidget(search_btn)
        
        refresh_btn = QPushButton("刷新")
        refresh_btn.setFixedSize(80, 30)
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 15px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        """)
        refresh_btn.clicked.connect(self.load_users)
        search_layout.addWidget(refresh_btn)
        
        search_frame.setLayout(search_layout)
        scroll_layout.addWidget(search_frame)
        
        # 用户表格
        self.user_table = QTableWidget()
        self.user_table.setColumnCount(7)
        self.user_table.setHorizontalHeaderLabels(["用户ID", "用户名", "密码", "昵称", "角色", "注册时间", "操作"])
        self.user_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.user_table.setStyleSheet("""
            QTableWidget {
                background-color: white;
                border-radius: 8px;
                border: 1px solid #E0E0E0;
                gridline-color: #E0E0E0;
            }
            QTableWidget::item {
                padding: 10px;
            }
            QHeaderView::section {
                background-color: #F5F5F5;
                padding: 10px;
                border: none;
                font-weight: bold;
            }
        """)
        scroll_layout.addWidget(self.user_table)
        
        scroll_content.setLayout(scroll_layout)
        self.content_area.setWidget(scroll_content)
    
    def load_users(self, search_keyword=None):
        """加载用户数据（从本地存储或服务器）"""
        try:
            # 优先尝试从服务器获取用户列表
            server_users = []
            try:
                from api_service import get_api_service
                api = get_api_service()
                # TODO: 如果服务器有获取所有用户的API，在这里调用
                # users_list, error = api.user_get_all()
                # if not error and users_list:
                #     server_users = users_list
            except Exception as e:
                print(f"[DEBUG] 从服务器获取用户列表失败: {e}，使用本地存储")
            
            # 从本地存储获取用户数据
            from local_storage import load_data
            data = load_data()
            local_users = data.get('users', [])
            
            # 合并用户数据（优先使用服务器数据）
            all_users = server_users if server_users else local_users
            
            # 应用搜索过滤
            if search_keyword:
                search_keyword = search_keyword.strip().lower()
                filtered_users = []
                for user in all_users:
                    user_id = str(user.get('user_id', ''))
                    username = str(user.get('username', '')).lower()
                    nickname = str(user.get('nickname', '')).lower()
                    if (search_keyword in user_id.lower() or 
                        search_keyword in username or 
                        search_keyword in nickname):
                        filtered_users.append(user)
                all_users = filtered_users
            
            # 显示用户数据
            self.user_table.setRowCount(len(all_users))
            for i, user in enumerate(all_users):
                user_id = str(user.get('user_id', ''))
                username = user.get('username', '')
                password = user.get('password', '')
                nickname = user.get('nickname', username)
                role = user.get('role', 'normal')
                create_time = user.get('create_time', '未知')
                
                # 密码显示为星号（保护隐私）
                password_display = '*' * len(password) if password else '无'
                
                self.user_table.setItem(i, 0, QTableWidgetItem(user_id))
                self.user_table.setItem(i, 1, QTableWidgetItem(username))
                self.user_table.setItem(i, 2, QTableWidgetItem(password_display))
                self.user_table.setItem(i, 3, QTableWidgetItem(nickname))
                
                # 角色显示
                role_text = "管理员" if role == "admin" else "普通用户"
                self.user_table.setItem(i, 4, QTableWidgetItem(role_text))
                self.user_table.setItem(i, 5, QTableWidgetItem(create_time))
                
                # 操作按钮
                action_btn = QPushButton("查看详情")
                action_btn.setFixedSize(80, 30)
                action_btn.setStyleSheet("""
                    QPushButton {
                        background-color: #FFA366;
                        color: white;
                        border: none;
                        border-radius: 15px;
                        font-size: 12px;
                    }
                    QPushButton:hover {
                        background-color: #FFB380;
                    }
                """)
                # 绑定点击事件（传递完整的用户数据）
                action_btn.clicked.connect(lambda checked, u=user: self.view_user_detail(u))
                self.user_table.setCellWidget(i, 6, action_btn)
            
            print(f"[DEBUG] 已加载 {len(all_users)} 个用户")
        except Exception as e:
            print(f"[ERROR] 加载用户数据失败: {e}")
            import traceback
            traceback.print_exc()
            # 如果加载失败，显示空表格
            self.user_table.setRowCount(0)
    
    def on_search_changed(self, text):
        """搜索框内容变化时的处理（实时搜索）"""
        if not text.strip():
            # 如果搜索框为空，重新加载所有用户
            self.load_users()
        else:
            # 应用搜索过滤
            self.load_users(search_keyword=text)
    
    def on_search_clicked(self):
        """搜索按钮点击"""
        keyword = self.search_input.text()
        self.load_users(search_keyword=keyword)
    
    def view_user_detail(self, user_data):
        """查看用户详情"""
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton
        from local_storage import load_data
        
        dialog = QDialog(self)
        dialog.setWindowTitle("用户详情")
        dialog.setFixedSize(450, 500)
        dialog.setStyleSheet("""
            QDialog {
                background-color: white;
                border-radius: 12px;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setSpacing(15)
        layout.setContentsMargins(30, 30, 30, 30)
        
        # 获取用户统计数据
        user_id = user_data.get('user_id')
        username = user_data.get('username', '')
        password = user_data.get('password', '')
        nickname = user_data.get('nickname', username)
        role = user_data.get('role', 'normal')
        create_time = user_data.get('create_time', '未知')
        
        # 统计用户发布商品数、成交订单数等
        data = load_data()
        published_count = 0
        sold_count = 0
        bought_count = 0
        
        # 统计发布商品数
        for bucket in ['pending_goods', 'approved_goods', 'sold_goods', 'rejected_goods']:
            for goods in data.get(bucket, []):
                if str(goods.get('user_id')) == str(user_id):
                    published_count += 1
        
        # 统计卖出数（已售出商品）
        for goods in data.get('sold_goods', []):
            if str(goods.get('user_id')) == str(user_id):
                sold_count += 1
        
        # 统计买入数（订单中的buyer_id）
        for order in data.get('orders', []):
            if str(order.get('buyer_id')) == str(user_id):
                bought_count += 1
        
        role_text = "管理员" if role == "admin" else "普通用户"
        
        # 用户信息（不包含手机号）
        info_text = f"""
        <h3>用户详情</h3>
        <p><b>用户ID:</b> {user_id}</p>
        <p><b>用户名:</b> {username}</p>
        <p><b>密码:</b> {password}</p>
        <p><b>昵称:</b> {nickname}</p>
        <p><b>角色:</b> {role_text}</p>
        <p><b>注册时间:</b> {create_time}</p>
        <hr>
        <p><b>发布商品数:</b> {published_count}</p>
        <p><b>卖出商品数:</b> {sold_count}</p>
        <p><b>购买订单数:</b> {bought_count}</p>
        """
        info_label = QLabel(info_text)
        info_label.setStyleSheet("font-size: 14px; color: #333;")
        layout.addWidget(info_label)
        
        layout.addStretch()
        
        # 关闭按钮
        close_btn = QPushButton("关闭")
        close_btn.setFixedHeight(40)
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        close_btn.clicked.connect(dialog.accept)
        layout.addWidget(close_btn)
        
        dialog.setLayout(layout)
        dialog.exec()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = UserManagementPage()
    window.show()
    sys.exit(app.exec())

