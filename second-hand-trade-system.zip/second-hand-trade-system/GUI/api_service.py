"""
API服务层 - 封装与后端Socket通信
处理字段映射和数据转换
"""
import json
import sys
import os
import threading
from datetime import datetime

# 添加根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from socket_client import SocketClient

# 服务器配置
SERVER_IP = "10.129.106.38"
SERVER_PORT = 8888

# 状态映射：前端 → 后端
GOODS_STATUS_MAP = {
    'pending': 'pending_review',
    'approved': 'on_sale',
    'sold': 'sold',
    'off': 'on_sale',  # 下架商品，后端可能用on_sale+off_time
    'rejected': 'rejected'
}

# 状态映射：后端 → 前端
GOODS_STATUS_REVERSE_MAP = {
    'pending_review': 'pending',
    'on_sale': 'approved',
    'sold': 'sold',
    'rejected': 'rejected'
}

# 订单状态映射：前端 → 后端
ORDER_STATUS_MAP = {
    '待付款': 'pending_payment',
    '待发货': 'pending_shipment',
    '待收货': 'pending_receipt',
    '已完成': 'completed',
    '已取消': 'canceled',
    '售后中': 'after_sales_in_progress',
    '退款成功': 'refund_successful',
    '退款失败': 'refund_failed'
}

# 订单状态映射：后端 → 前端
ORDER_STATUS_REVERSE_MAP = {
    'pending_payment': '待付款',
    'pending_shipment': '待发货',
    'pending_receipt': '待收货',
    'completed': '已完成',
    'canceled': '已取消',
    'after_sales_in_progress': '售后中',
    'refund_successful': '退款成功',
    'refund_failed': '退款失败'
}


class ApiService:
    """API服务类，封装所有后端API调用"""
    
    def __init__(self):
        self.client = SocketClient()
        self.connected = False
    
    def _connect(self):
        """连接服务器"""
        # 检查底层socket客户端的实际连接状态
        if hasattr(self.client, 'connected'):
            if not self.client.connected:
                self.connected = False
        
        if not self.connected:
            result = self.client.connect(SERVER_IP, SERVER_PORT, timeout=3.0)
            if result.startswith("连接成功") or result == "已连接":
                self.connected = True
                if hasattr(self.client, 'connected'):
                    self.client.connected = True
                return True
            print(f"[DEBUG] ApiService连接失败: {result}")
            self.connected = False
            if hasattr(self.client, 'connected'):
                self.client.connected = False
            return False
        return True
    
    def _send_command(self, cmd, data):
        """发送命令并解析响应"""
        if not self._connect():
            return None, "连接服务器失败"
        
        try:
            print(f"[DEBUG] ApiService发送命令: {cmd}, 数据: {data}")
            response = self.client.send_command(cmd, data)
            print(f"[DEBUG] ApiService收到响应: {response[:200] if len(response) > 200 else response}...")  # 只打印前200个字符
            
            # 检查响应是否表示连接失败，如果是则重置连接状态
            if response.startswith("未连接服务器") or response.startswith("发送/接收失败"):
                self.connected = False
                if hasattr(self.client, 'connected'):
                    self.client.connected = False
            
            if "|" in response:
                cmd_resp, resp_body = response.split("|", 1)
                try:
                    resp_data = json.loads(resp_body)
                    print(f"[DEBUG] ApiService解析响应成功: code={resp_data.get('code')}")
                    return resp_data, None
                except json.JSONDecodeError:
                    print(f"[DEBUG] ApiService响应解析失败: {resp_body}")
                    return None, f"响应解析失败: {resp_body}"
            print(f"[DEBUG] ApiService响应格式错误: {response}")
            return None, f"响应格式错误: {response}"
        except Exception as e:
            print(f"[DEBUG] ApiService请求异常: {e}")
            # 发生异常时重置连接状态
            self.connected = False
            if hasattr(self.client, 'connected'):
                self.client.connected = False
            import traceback
            traceback.print_exc()
            return None, f"请求失败: {str(e)}"
    
    def _goods_to_frontend(self, goods):
        """将后端商品数据转换为前端格式"""
        if not goods:
            return goods
        
        # 状态映射
        status = goods.get('status', '')
        goods['status'] = GOODS_STATUS_REVERSE_MAP.get(status, status)
        
        # 图片处理：如果后端返回images数组，转换为逗号分隔字符串
        if 'images' in goods and isinstance(goods['images'], list):
            img_paths = [img.get('img_path', '') for img in goods['images'] if img.get('img_path')]
            if img_paths:
                goods['img_path'] = ','.join(img_paths)
        elif 'primary_image' in goods and goods['primary_image']:
            goods['img_path'] = goods['primary_image']
        
        # 时间字段格式统一（如果需要）
        # create_time, audit_time, off_time 保持原样
        
        return goods
    
    def _goods_to_backend(self, goods):
        """将前端商品数据转换为后端格式"""
        if not goods:
            return goods
        
        # 状态映射
        status = goods.get('status', '')
        goods['status'] = GOODS_STATUS_MAP.get(status, status)
        
        # 图片处理：如果前端是逗号分隔字符串，转换为数组格式
        if 'img_path' in goods and isinstance(goods['img_path'], str) and ',' in goods['img_path']:
            img_paths = [p.strip() for p in goods['img_path'].split(',') if p.strip()]
            goods['images'] = [
                {
                    'img_path': path,
                    'display_order': idx,
                    'is_primary': 1 if idx == 0 else 0
                }
                for idx, path in enumerate(img_paths)
            ]
            # 保留img_path作为主图
            goods['primary_image'] = img_paths[0] if img_paths else ''
        elif 'img_path' in goods:
            goods['primary_image'] = goods['img_path']
            goods['images'] = [{
                'img_path': goods['img_path'],
                'display_order': 0,
                'is_primary': 1
            }]
        
        # 移除前端特有字段（如果后端不需要）
        # condition字段保留，后端可能需要补充支持
        
        return goods
    
    def _order_to_frontend(self, order):
        """将后端订单数据转换为前端格式"""
        if not order:
            return order
        
        # 状态映射
        status = order.get('status', '')
        order['status'] = ORDER_STATUS_REVERSE_MAP.get(status, status)
        
        # 字段名映射
        if 'order_no' in order:
            order['order_number'] = order['order_no']
        if 'created_at' in order:
            order['order_time'] = order['created_at']
        if 'total_price' in order:
            order['price'] = order['total_price']
        
        return order

    # ========== 聊天相关 ==========
    def chat_send(self, sender_id, receiver_id, content):
        """
        发送聊天消息
        请求: CHAT_SEND|{"sender_id": 1, "receiver_id": 2, "content": "你好"}
        成功返回 (message_id, None); 失败返回 (None, error_msg)
        """
        request_data = {
            "sender_id": sender_id,
            "receiver_id": receiver_id,
            "content": content
        }
        resp_data, error = self._send_command("CHAT_SEND", request_data)
        if error:
            return None, error
        if resp_data.get("code") == 200:
            return resp_data.get("message_id"), None
        return None, resp_data.get("msg", "发送失败")
    
    def _order_to_backend(self, order):
        """将前端订单数据转换为后端格式"""
        if not order:
            return order
        
        # 状态映射
        status = order.get('status', '')
        order['status'] = ORDER_STATUS_MAP.get(status, status)
        
        # 字段名映射
        if 'order_number' in order:
            order['order_no'] = order['order_number']
        if 'order_time' in order:
            order['created_at'] = order['order_time']
        if 'price' in order and 'total_price' not in order:
            order['total_price'] = order['price']
        
        return order
    
    # ========== 商品相关API ==========
    
    def goods_add(self, goods_data):
        """
        发布商品
        goods_data: 前端格式的商品数据
        返回: (goods_id, error_msg)
        """
        # 转换为后端格式
        backend_data = self._goods_to_backend(goods_data.copy())
        
        # 构建请求数据（只包含后端需要的字段）
        request_data = {
            'user_id': backend_data.get('user_id'),
            'title': backend_data.get('title'),
            'description': backend_data.get('description', ''),
            'category': backend_data.get('category'),
            'price': backend_data.get('price'),
        }
        
        # 可选字段
        if 'brand' in backend_data:
            request_data['brand'] = backend_data['brand']
        if 'original_price' in backend_data and backend_data['original_price']:
            request_data['original_price'] = backend_data['original_price']
        if 'purchase_time' in backend_data:
            request_data['purchase_time'] = backend_data['purchase_time']
        if 'stock_quantity' in backend_data:
            request_data['stock_quantity'] = backend_data['stock_quantity']
        else:
            request_data['stock_quantity'] = 1  # 默认1
        if 'primary_image' in backend_data:
            request_data['img_path'] = backend_data['primary_image']
        
        resp_data, error = self._send_command("GOODS_ADD", request_data)
        if error:
            return None, error
        
        if resp_data.get('code') == 200:
            goods_id = resp_data.get('goods_id')
            return goods_id, None
        else:
            return None, resp_data.get('msg', '发布失败')
    
    def goods_get(self, category=None, status=None, page=1, page_size=20):
        """
        获取商品列表
        返回: (goods_list, total, error_msg)
        """
        # 确保page和page_size是整数类型
        try:
            page = int(page) if page is not None else 1
            page_size = int(page_size) if page_size is not None else 20
        except (ValueError, TypeError):
            page = 1
            page_size = 20
        
        request_data = {
            'page': page,
            'page_size': page_size
        }
        
        if category:
            request_data['category'] = str(category)
        if status:
            # 状态映射
            request_data['status'] = GOODS_STATUS_MAP.get(status, status)
        
        resp_data, error = self._send_command("GOODS_GET", request_data)
        if error:
            return [], 0, error
        
        if resp_data.get('code') == 200:
            goods_list = resp_data.get('data', [])
            # 转换为前端格式
            frontend_goods = [self._goods_to_frontend(g) for g in goods_list]
            total = resp_data.get('total', len(frontend_goods))
            return frontend_goods, total, None
        else:
            return [], 0, resp_data.get('msg', '查询失败')
    
    def goods_audit(self, goods_id, status, admin_user_id=None):
        """
        审核商品
        status: 'on_sale' 或 'rejected'
        返回: (success, error_msg)
        """
        request_data = {
            'goods_id': goods_id,
            'status': status  # 后端直接使用 on_sale 或 rejected
        }
        
        if admin_user_id:
            request_data['admin_user_id'] = admin_user_id
        
        resp_data, error = self._send_command("GOODS_AUDIT", request_data)
        if error:
            return False, error
        
        if resp_data.get('code') == 200:
            return True, None
        else:
            return False, resp_data.get('msg', '审核失败')
    
    def goods_update_status(self, goods_id, status):
        """
        更新商品状态（购买后更新为待发货等）
        status: 'pending_shipment' 待发货, 'sold' 已售出等
        返回: (success, error_msg)
        """
        request_data = {
            'goods_id': goods_id,
            'status': status  # 后端状态：pending_shipment, sold等
        }
        
        resp_data, error = self._send_command("GOODS_UPDATE_STATUS", request_data)
        if error:
            return False, error
        
        if resp_data.get('code') == 200:
            return True, None
        else:
            return False, resp_data.get('msg', '更新商品状态失败')
    
    def image_upload(self, chunk_id, chunk_index, total_chunks, chunk_data, 
                     filename=None, goods_id=None, is_primary=0, display_order=0):
        """
        上传图片分片
        返回: (img_path, received, total, error_msg)
        """
        request_data = {
            'chunk_id': chunk_id,
            'chunk_index': chunk_index,
            'total_chunks': total_chunks,
            'chunk_data': chunk_data  # base64编码
        }
        
        if filename:
            request_data['filename'] = filename
        if goods_id:
            request_data['goods_id'] = goods_id
        if is_primary:
            request_data['is_primary'] = is_primary
        if display_order:
            request_data['display_order'] = display_order
        
        resp_data, error = self._send_command("IMAGE_UPLOAD", request_data)
        if error:
            return None, 0, 0, error
        
        if resp_data.get('code') == 200:
            img_path = resp_data.get('img_path')
            received = resp_data.get('received', total_chunks)
            total = resp_data.get('total', total_chunks)
            return img_path, received, total, None
        else:
            return None, 0, 0, resp_data.get('msg', '上传失败')
    
    # ========== 订单相关API ==========
    
    def order_add(self, buyer_id, goods_id, quantity=1):
        """
        创建订单
        返回: (order_id, order_no, error_msg)
        """
        request_data = {
            'buyer_id': buyer_id,
            'goods_id': goods_id,
            'quantity': quantity
        }
        
        resp_data, error = self._send_command("ORDER_ADD", request_data)
        if error:
            return None, None, error
        
        if resp_data.get('code') == 200:
            order_id = resp_data.get('order_id')
            order_no = resp_data.get('order_no')
            return order_id, order_no, None
        else:
            return None, None, resp_data.get('msg', '下单失败')
    
    def order_update(self, order_id, status):
        """
        更新订单状态
        返回: (success, error_msg)
        """
        # 状态映射
        backend_status = ORDER_STATUS_MAP.get(status, status)
        
        request_data = {
            'order_id': order_id,
            'status': backend_status
        }
        
        resp_data, error = self._send_command("ORDER_UPDATE", request_data)
        if error:
            return False, error
        
        if resp_data.get('code') == 200:
            return True, None
        else:
            return False, resp_data.get('msg', '更新失败')
    
    def order_get(self, buyer_id, status=None):
        """
        获取订单列表
        返回: (orders_list, error_msg)
        """
        request_data = {
            'buyer_id': buyer_id
        }
        
        if status:
            # 状态映射
            request_data['status'] = ORDER_STATUS_MAP.get(status, status)
        
        resp_data, error = self._send_command("ORDER_GET", request_data)
        if error:
            return [], error
        
        if resp_data.get('code') == 200:
            orders_list = resp_data.get('data', [])
            # 转换为前端格式
            frontend_orders = [self._order_to_frontend(o) for o in orders_list]
            return frontend_orders, None
        else:
            return [], resp_data.get('msg', '查询失败')
    
    def close(self):
        """关闭连接"""
        if self.client:
            self.client.close()
        self.connected = False


# 全局API服务实例（可选，也可以每次创建新实例）
_api_service = None

def get_api_service():
    """获取API服务实例（单例模式）"""
    global _api_service
    if _api_service is None:
        _api_service = ApiService()
    return _api_service

