"""
我卖出的页面
显示用户已卖出的商品列表，点击进入商品详情页
"""
import sys
import os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QGridLayout)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor
from local_storage import get_sold_goods, get_order_by_id


class MySaleCard(QFrame):
    """已卖出商品卡片"""
    clicked = None
    
    def __init__(self, product_data, parent=None):
        super().__init__(parent)
        self.product_data = product_data
        self.after_sale_reason = product_data.get("after_sale_reason") or ""
        self.after_sale_status = product_data.get("after_sale_status") or ""
        
        self.setFixedSize(200, 280)
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                border: 1px solid #E0E0E0;
            }
            QFrame:hover {
                border: 2px solid #FFA366;
                background-color: #FFF8F5;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # 商品图片
        image_label = QLabel()
        image_label.setFixedSize(180, 180)
        image_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                border-radius: 8px;
            }
        """)
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # 尝试加载真实图片
        img_path = product_data.get("img_path", "")
        if img_path and ',' in str(img_path):
            img_path = str(img_path).split(',')[0].strip()
        if img_path:
            if not os.path.isabs(img_path):
                project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                img_path = os.path.join(project_root, img_path)
            if os.path.exists(img_path):
                pixmap = QPixmap(img_path)
                if not pixmap.isNull():
                    pixmap = pixmap.scaled(180, 180, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                    image_label.setPixmap(pixmap)
                else:
                    self._set_placeholder(image_label)
            else:
                self._set_placeholder(image_label)
        else:
            self._set_placeholder(image_label)
        
        layout.addWidget(image_label)
        # 售后标记
        status_text = self.product_data.get("after_sale_status") or ""
        if status_text == "已退款":
            badge_text = "已退款"
        elif status_text:
            badge_text = status_text
        elif self.after_sale_reason:
            badge_text = "申请售后"
        else:
            badge_text = ""

        if badge_text:
            badge = QLabel(badge_text)
            badge.setStyleSheet("""
                QLabel {
                    background-color: #FFF1E6;
                    color: #FF7A45;
                    padding: 4px 8px;
                    border-radius: 10px;
                    font-size: 11px;
                    font-weight: bold;
                    border: 1px solid #FFB380;
                }
            """)
            badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            badge.move(10, 10)
            badge.setParent(self)
        
        # 商品标题
        title_label = QLabel(product_data.get("title", "商品标题"))
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        title_label.setWordWrap(True)
        title_label.setMaximumHeight(40)
        layout.addWidget(title_label)
        
        # 价格和状态
        price_status_layout = QHBoxLayout()
        price_status_layout.setContentsMargins(0, 0, 0, 0)
        price_status_layout.setSpacing(8)

        price_label = QLabel(f"¥{product_data.get('price', 0)}")
        price_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        price_status_layout.addWidget(price_label)

        status_label = QLabel(self._status_text())
        status_label.setStyleSheet("""
            QLabel {
                color: #666;
                font-size: 12px;
            }
        """)
        price_status_layout.addWidget(status_label)
        price_status_layout.addStretch()
        layout.addLayout(price_status_layout)
        
        layout.addStretch()
        self.setLayout(layout)
    
    def mousePressEvent(self, event):
        """点击事件"""
        if event.button() == Qt.MouseButton.LeftButton and self.clicked:
            self.clicked()

    def _set_placeholder(self, label):
        pixmap = QPixmap(180, 180)
        pixmap.fill(QColor(245, 245, 245))
        painter = QPainter(pixmap)
        painter.setPen(QColor(200, 200, 200))
        painter.setFont(QFont("Arial", 40))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "📷")
        painter.end()
        label.setPixmap(pixmap)

    def paintEvent(self, event):
        super().paintEvent(event)
        # 让 badge 保持在顶层
        if self.after_sale_reason or self.after_sale_status:
            for child in self.children():
                if isinstance(child, QLabel):
                    child.raise_()

    def _status_text(self):
        # 优先显示售后状态
        if self.after_sale_status:
            return self.after_sale_status
        order_status = self.product_data.get("order_status")
        if order_status == "已完成":
            return "交易完成"
        if order_status in ["退款成功", "已退款"]:
            return "已退款"
        if order_status == "退款失败":
            return "退款失败"
        if order_status == "售后中":
            return "售后中"
        if order_status == "待收货":
            return "待收货"
        if order_status == "待发货":
            return "待发货"
        return "待收货"


class MySalesPage(QMainWindow):
    """我卖出的页面"""
    def __init__(self, parent=None, user_info=None):
        super().__init__(parent)
        # 对齐“我的发布”的逻辑：优先从会话获取当前登录用户
        try:
            from user_session import get_current_user_info, get_current_user_id
            session_user_info = get_current_user_info()
            if session_user_info:
                self.user_info = session_user_info
                self.user_id = get_current_user_id()
            else:
                self.user_info = user_info or {}
                self.user_id = self.user_info.get('user_id')
        except:
            self.user_info = user_info or {}
            self.user_id = self.user_info.get('user_id')
        self.setWindowTitle("我卖出的 - 闲转")
        self.setGeometry(100, 100, 1200, 800)
        self.setStyleSheet("background-color: #F8F8F8;")
        
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)
        
        # 商品列表
        self.create_product_list()
        main_layout.addWidget(self.product_list_area)
        
        main_widget.setLayout(main_layout)
        
        # 加载已卖出商品
        self.load_my_sales()
    
    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        
        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333;
                border: none;
                font-size: 16px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #F5F5F5;
                border-radius: 5px;
            }
        """)
        back_btn.clicked.connect(self.close)
        layout.addWidget(back_btn)
        
        # 标题
        title_label = QLabel("我卖出的")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label, 1)

        # 刷新按钮
        refresh_btn = QPushButton("刷新")
        refresh_btn.setFixedHeight(32)
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 6px 12px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        refresh_btn.clicked.connect(self.load_my_sales)
        layout.addWidget(refresh_btn)
        
        self.top_nav.setLayout(layout)
    
    def create_product_list(self):
        """创建商品列表"""
        self.product_list_area = QScrollArea()
        self.product_list_area.setWidgetResizable(True)
        self.product_list_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(20, 20, 20, 20)
        scroll_layout.setSpacing(20)
        
        # 商品网格
        self.product_grid = QWidget()
        self.grid_layout = QGridLayout()
        self.grid_layout.setSpacing(15)
        self.grid_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.product_grid.setLayout(self.grid_layout)
        
        scroll_layout.addWidget(self.product_grid)
        scroll_layout.addStretch()
        
        scroll_content.setLayout(scroll_layout)
        self.product_list_area.setWidget(scroll_content)
    
    def load_my_sales(self):
        """加载已卖出商品（从本地存储，按用户过滤）"""
        # 清空旧卡片
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        sold = get_sold_goods()
        def belong_to_me(goods):
            if self.user_id is None:
                return True
            return str(goods.get('user_id')) == str(self.user_id)
        
        my_sales = []
        for g in sold:
            if belong_to_me(g):
                # 方案A：优先使用 sold_goods 自己记录的 order_status
                order_status = g.get("order_status")
                order_id = g.get("order_id")
                # 如果没有，则可以兜底去订单表查一次（可选）
                if order_status is None and order_id:
                    order = get_order_by_id(order_id)
                    if order:
                        order_status = order.get("status")

                my_sales.append({
                    "id": g.get("goods_id"),
                    "title": g.get("title"),
                    "price": g.get("price", 0),
                    "img_path": g.get("img_path", ""),
                    "after_sale_reason": g.get("after_sale_reason", ""),
                    "after_sale_status": g.get("after_sale_status", ""),
                    "order_id": g.get("order_id"),
                    "order_status": order_status
                })
        
        row = 0
        col = 0
        for sale in my_sales:
            card = MySaleCard(sale)
            
            # 设置点击事件（使用闭包捕获正确的商品ID）
            product_id = sale["id"]  # 在循环中创建局部变量
            card.clicked = lambda pid=product_id: self.open_product_detail(pid)
            
            self.grid_layout.addWidget(card, row, col)
            col += 1
            if col >= 5:  # 每行5个
                col = 0
                row += 1
    
    def open_product_detail(self, product_id):
        """打开商品详情页"""
        # 找到当前商品的数据
        sold = get_sold_goods()
        target = None
        for g in sold:
            if str(g.get('goods_id')) == str(product_id):
                target = g
                break
        from product_detail_page import ProductDetailPage
        detail_window = ProductDetailPage(
            product_id=product_id,
            product_data={
                'id': product_id,
                'title': target.get('title') if target else '',
                'price': target.get('price', 0) if target else 0,
                'description': target.get('description', '') if target else '',
                'image': target.get('img_path', '') if target else '',
                'images': [p for p in str(target.get('img_path', '')).split(',') if p] if target else [],
                'after_sale_reason': target.get('after_sale_reason', '') if target else '',
                'after_sale_status': target.get('after_sale_status', '') if target else '',
                'order_id': target.get('order_id') if target else None
            },
            user_info=self.user_info,
            is_edit_mode=False,
            is_sold_view=True  # 卖家售出视角
        )
        detail_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MySalesPage()
    window.show()
    sys.exit(app.exec())

