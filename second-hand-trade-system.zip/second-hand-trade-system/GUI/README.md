# second-hand-trade-system

## 安装依赖

本项目使用 PyQt6 作为 GUI 框架。在运行程序前，请先安装依赖：

```bash
pip install -r requirements.txt
```

或者直接安装 PyQt6：

```bash
pip install PyQt6
```

## 运行程序

### 运行主程序（登录页面）
```bash
python main.py
```

### 运行商品列表页面
```bash
python zhuyemian.py
```

## 注意事项

- 本项目已从 PyQt5 迁移到 PyQt6，以支持 Python 3.13
- 如果遇到 DLL 加载错误，请确保已安装 Visual C++ Redistributable
- 建议使用 Python 3.10 或更高版本
