"""
我的发布页面
显示用户已发布的商品列表，点击进入商品详情页
"""
import sys
import os
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QGridLayout)
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor
from local_storage import get_pending_goods, get_approved_goods, get_sold_goods, get_rejected_goods


class MyPostCard(QFrame):
    """已发布商品卡片"""
    clicked = None
    
    def __init__(self, product_data, parent=None):
        super().__init__(parent)
        self.product_data = product_data
        
        self.setFixedSize(200, 280)
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 12px;
                border: 1px solid #E0E0E0;
            }
            QFrame:hover {
                border: 2px solid #FFA366;
                background-color: #FFF8F5;
            }
        """)
        
        layout = QVBoxLayout()
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)
        
        # 商品图片
        image_label = QLabel()
        image_label.setFixedSize(180, 180)
        image_label.setStyleSheet("""
            QLabel {
                background-color: #F5F5F5;
                border-radius: 8px;
            }
        """)
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # 尝试加载真实图片
        img_path = product_data.get("img_path", "")
        if img_path and ',' in str(img_path):
            img_path = str(img_path).split(',')[0].strip()
        if img_path:
            if not os.path.isabs(img_path):
                project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                img_path = os.path.join(project_root, img_path)
            if os.path.exists(img_path):
                pixmap = QPixmap(img_path)
                if not pixmap.isNull():
                    pixmap = pixmap.scaled(180, 180, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                    image_label.setPixmap(pixmap)
                else:
                    self._set_placeholder(image_label)
            else:
                self._set_placeholder(image_label)
        else:
            self._set_placeholder(image_label)
        
        layout.addWidget(image_label)
        
        # 商品标题
        title_label = QLabel(product_data.get("title", "商品标题"))
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 14px;
                font-weight: bold;
            }
        """)
        title_label.setWordWrap(True)
        title_label.setMaximumHeight(40)
        layout.addWidget(title_label)
        
        # 价格和状态
        price_status_layout = QHBoxLayout()
        price_status_layout.setContentsMargins(0, 0, 0, 0)
        
        price_label = QLabel(f"¥{product_data.get('price', 0)}")
        price_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        price_status_layout.addWidget(price_label)
        price_status_layout.addStretch()
        
        # 状态标签
        status = product_data.get("status", "审核中")
        status_label = QLabel(status)
        if status == "审核中":
            status_color = "#999"
        elif status == "已上架":
            status_color = "#52C41A"
        elif status == "已卖出":
            status_color = "#FF8C00"
        elif status == "已下架":
            status_color = "#FF4444"
        else:
            status_color = "#999"
        status_label.setStyleSheet(f"""
            QLabel {{
                color: {status_color};
                font-size: 12px;
                padding: 2px 8px;
                border-radius: 4px;
                background-color: rgba(0, 0, 0, 0.05);
            }}
        """)
        price_status_layout.addWidget(status_label)
        
        layout.addLayout(price_status_layout)
        
        layout.addStretch()
        self.setLayout(layout)
    
    def mousePressEvent(self, event):
        """点击事件"""
        if event.button() == Qt.MouseButton.LeftButton and self.clicked:
            self.clicked()

    def _set_placeholder(self, label):
        pixmap = QPixmap(180, 180)
        pixmap.fill(QColor(245, 245, 245))
        painter = QPainter(pixmap)
        painter.setPen(QColor(200, 200, 200))
        painter.setFont(QFont("Arial", 40))
        painter.drawText(pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "📷")
        painter.end()
        label.setPixmap(pixmap)


class MyPostsPage(QMainWindow):
    """我的发布页面"""
    def __init__(self, parent=None, user_info=None):
        super().__init__(parent)
        # 优先从会话获取用户信息
        try:
            from user_session import get_current_user_info, get_current_user_id
            session_user_info = get_current_user_info()
            if session_user_info:
                self.user_info = session_user_info
                self.user_id = get_current_user_id()
            else:
                self.user_info = user_info or {}
                self.user_id = self.user_info.get('user_id')
        except:
            self.user_info = user_info or {}
            self.user_id = self.user_info.get('user_id')
        self.setWindowTitle("我的发布 - 闲转")
        self.setGeometry(100, 100, 1200, 800)
        self.setStyleSheet("background-color: #F8F8F8;")
        
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)
        
        # 商品列表
        self.create_product_list()
        main_layout.addWidget(self.product_list_area)
        
        main_widget.setLayout(main_layout)
        
        # 加载已发布商品
        self.load_my_posts()
    
    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        
        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333;
                border: none;
                font-size: 16px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #F5F5F5;
                border-radius: 5px;
            }
        """)
        back_btn.clicked.connect(self.close)
        layout.addWidget(back_btn)
        
        # 标题
        title_label = QLabel("我的发布")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label, 1)
        
        self.top_nav.setLayout(layout)
    
    def create_product_list(self):
        """创建商品列表"""
        self.product_list_area = QScrollArea()
        self.product_list_area.setWidgetResizable(True)
        self.product_list_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(20, 20, 20, 20)
        scroll_layout.setSpacing(20)
        
        # 商品网格
        self.product_grid = QWidget()
        self.grid_layout = QGridLayout()
        self.grid_layout.setSpacing(15)
        self.grid_layout.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self.product_grid.setLayout(self.grid_layout)
        
        scroll_layout.addWidget(self.product_grid)
        scroll_layout.addStretch()
        
        scroll_content.setLayout(scroll_layout)
        self.product_list_area.setWidget(scroll_content)
    
    def load_my_posts(self):
        """加载已发布商品（从本地存储，按用户过滤）"""
        # 清空旧卡片
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        
        # 取数据（按当前用户过滤）
        pending = get_pending_goods(self.user_id)
        approved = get_approved_goods(self.user_id)
        sold = get_sold_goods(self.user_id)
        rejected = get_rejected_goods(self.user_id)
        
        def belong_to_me(goods):
            if self.user_id is None:
                return True
            return str(goods.get('user_id')) == str(self.user_id)
        
        # 组装列表：待审核、在售、已卖出/下架/审核未通过
        seen_ids = set()
        my_posts = []
        for g in pending:
            if belong_to_me(g):
                gid = g.get("goods_id")
                if gid in seen_ids:
                    continue
                seen_ids.add(gid)
                my_posts.append({
                    "id": gid,
                    "title": g.get("title"),
                    "price": g.get("price", 0),
                    "status": "审核中",
                    "img_path": g.get("img_path", "")
                })
        for g in approved:
            if not belong_to_me(g):
                continue
            gid = g.get("goods_id")
            if gid in seen_ids:
                continue
            status_val = g.get('status')
            if status_val == 'sold':
                continue  # 已卖出的由 sold 列表处理
            seen_ids.add(gid)
            status_text = "已上架"
            if status_val == 'off':
                status_text = "已下架"
            my_posts.append({
                "id": gid,
                "title": g.get("title"),
                "price": g.get("price", 0),
                "status": status_text,
                "img_path": g.get("img_path", "")
            })
        for g in sold:
            if belong_to_me(g):
                gid = g.get("goods_id")
                if gid in seen_ids:
                    continue
                seen_ids.add(gid)
                status_text = "已卖出" if g.get('status') == 'sold' else "已下架"
                my_posts.append({
                    "id": gid,
                    "title": g.get("title"),
                    "price": g.get("price", 0),
                    "status": status_text,
                    "img_path": g.get("img_path", "")
                })
        for g in rejected:
            if belong_to_me(g):
                gid = g.get("goods_id")
                if gid in seen_ids:
                    continue
                seen_ids.add(gid)
                status_text = "已下架" if g.get('status') == 'off' else "审核未通过"
                my_posts.append({
                    "id": gid,
                    "title": g.get("title"),
                    "price": g.get("price", 0),
                    "status": status_text,
                    "img_path": g.get("img_path", "")
                })
        
        row = 0
        col = 0
        for post in my_posts:
            card = MyPostCard(post)
            
            # 设置点击事件（使用闭包捕获正确的商品ID）
            product_id = post["id"]  # 在循环中创建局部变量
            card.clicked = lambda pid=product_id: self.open_product_detail(pid)
            
            self.grid_layout.addWidget(card, row, col)
            col += 1
            if col >= 5:  # 每行5个
                col = 0
                row += 1
    
    def open_product_detail(self, product_id):
        """打开商品编辑页（复用商品详情的编辑模式）"""
        from PyQt6.QtWidgets import QMessageBox
        try:
            # 找到当前商品的数据
            all_goods = get_pending_goods() + get_approved_goods() + get_sold_goods()
            target = None
            for g in all_goods:
                if str(g.get('goods_id')) == str(product_id):
                    target = g
                    break
            if not target:
                QMessageBox.warning(self, "提示", "未找到商品数据，无法打开详情")
                return

            # 获取发布者信息
            seller_user_id = target.get('user_id') if target else self.user_id
            seller_name = None
            if seller_user_id:
                try:
                    from local_storage import get_user_by_id
                    seller_info = get_user_by_id(seller_user_id)
                    if seller_info:
                        seller_name = seller_info.get('nickname', seller_info.get('username', '用户'))
                except:
                    pass
            
            from product_detail_page import ProductDetailPage
            detail_window = ProductDetailPage(
                product_id=product_id,
                product_data={
                    'id': product_id,
                    'title': target.get('title', ''),
                    'price': target.get('price', 0),
                    'description': target.get('description', ''),
                    'image': target.get('img_path', ''),
                    'images': [p for p in str(target.get('img_path', '')).split(',') if p],
                    'user_id': seller_user_id,  # 确保包含user_id
                    'seller': seller_name or '用户'
                },
                user_info=self.user_info,
                on_purchase=self.load_my_posts,  # 用于刷新列表
                is_edit_mode=True
            )
            detail_window.show()
        except Exception as e:
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "错误", f"打开详情失败: {e}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MyPostsPage()
    window.show()
    sys.exit(app.exec())

