"""
消息列表页面
显示所有聊天会话列表，点击进入对应聊天框
"""
import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QScrollArea,
                             QFrame, QListWidget, QListWidgetItem)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QFont, QColor


class MessageItem(QFrame):
    """消息列表项"""
    clicked = None
    
    def __init__(self, user_name, last_message, time, unread_count=0, parent=None):
        super().__init__(parent)
        self.user_name = user_name
        self.last_message = last_message
        self.time = time
        self.unread_count = unread_count
        
        self.setFixedHeight(80)
        self.setStyleSheet("""
            QFrame {
                background-color: white;
                border-radius: 8px;
                border: 1px solid #E0E0E0;
            }
            QFrame:hover {
                background-color: #FFF8F5;
                border: 1px solid #FF6B35;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        layout.setSpacing(15)
        
        # 头像
        avatar_label = QLabel("👤")
        avatar_label.setFixedSize(50, 50)
        avatar_label.setStyleSheet("""
            QLabel {
                background-color: #E0E0E0;
                border-radius: 25px;
                font-size: 24px;
            }
        """)
        avatar_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(avatar_label)
        
        # 中间信息
        info_layout = QVBoxLayout()
        info_layout.setSpacing(5)
        info_layout.setContentsMargins(0, 0, 0, 0)
        
        # 用户名和时间
        name_time_layout = QHBoxLayout()
        name_time_layout.setContentsMargins(0, 0, 0, 0)
        
        name_label = QLabel(user_name)
        name_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 16px;
                font-weight: bold;
            }
        """)
        name_time_layout.addWidget(name_label)
        name_time_layout.addStretch()
        
        time_label = QLabel(time)
        time_label.setStyleSheet("""
            QLabel {
                color: #999;
                font-size: 12px;
            }
        """)
        name_time_layout.addWidget(time_label)
        info_layout.addLayout(name_time_layout)
        
        # 最后一条消息
        message_label = QLabel(last_message)
        message_label.setStyleSheet("""
            QLabel {
                color: #666;
                font-size: 14px;
            }
        """)
        message_label.setWordWrap(True)
        info_layout.addWidget(message_label)
        
        layout.addLayout(info_layout, 1)
        
        # 未读数角标
        if unread_count > 0:
            badge = QLabel(str(unread_count))
            badge.setFixedSize(20, 20)
            badge.setStyleSheet("""
                QLabel {
                    background-color: #FF4444;
                    color: white;
                    border-radius: 10px;
                    font-size: 12px;
                    font-weight: bold;
                }
            """)
            badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(badge)
        
        self.setLayout(layout)
    
    def mousePressEvent(self, event):
        """点击事件"""
        if event.button() == Qt.MouseButton.LeftButton and self.clicked:
            self.clicked()


class MessageListPage(QMainWindow):
    """消息列表页面"""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("消息通知 - 闲转")
        self.setGeometry(100, 100, 600, 800)
        self.setStyleSheet("background-color: #F8F8F8;")
        
        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # 顶部导航栏
        self.create_top_nav()
        main_layout.addWidget(self.top_nav)
        
        # 消息列表
        self.create_message_list()
        main_layout.addWidget(self.message_list_area)
        
        main_widget.setLayout(main_layout)
        
        # 模拟消息数据
        self.load_messages()
    
    def create_top_nav(self):
        """创建顶部导航栏"""
        self.top_nav = QFrame()
        self.top_nav.setFixedHeight(60)
        self.top_nav.setStyleSheet("""
            QFrame {
                background-color: white;
                border-bottom: 1px solid #E0E0E0;
            }
        """)
        
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 10, 15, 10)
        
        # 返回按钮
        back_btn = QPushButton("← 返回")
        back_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333;
                border: none;
                font-size: 16px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #F5F5F5;
                border-radius: 5px;
            }
        """)
        back_btn.clicked.connect(self.close)
        layout.addWidget(back_btn)
        
        # 标题
        title_label = QLabel("消息通知")
        title_label.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 18px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label, 1)
        
        self.top_nav.setLayout(layout)
    
    def create_message_list(self):
        """创建消息列表"""
        self.message_list_area = QScrollArea()
        self.message_list_area.setWidgetResizable(True)
        self.message_list_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #F8F8F8;
            }
        """)
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout()
        scroll_layout.setContentsMargins(15, 15, 15, 15)
        scroll_layout.setSpacing(10)
        
        self.message_container = QWidget()
        self.message_layout = QVBoxLayout()
        self.message_layout.setContentsMargins(0, 0, 0, 0)
        self.message_layout.setSpacing(10)
        self.message_container.setLayout(self.message_layout)
        
        scroll_layout.addWidget(self.message_container)
        scroll_layout.addStretch()
        
        scroll_content.setLayout(scroll_layout)
        self.message_list_area.setWidget(scroll_content)
    
    def load_messages(self):
        """加载消息列表（优先本地存储，如果服务器可用则同步）"""
        try:
            from user_session import get_current_user_id
            current_user_id = get_current_user_id()
        except:
            current_user_id = None
        
        if not current_user_id:
            return
        
        try:
            # 先从本地存储加载
            from local_storage import get_chat_list
            conversations = get_chat_list(current_user_id)
            
            if conversations:
                for conv in conversations:
                    item = MessageItem(
                        conv.get('other_user_name', '用户'),
                        conv.get('last_message', ''),
                        conv.get('last_time', ''),
                        conv.get('unread_count', 0)
                    )
                    
                    other_user_id = conv.get('other_user_id')
                    other_user_name = conv.get('other_user_name', '用户')
                    item.clicked = lambda uid=other_user_id, name=other_user_name: self.open_chat(uid, name)
                    self.message_layout.addWidget(item)
            else:
                # 没有聊天记录，显示空列表
                pass
            
            # 尝试从服务器同步（可选）
            try:
                from api_service import get_api_service
                api = get_api_service()
                # TODO: 当后端API准备好后，调用获取消息列表API并合并
            except:
                pass  # 服务器不可用，只使用本地存储
            
            print(f"[消息列表] 已加载 {len(conversations)} 个聊天会话")
        except Exception as e:
            print(f"加载消息列表失败: {e}")
            import traceback
            traceback.print_exc()
    
    def open_chat(self, other_user_id, other_user_name=None):
        """打开聊天框"""
        from chat_page import ChatPage
        chat_window = ChatPage(self, other_user_id=other_user_id, other_user_name=other_user_name)
        if other_user_name:
            chat_window.setWindowTitle(f"与 {other_user_name} 的聊天")
        chat_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MessageListPage()
    window.show()
    sys.exit(app.exec())

