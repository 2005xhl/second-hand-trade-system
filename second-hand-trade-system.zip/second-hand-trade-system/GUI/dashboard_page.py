import sys
import random
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QFrame)
from PyQt6.QtCore import Qt, QPropertyAnimation, QEasingCurve, QTimer, pyqtSignal, QPoint
from PyQt6.QtGui import QFont, QPixmap, QPainter, QColor, QPen, QBrush, QMouseEvent, QWheelEvent, QLinearGradient


class BarChart(QWidget):
    """柱状图组件"""
    def __init__(self, data, parent=None):
        super().__init__(parent)
        self.data = data  # {category: value}
        self.hover_index = -1
        self.setMinimumHeight(300)
        self.setStyleSheet("background-color: white; border-radius: 12px;")

    def paintEvent(self, event):
        """绘制柱状图"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        width = self.width()
        height = self.height()
        margin = 40
        chart_width = width - 2 * margin
        chart_height = height - 2 * margin

        # 计算最大值
        max_value = max(self.data.values()) if self.data else 1
        if max_value == 0:
            max_value = 1

        # 绘制坐标轴
        painter.setPen(QPen(QColor(200, 200, 200), 1))
        painter.drawLine(margin, margin, margin, height - margin)
        painter.drawLine(margin, height - margin, width - margin, height - margin)

        # 绘制柱子和标签
        if self.data:
            categories = list(self.data.keys())
            bar_width = chart_width / (len(categories) * 2)
            spacing = bar_width

            for i, (category, value) in enumerate(self.data.items()):
                x = margin + i * (bar_width + spacing) + spacing / 2
                bar_height = (value / max_value) * chart_height
                y = height - margin - bar_height

                # 绘制柱子（橙色渐变）
                gradient = QLinearGradient(x, y, x, y + bar_height)
                gradient.setColorAt(0, QColor(255, 163, 102))
                gradient.setColorAt(1, QColor(255, 133, 85))
                painter.setBrush(QBrush(gradient))
                painter.setPen(Qt.PenStyle.NoPen)

                # hover效果
                if self.hover_index == i:
                    painter.setBrush(QBrush(QColor(255, 163, 102)))
                    # 绘制数值提示
                    painter.setPen(QPen(QColor(255, 255, 255)))
                    painter.setFont(QFont("Arial", 10, QFont.Weight.Bold))
                    text_rect = painter.boundingRect(0, 0, 0, 0, Qt.AlignmentFlag.AlignCenter, str(value))
                    tip_x = x + bar_width / 2 - text_rect.width() / 2
                    tip_y = y - 25
                    painter.drawRect(tip_x - 5, tip_y - 5, text_rect.width() + 10, text_rect.height() + 10)
                    painter.drawText(tip_x, tip_y + text_rect.height(), str(value))
                    painter.setPen(Qt.PenStyle.NoPen)

                painter.drawRect(int(x), int(y), int(bar_width), int(bar_height))

                # 绘制分类标签
                painter.setPen(QPen(QColor(100, 100, 100)))
                painter.setFont(QFont("Arial", 10))
                text_rect = painter.boundingRect(0, 0, 0, 0, Qt.AlignmentFlag.AlignCenter, category)
                label_x = x + bar_width / 2 - text_rect.width() / 2
                painter.drawText(int(label_x), height - margin + 20, category)

    def mouseMoveEvent(self, event: QMouseEvent):
        """鼠标移动事件"""
        width = self.width()
        height = self.height()
        margin = 40
        chart_width = width - 2 * margin

        if self.data:
            categories = list(self.data.keys())
            bar_width = chart_width / (len(categories) * 2)
            spacing = bar_width

            for i in range(len(categories)):
                x = margin + i * (bar_width + spacing) + spacing / 2
                if x <= event.position().x() <= x + bar_width:
                    self.hover_index = i
                    self.update()
                    return

        self.hover_index = -1
        self.update()


class PieChart(QWidget):
    """饼图组件"""
    def __init__(self, data, parent=None):
        super().__init__(parent)
        self.data = data  # {label: value}
        self.hidden_slices = set()
        self.setMinimumHeight(300)
        self.setStyleSheet("background-color: white; border-radius: 12px;")

    def paintEvent(self, event):
        """绘制饼图"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        width = self.width()
        height = self.height()
        center_x = width / 2
        center_y = height / 2
        radius = min(width, height) / 2 - 60

        # 计算总和
        total = sum(v for k, v in self.data.items() if k not in self.hidden_slices)
        if total == 0:
            return

        # 颜色列表
        colors = [
            QColor(255, 163, 102),  # 浅橙色
            QColor(24, 144, 255),  # 蓝色
            QColor(82, 196, 26),   # 绿色
            QColor(250, 173, 20),  # 黄色
            QColor(114, 46, 209),  # 紫色
        ]

        start_angle = 0
        color_index = 0

        # 绘制饼图
        for i, (label, value) in enumerate(self.data.items()):
            if label in self.hidden_slices:
                continue

            span_angle = int((value / total) * 360 * 16)
            color = colors[color_index % len(colors)]

            painter.setBrush(QBrush(color))
            painter.setPen(QPen(QColor(255, 255, 255), 2))
            painter.drawPie(
                int(center_x - radius),
                int(center_y - radius),
                int(radius * 2),
                int(radius * 2),
                start_angle,
                span_angle
            )

            start_angle += span_angle
            color_index += 1

        # 绘制图例
        legend_x = width - 120
        legend_y = 40
        color_index = 0

        for label, value in self.data.items():
            if label in self.hidden_slices:
                continue

            color = colors[color_index % len(colors)]
            percentage = (value / total * 100) if total > 0 else 0

            # 图例颜色块
            painter.setBrush(QBrush(color))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRect(legend_x, legend_y, 15, 15)

            # 图例文字（可点击）
            painter.setPen(QPen(QColor(100, 100, 100)))
            painter.setFont(QFont("Arial", 10))
            legend_text = f"{label} ({percentage:.1f}%)"
            painter.drawText(legend_x + 20, legend_y + 12, legend_text)

            legend_y += 25
            color_index += 1

    def mousePressEvent(self, event: QMouseEvent):
        """点击图例隐藏/显示"""
        width = self.width()
        legend_x = width - 120
        legend_y = 40

        for i, (label, value) in enumerate(self.data.items()):
            if legend_x <= event.position().x() <= legend_x + 100 and \
               legend_y - 10 <= event.position().y() <= legend_y + 10:
                if label in self.hidden_slices:
                    self.hidden_slices.remove(label)
                else:
                    self.hidden_slices.add(label)
                self.update()
                return
            legend_y += 25


class DataCard(QFrame):
    """数据卡片"""
    def __init__(self, title, value, unit, color, parent=None):
        super().__init__(parent)
        self.setFixedSize(200, 120)
        self.setStyleSheet(f"""
            QFrame {{
                background-color: {color};
                border-radius: 12px;
                padding: 20px;
            }}
        """)

        layout = QVBoxLayout()
        layout.setSpacing(10)

        # 标题
        title_label = QLabel(title)
        title_label.setStyleSheet("""
            QLabel {
                color: rgba(255, 255, 255, 0.9);
                font-size: 14px;
            }
        """)
        layout.addWidget(title_label)

        # 数值
        value_layout = QHBoxLayout()
        value_layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        value_label = QLabel(str(value))
        value_label.setStyleSheet("""
            QLabel {
                color: white;
                font-size: 36px;
                font-weight: bold;
            }
        """)
        value_layout.addWidget(value_label)

        unit_label = QLabel(unit)
        unit_label.setStyleSheet("""
            QLabel {
                color: rgba(255, 255, 255, 0.8);
                font-size: 14px;
            }
        """)
        value_layout.addWidget(unit_label)
        value_layout.addStretch()

        layout.addLayout(value_layout)
        layout.addStretch()

        self.setLayout(layout)


class DashboardPage(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("数据看板 - 闲转")
        self.setGeometry(100, 100, 1200, 800)
        self.setStyleSheet("background-color: #F8F8F8;")

        # 数据
        self.category_data = {
            "数码": 45,
            "服饰": 32,
            "图书": 18,
            "家居": 25,
            "其他": 12
        }

        self.order_status_data = {
            "待付款": 15,
            "待发货": 28,
            "待收货": 12,
            "已完成": 45,
            "已取消": 5
        }

        self.stats = {
            "published": 132,
            "orders": 105,
            "favorites": 89
        }

        # 主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)

        # 顶部栏
        self.create_top_bar()
        main_layout.addWidget(self.top_bar)

        # 图表区
        self.create_chart_area()
        main_layout.addWidget(self.chart_area)

        # 数据卡片区
        self.create_data_cards()
        main_layout.addWidget(self.data_cards_area)

        main_layout.addStretch()

        main_widget.setLayout(main_layout)

    def create_top_bar(self):
        """创建顶部栏"""
        self.top_bar = QFrame()
        self.top_bar.setStyleSheet("background-color: transparent;")

        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)

        # 标题
        title_label = QLabel("数据看板")
        title_label.setStyleSheet("""
            QLabel {
                color: #FFA366;
                font-size: 28px;
                font-weight: bold;
            }
        """)
        layout.addWidget(title_label)

        layout.addStretch()

        # 刷新按钮
        self.refresh_btn = QPushButton("刷新数据")
        self.refresh_btn.setFixedSize(120, 40)
        self.refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #FFA366;
                color: white;
                border: none;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FFB380;
            }
        """)
        self.refresh_btn.clicked.connect(self.refresh_data)
        layout.addWidget(self.refresh_btn)

        self.top_bar.setLayout(layout)

    def create_chart_area(self):
        """创建图表区"""
        self.chart_area = QFrame()
        self.chart_area.setStyleSheet("background-color: transparent;")

        layout = QHBoxLayout()
        layout.setSpacing(20)

        # 左侧柱状图
        bar_chart_frame = QFrame()
        bar_chart_frame.setStyleSheet("background-color: transparent;")

        bar_chart_layout = QVBoxLayout()
        bar_chart_layout.setContentsMargins(0, 0, 0, 0)

        bar_title = QLabel("商品分类热度")
        bar_title.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 16px;
                font-weight: bold;
                padding: 10px;
            }
        """)
        bar_chart_layout.addWidget(bar_title)

        self.bar_chart = BarChart(self.category_data)
        bar_chart_layout.addWidget(self.bar_chart)

        bar_chart_frame.setLayout(bar_chart_layout)
        layout.addWidget(bar_chart_frame, 1)

        # 右侧饼图
        pie_chart_frame = QFrame()
        pie_chart_frame.setStyleSheet("background-color: transparent;")

        pie_chart_layout = QVBoxLayout()
        pie_chart_layout.setContentsMargins(0, 0, 0, 0)

        pie_title = QLabel("我的订单状态占比")
        pie_title.setStyleSheet("""
            QLabel {
                color: #333;
                font-size: 16px;
                font-weight: bold;
                padding: 10px;
            }
        """)
        pie_chart_layout.addWidget(pie_title)

        self.pie_chart = PieChart(self.order_status_data)
        pie_chart_layout.addWidget(self.pie_chart)

        pie_chart_frame.setLayout(pie_chart_layout)
        layout.addWidget(pie_chart_frame, 1)

        self.chart_area.setLayout(layout)

    def create_data_cards(self):
        """创建数据卡片区"""
        self.data_cards_area = QFrame()
        self.data_cards_area.setStyleSheet("background-color: transparent;")

        layout = QHBoxLayout()
        layout.setSpacing(20)

        # 已发布商品数
        card1 = DataCard("已发布商品数", self.stats["published"], "件", "#FFA366")
        layout.addWidget(card1)

        # 已成交订单数
        card2 = DataCard("已成交订单数", self.stats["orders"], "单", "#1890FF")
        layout.addWidget(card2)

        # 收藏商品数
        card3 = DataCard("收藏商品数", self.stats["favorites"], "件", "#52C41A")
        layout.addWidget(card3)

        layout.addStretch()

        self.data_cards_area.setLayout(layout)

    def refresh_data(self):
        """刷新数据"""
        # 禁用按钮，显示加载状态
        self.refresh_btn.setEnabled(False)
        self.refresh_btn.setText("加载中...")
        
        # 更新数据
        QTimer.singleShot(1000, self.update_data)

    def update_data(self):
        """更新数据"""
        # 随机更新数据
        self.category_data = {
            "数码": random.randint(30, 60),
            "服饰": random.randint(20, 50),
            "图书": random.randint(10, 30),
            "家居": random.randint(15, 40),
            "其他": random.randint(5, 20)
        }

        self.order_status_data = {
            "待付款": random.randint(10, 25),
            "待发货": random.randint(20, 35),
            "待收货": random.randint(8, 20),
            "已完成": random.randint(30, 60),
            "已取消": random.randint(3, 10)
        }

        self.stats = {
            "published": random.randint(100, 200),
            "orders": random.randint(80, 150),
            "favorites": random.randint(60, 120)
        }

        # 更新图表
        self.bar_chart.data = self.category_data
        self.bar_chart.update()

        self.pie_chart.data = self.order_status_data
        self.pie_chart.update()

        # 更新数据卡片
        self.update_data_cards()

        # 恢复按钮
        self.refresh_btn.setEnabled(True)
        self.refresh_btn.setText("刷新数据")

        # 显示提示
        self.show_toast("数据已更新", "#52C41A")

    def update_data_cards(self):
        """更新数据卡片"""
        # 这里简化处理，实际应该更新卡片内容
        pass

    def show_toast(self, message, color="#FFA366"):
        """显示Toast提示"""
        toast = QLabel(message, self)
        toast.setStyleSheet(f"""
            QLabel {{
                background-color: {color};
                color: white;
                padding: 12px 24px;
                border-radius: 20px;
                font-size: 14px;
                font-weight: bold;
            }}
        """)
        toast.setAlignment(Qt.AlignmentFlag.AlignCenter)
        toast.adjustSize()
        
        # 居中显示
        x = (self.width() - toast.width()) // 2
        y = self.height() // 2
        toast.move(x, y)
        toast.show()

        # 2秒后隐藏
        QTimer.singleShot(2000, toast.hide)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = DashboardPage()
    window.show()
    sys.exit(app.exec())

