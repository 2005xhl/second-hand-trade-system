"""
简易用户表查看脚本
- 读取 GUI/users.db 并打印 users 表的全部数据
- 如数据库不存在，会自动创建空表
"""

import os
import sqlite3

DB_PATH = os.path.join(os.path.dirname(__file__), "GUI", "users.db")


def ensure_table(conn: sqlite3.Connection):
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
        """
    )
    conn.commit()


def main():
    print(f"数据库路径: {DB_PATH}")
    conn = sqlite3.connect(DB_PATH)
    ensure_table(conn)

    cur = conn.cursor()
    cur.execute("SELECT id, username, password FROM users ORDER BY id")
    rows = cur.fetchall()

    if not rows:
        print("users 表当前为空，可在注册界面提交后再查看。")
    else:
        print("当前 users 表数据：")
        for row in rows:
            uid, username, password = row
            print(f"- id={uid}, username={username}, password={password}")

    conn.close()


if __name__ == "__main__":
    main()

