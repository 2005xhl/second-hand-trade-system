# API对接测试指南

## 一、准备工作

### 1. 确认后端服务器信息
- **服务器地址**: `10.129.106.38`
- **端口**: `8888`
- 确保后端服务已启动并可以连接

### 2. 检查网络连接
```bash
# 测试网络连通性（可选）
ping 10.129.106.38
```

---

## 二、使用测试工具

### 方法1: 使用API测试工具（推荐）

运行测试工具：
```bash
cd D:\python\second-hand-trade-system
python GUI/api_test.py
```

**测试步骤**：
1. 打开测试工具窗口
2. 选择测试类型（如"连接测试"）
3. 点击"加载示例参数"或手动输入JSON参数
4. 点击"执行测试"
5. 查看测试结果

**可测试的功能**：
- ✅ 连接测试
- ✅ 获取商品列表
- ✅ 发布商品
- ✅ 审核商品
- ✅ 创建订单
- ✅ 获取订单
- ✅ 更新订单状态

### 方法2: 使用Socket客户端测试工具

运行Socket客户端：
```bash
python socket_client.py
```

手动输入命令测试，例如：
- 指令头: `LOGIN`
- JSON内容: `{"username":"admin","password":"admin123"}`

---

## 三、测试流程

### 1. 基础连接测试
```
测试类型: 连接测试
参数: {}
```
**预期结果**: 连接成功

### 2. 获取商品列表测试
```
测试类型: 获取商品列表
参数: {
  "category": "电子产品",
  "status": "on_sale",
  "page": 1,
  "page_size": 20
}
```
**预期结果**: 返回商品列表数据

### 3. 发布商品测试
```
测试类型: 发布商品
参数: {
  "user_id": 1,
  "title": "测试商品",
  "category": "电子产品",
  "price": 100.0,
  "description": "这是一个测试商品"
}
```
**预期结果**: 返回商品ID

### 4. 审核商品测试
```
测试类型: 审核商品
参数: {
  "goods_id": 1,
  "status": "on_sale",
  "admin_user_id": 1
}
```
**预期结果**: 审核成功

### 5. 创建订单测试
```
测试类型: 创建订单
参数: {
  "buyer_id": 2,
  "goods_id": 1,
  "quantity": 1
}
```
**预期结果**: 返回订单ID和订单号

### 6. 获取订单测试
```
测试类型: 获取订单
参数: {
  "buyer_id": 2,
  "status": "pending_payment"
}
```
**预期结果**: 返回订单列表

---

## 四、切换到API服务

### 步骤1: 在代码中导入API服务
```python
from api_service import get_api_service

api = get_api_service()
```

### 步骤2: 替换local_storage调用

**示例：获取商品列表**

**之前（使用local_storage）**:
```python
from local_storage import get_approved_goods

goods_list = get_approved_goods()
```

**之后（使用API）**:
```python
from api_service import get_api_service

api = get_api_service()
goods_list, total, error = api.goods_get(status='on_sale')
if error:
    print(f"获取失败: {error}")
    # 处理错误
else:
    # 使用goods_list
    pass
```

**示例：发布商品**

**之前**:
```python
from local_storage import add_pending_goods

goods_id = add_pending_goods(goods_data)
```

**之后**:
```python
from api_service import get_api_service

api = get_api_service()
goods_id, error = api.goods_add(goods_data)
if error:
    print(f"发布失败: {error}")
else:
    print(f"发布成功，商品ID: {goods_id}")
```

### 步骤3: 处理错误和异常

所有API方法都会返回错误信息，需要妥善处理：
```python
result, error = api.some_method(params)
if error:
    # 显示错误提示
    QMessageBox.warning(self, "错误", error)
    return
# 继续处理成功的情况
```

---

## 五、常见问题排查

### 1. 连接失败
- ✅ 检查服务器地址和端口是否正确
- ✅ 确认后端服务是否已启动
- ✅ 检查防火墙设置
- ✅ 确认网络连通性

### 2. 响应格式错误
- ✅ 检查后端返回的数据格式是否符合文档
- ✅ 查看`api_service.py`中的字段映射是否正确
- ✅ 检查状态值映射是否正确

### 3. 字段不匹配
- ✅ 查看`API对接说明文档.md`确认字段名
- ✅ 检查`api_service.py`中的字段转换逻辑
- ✅ 确认前端字段和后端字段的映射关系

### 4. 状态值错误
- ✅ 确认状态值映射表（`GOODS_STATUS_MAP`、`ORDER_STATUS_MAP`）
- ✅ 检查后端返回的状态值格式
- ✅ 确认前端使用的状态值是否正确映射

---

## 六、测试检查清单

- [ ] 连接测试通过
- [ ] 获取商品列表正常
- [ ] 发布商品成功
- [ ] 审核商品功能正常
- [ ] 创建订单成功
- [ ] 获取订单列表正常
- [ ] 更新订单状态正常
- [ ] 字段映射正确（状态值、字段名）
- [ ] 错误处理完善
- [ ] 图片上传功能（如需要）

---

## 七、逐步切换建议

### 阶段1: 测试API服务层
1. 使用`api_test.py`测试所有API接口
2. 确认数据格式和字段映射正确

### 阶段2: 单个页面切换
1. 选择一个简单页面（如商品列表页）
2. 替换为API调用
3. 测试功能是否正常

### 阶段3: 全面切换
1. 逐个页面替换API调用
2. 保留`local_storage`作为备用（可选）
3. 全面测试所有功能

---

## 八、调试技巧

### 1. 查看原始响应
在`api_service.py`的`_send_command`方法中添加日志：
```python
print(f"发送: {cmd}|{json.dumps(data, ensure_ascii=False)}")
print(f"响应: {response}")
```

### 2. 检查字段映射
在字段转换方法中添加日志：
```python
print(f"转换前: {data}")
print(f"转换后: {converted_data}")
```

### 3. 使用测试工具
利用`api_test.py`逐步测试每个接口，确认数据格式正确。

---

## 九、联系后端开发

如果遇到问题，需要与后端开发沟通时，请提供：
1. **测试命令**: 发送的具体指令和参数
2. **错误信息**: 完整的错误提示
3. **预期结果**: 期望返回的数据格式
4. **实际结果**: 实际返回的数据（如果有）

---

## 十、注意事项

1. **状态值映射**: 前端使用中文/简写，后端使用英文标准值，API服务层会自动转换
2. **字段名映射**: 某些字段名不同（如`order_number` ↔ `order_no`），会自动处理
3. **图片格式**: 前端使用逗号分隔字符串，后端使用数组，会自动转换
4. **错误处理**: 所有API调用都要检查错误返回值
5. **连接管理**: API服务会自动管理连接，但建议在不需要时调用`close()`

