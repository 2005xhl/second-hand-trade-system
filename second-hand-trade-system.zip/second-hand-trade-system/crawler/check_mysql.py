"""
检查MySQL服务状态
"""

import subprocess
import sys

def check_mysql_service():
    """检查MySQL服务是否运行"""
    print("=" * 60)
    print("MySQL 服务检查")
    print("=" * 60)
    print()
    
    # 方法1: 使用sc命令检查服务状态（Windows）
    print("1. 检查MySQL服务状态...")
    try:
        result = subprocess.run(
            ['sc', 'query', 'MySQL80'],  # MySQL80是常见的服务名，也可能是MySQL、MySQL57等
            capture_output=True,
            text=True,
            timeout=5
        )
        
        if 'RUNNING' in result.stdout:
            print("   ✅ MySQL服务正在运行")
            return True
        elif 'STOPPED' in result.stdout:
            print("   ⚠️  MySQL服务已停止")
            print("   需要启动MySQL服务")
            return False
        else:
            print("   ⚠️  未找到MySQL80服务，尝试其他服务名...")
    except Exception as e:
        print(f"   ⚠️  检查服务失败: {e}")
    
    # 尝试其他常见的MySQL服务名
    service_names = ['MySQL', 'MySQL57', 'MySQL80', 'MYSQL', 'mysql']
    for service_name in service_names:
        try:
            result = subprocess.run(
                ['sc', 'query', service_name],
                capture_output=True,
                text=True,
                timeout=5
            )
            if 'RUNNING' in result.stdout:
                print(f"   ✅ 找到MySQL服务: {service_name}，正在运行")
                return True
            elif 'STOPPED' in result.stdout:
                print(f"   ⚠️  找到MySQL服务: {service_name}，但已停止")
                print(f"   启动命令: net start {service_name}")
                return False
        except:
            continue
    
    print("   ❌ 未找到MySQL服务")
    return False


def show_solutions():
    """显示解决方案"""
    print("\n" + "=" * 60)
    print("解决方案")
    print("=" * 60)
    print()
    
    print("方法1: 启动MySQL服务（推荐）")
    print("  1. 按 Win+R，输入 services.msc，回车")
    print("  2. 找到 MySQL 或 MySQL80 服务")
    print("  3. 右键 -> 启动")
    print()
    print("  或者使用命令行（以管理员身份运行）：")
    print("     net start MySQL80")
    print("     # 或")
    print("     net start MySQL")
    print()
    
    print("方法2: 检查MySQL是否安装")
    print("  如果没有安装MySQL，可以：")
    print("  1. 下载安装MySQL: https://dev.mysql.com/downloads/mysql/")
    print("  2. 或使用XAMPP/WAMP等集成环境")
    print("  3. 或使用Docker运行MySQL")
    print()
    
    print("方法3: 检查端口")
    print("  如果MySQL运行在不同端口，需要修改配置：")
    print("  - 编辑 crawler/quick_start.py")
    print("  - 修改 'port': 3306 为实际端口")
    print()
    
    print("方法4: 检查MySQL配置")
    print("  确保MySQL允许本地连接：")
    print("  - 检查 my.ini 或 my.cnf 配置文件")
    print("  - 确保 bind-address = 127.0.0.1 或 0.0.0.0")
    print()


if __name__ == "__main__":
    is_running = check_mysql_service()
    
    if not is_running:
        show_solutions()
        
        print("\n" + "=" * 60)
        print("快速启动MySQL服务")
        print("=" * 60)
        print()
        print("请以管理员身份运行以下命令之一：")
        print()
        print("  net start MySQL80")
        print("  # 或")
        print("  net start MySQL")
        print("  # 或")
        print("  net start MySQL57")
        print()
        print("如果不知道服务名，可以运行：")
        print("  sc query | findstr MySQL")
        print()

