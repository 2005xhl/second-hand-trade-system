"""
测试MySQL数据库连接
用于排查连接问题
"""

import pymysql
import sys

def test_connection():
    """测试数据库连接"""
    print("=" * 60)
    print("MySQL 数据库连接测试")
    print("=" * 60)
    print()
    
    # 数据库配置
    db_config = {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'password': '123456',  # 请修改为你的数据库密码
        'database': 'used_goods_platform',
        'charset': 'utf8mb4'
    }
    
    print("数据库配置：")
    print(f"  主机: {db_config['host']}")
    print(f"  端口: {db_config['port']}")
    print(f"  用户: {db_config['user']}")
    print(f"  密码: {'*' * len(db_config['password'])}")
    print(f"  数据库: {db_config['database']}")
    print()
    
    # 测试1: 检查MySQL服务是否运行
    print("1. 测试MySQL服务连接...")
    try:
        # 先不指定数据库，只测试MySQL服务
        test_config = db_config.copy()
        test_config.pop('database', None)
        conn = pymysql.connect(**test_config)
        print("   ✅ MySQL服务连接成功")
        conn.close()
    except pymysql.err.OperationalError as e:
        print(f"   ❌ MySQL服务连接失败: {e}")
        print()
        print("可能的原因：")
        print("  - MySQL服务没有启动")
        print("  - 主机地址或端口错误")
        print("  - 防火墙阻止连接")
        return False
    except Exception as e:
        print(f"   ❌ 连接异常: {e}")
        return False
    
    # 测试2: 检查数据库是否存在
    print("\n2. 检查数据库是否存在...")
    try:
        test_config = db_config.copy()
        test_config.pop('database', None)
        conn = pymysql.connect(**test_config)
        cursor = conn.cursor()
        
        cursor.execute("SHOW DATABASES LIKE %s", (db_config['database'],))
        result = cursor.fetchone()
        
        if result:
            print(f"   ✅ 数据库 '{db_config['database']}' 存在")
        else:
            print(f"   ❌ 数据库 '{db_config['database']}' 不存在")
            print(f"\n   创建数据库...")
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{db_config['database']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
            conn.commit()
            print(f"   ✅ 数据库已创建")
        
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"   ❌ 检查数据库失败: {e}")
        return False
    
    # 测试3: 连接到指定数据库
    print("\n3. 连接到指定数据库...")
    try:
        conn = pymysql.connect(**db_config)
        print(f"   ✅ 成功连接到数据库 '{db_config['database']}'")
        conn.close()
    except pymysql.err.OperationalError as e:
        error_code, error_msg = e.args
        print(f"   ❌ 连接失败: {error_msg}")
        print()
        if error_code == 1045:
            print("   错误原因：用户名或密码错误")
        elif error_code == 1049:
            print("   错误原因：数据库不存在")
        else:
            print(f"   错误代码: {error_code}")
        return False
    except Exception as e:
        print(f"   ❌ 连接异常: {e}")
        return False
    
    # 测试4: 检查表是否存在
    print("\n4. 检查goods表是否存在...")
    try:
        conn = pymysql.connect(**db_config)
        cursor = conn.cursor()
        
        cursor.execute("SHOW TABLES LIKE 'goods'")
        result = cursor.fetchone()
        
        if result:
            print("   ✅ goods表存在")
            
            # 检查表结构
            cursor.execute("DESCRIBE goods")
            columns = cursor.fetchall()
            print(f"   ✅ 表结构正常（{len(columns)}个字段）")
        else:
            print("   ❌ goods表不存在")
            print("   需要运行数据库初始化脚本创建表")
        
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"   ❌ 检查表失败: {e}")
        return False
    
    print("\n" + "=" * 60)
    print("✅ 所有测试通过！数据库连接正常")
    print("=" * 60)
    return True


if __name__ == "__main__":
    try:
        success = test_connection()
        if not success:
            print("\n请根据上述错误信息修复问题后重试")
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n用户中断")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ 发生未预期的错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

