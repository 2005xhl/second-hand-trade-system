# 如何启动MySQL服务

## 🔍 问题诊断

检测到你的MySQL服务已停止，需要启动后才能连接数据库。

## 🚀 启动方法

### 方法1: 使用服务管理器（最简单）

1. **按 `Win + R`**，输入 `services.msc`，回车
2. 在服务列表中找到 **MySQL** 服务
3. 右键点击 -> **启动**
4. 等待服务启动完成（状态变为"正在运行"）

### 方法2: 使用命令行（需要管理员权限）

1. **以管理员身份打开 PowerShell 或 CMD**
   - 右键点击"开始"菜单
   - 选择"Windows PowerShell (管理员)" 或 "命令提示符 (管理员)"

2. 运行启动命令：
   ```bash
   net start MySQL
   ```

   如果服务名不是 `MySQL`，可以尝试：
   ```bash
   net start MySQL80
   # 或
   net start MySQL57
   ```

3. 看到"服务已成功启动"的提示即可

### 方法3: 使用任务管理器

1. 按 `Ctrl + Shift + Esc` 打开任务管理器
2. 切换到"服务"标签
3. 找到 MySQL 服务
4. 右键 -> 启动

## ✅ 验证服务是否启动

启动后，运行测试脚本验证：

```bash
python crawler/test_db_connection.py
```

如果看到"✅ 所有测试通过！数据库连接正常"，说明MySQL已成功启动。

## ⚠️ 常见问题

### Q: 提示"拒绝访问"？
A: 需要以**管理员身份**运行命令提示符或PowerShell

### Q: 提示"服务名无效"？
A: 先查看所有MySQL服务名：
   ```bash
   sc query | findstr MySQL
   ```
   然后使用正确的服务名启动

### Q: MySQL服务启动后立即停止？
A: 可能是MySQL配置有问题，检查：
   - MySQL错误日志（通常在MySQL安装目录的data文件夹）
   - 端口3306是否被占用
   - MySQL配置文件是否正确

### Q: 没有安装MySQL？
A: 需要先安装MySQL：
   - 下载：https://dev.mysql.com/downloads/mysql/
   - 或使用XAMPP/WAMP等集成环境
   - 或使用Docker运行MySQL

## 📝 设置MySQL开机自启（可选）

如果希望MySQL每次开机自动启动：

1. 打开服务管理器（`services.msc`）
2. 找到MySQL服务
3. 右键 -> 属性
4. 启动类型选择"自动"
5. 确定

这样MySQL就会在每次开机时自动启动了。

