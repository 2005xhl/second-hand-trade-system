"""
快速开始脚本 - 生成测试商品数据
直接运行此脚本即可快速填充数据库
"""


import sys
import os

# 添加当前目录到路径，以便导入spider模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from spider import MockSpider

def main():
    print("=" * 60)
    print("商品数据快速填充工具")
    print("=" * 60)
    print()
    
    # 数据库配置（请根据实际情况修改）
    db_config = {
        'host': '127.0.0.1',
        'port': 3306,
        'user': 'root',
        'password': '123456',  # ⚠️ 请修改为你的数据库密码
        'database': 'used_goods_platform',
        'charset': 'utf8mb4'
    }
    
    # 询问用户要生成多少商品
    try:
        count = input("请输入要生成的商品数量（默认100）: ").strip()
        count = int(count) if count else 100
    except ValueError:
        count = 100
        print("输入无效，使用默认值100")
    
    print(f"\n开始生成 {count} 个商品数据...")
    print("-" * 60)
    
    # 创建爬虫实例
    spider = MockSpider(db_config=db_config, image_dir="images")
    
    # 开始生成数据
    spider.crawl(max_items=count)
    
    print("-" * 60)
    print("✅ 完成！商品数据已保存到数据库")
    print(f"📁 图片目录: {spider.image_dir}/")
    print("\n现在可以在前端界面查看这些商品了！")

if __name__ == "__main__":
    main()

