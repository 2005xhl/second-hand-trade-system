"""
数据库初始化脚本
创建goods表和其他必要的表
"""

import pymysql
import sys

# 数据库配置
DB_CONFIG = {
    'host': '127.0.0.1',
    'port': 3306,
    'user': 'root',
    'password': '123456',  # ⚠️ 请修改为你的数据库密码
    'database': 'used_goods_platform',
    'charset': 'utf8mb4'
}

# 创建goods表的SQL
CREATE_GOODS_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS `goods` (
    `goods_id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '商品ID',
    `user_id` INT NOT NULL COMMENT '发布者用户ID',
    `title` VARCHAR(200) NOT NULL COMMENT '商品标题',
    `category` VARCHAR(100) DEFAULT '其他' COMMENT '商品分类',
    `price` DECIMAL(10, 2) NOT NULL COMMENT '商品价格',
    `original_price` DECIMAL(10, 2) DEFAULT NULL COMMENT '原价',
    `condition` VARCHAR(20) DEFAULT '99新' COMMENT '成色',
    `description` TEXT COMMENT '商品描述',
    `img_path` TEXT COMMENT '图片路径（多个用逗号分隔）',
    `status` ENUM('pending', 'approved', 'rejected', 'sold') DEFAULT 'pending' COMMENT '状态：待审核/已通过/已拒绝/已售出',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_category` (`category`),
    INDEX `idx_status` (`status`),
    INDEX `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='商品表';
"""

# 创建user表的SQL（如果不存在）
CREATE_USER_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS `user` (
    `user_id` INT AUTO_INCREMENT PRIMARY KEY COMMENT '用户ID',
    `username` VARCHAR(50) UNIQUE NOT NULL COMMENT '用户名',
    `password` VARCHAR(255) NOT NULL COMMENT '密码（MD5加密）',
    `nickname` VARCHAR(100) DEFAULT NULL COMMENT '昵称',
    `phone` VARCHAR(20) DEFAULT NULL COMMENT '手机号',
    `role` ENUM('normal', 'admin') DEFAULT 'normal' COMMENT '角色：普通用户/管理员',
    `status` ENUM('active', 'blocked') DEFAULT 'active' COMMENT '状态：正常/封禁',
    `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    INDEX `idx_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';
"""


def init_database():
    """初始化数据库"""
    print("=" * 60)
    print("数据库初始化")
    print("=" * 60)
    print()
    
    try:
        # 连接数据库（不指定数据库，先创建数据库）
        config_without_db = DB_CONFIG.copy()
        config_without_db.pop('database')
        
        print("1. 连接MySQL服务器...")
        conn = pymysql.connect(**config_without_db)
        cursor = conn.cursor()
        print("   ✅ 连接成功")
        
        # 创建数据库（如果不存在）
        print(f"\n2. 创建数据库 '{DB_CONFIG['database']}'...")
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{DB_CONFIG['database']}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        conn.commit()
        print("   ✅ 数据库已创建/已存在")
        
        # 切换到目标数据库
        cursor.execute(f"USE `{DB_CONFIG['database']}`")
        
        # 创建user表
        print("\n3. 创建user表...")
        cursor.execute(CREATE_USER_TABLE_SQL)
        conn.commit()
        print("   ✅ user表已创建/已存在")
        
        # 创建goods表
        print("\n4. 创建goods表...")
        cursor.execute(CREATE_GOODS_TABLE_SQL)
        conn.commit()
        print("   ✅ goods表已创建/已存在")
        
        # 检查表结构
        print("\n5. 验证表结构...")
        cursor.execute("DESCRIBE goods")
        columns = cursor.fetchall()
        print(f"   ✅ goods表有 {len(columns)} 个字段")
        
        cursor.execute("DESCRIBE user")
        columns = cursor.fetchall()
        print(f"   ✅ user表有 {len(columns)} 个字段")
        
        cursor.close()
        conn.close()
        
        print("\n" + "=" * 60)
        print("✅ 数据库初始化完成！")
        print("=" * 60)
        print()
        print("现在可以运行爬虫脚本填充数据了：")
        print("  python crawler/quick_start.py")
        return True
        
    except pymysql.err.OperationalError as e:
        error_code, error_msg = e.args
        print(f"\n❌ 数据库操作失败: {error_msg}")
        if error_code == 1045:
            print("   错误原因：用户名或密码错误")
            print(f"   请检查密码是否正确（当前配置: {DB_CONFIG['password']}）")
        elif error_code == 2003:
            print("   错误原因：无法连接到MySQL服务器")
            print("   请确保MySQL服务正在运行")
        return False
    except Exception as e:
        print(f"\n❌ 发生错误: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("⚠️  请确保已修改脚本中的数据库密码！")
    print(f"   当前配置: password = '{DB_CONFIG['password']}'")
    print()
    
    confirm = input("是否继续初始化数据库？(y/n): ").strip().lower()
    if confirm != 'y':
        print("已取消")
        sys.exit(0)
    
    success = init_database()
    sys.exit(0 if success else 1)

